# Maximo Script Deployment — API Rules

These rules govern every deploy script written for this lab. Follow them exactly.

## Base URL

The Maximo REST API base is `{MAXIMO_URL}/maximo/api` — **not** `/maximo/oslc`.

```
BASE = f"{MAXIMO_URL}/maximo/api"
```

- `MAXIMO_URL` is the bare server root, e.g. `https://host.example.com` (no trailing slash).
- All endpoint paths are appended to `BASE`.

## Endpoints

| Purpose | Endpoint |
|---------|----------|
| Scripts | `{BASE}/os/mxapiautoscript` |
| Launch points | `{BASE}/os/mxapilaunchpoint` |

Always append `?lean=1` to every request.

## Required headers

```
apikey: <MAXIMO_APIKEY>
x-public-uri: <MAXIMO_PUBLIC_URI>
Content-Type: application/json
```

## Script language values

| File extension | `scriptlanguage` value |
|---|---|
| `.py` | `jython` |
| `.js` | `nashorn` |

## SSL verification

The demo server uses a self-signed certificate. Always pass `verify=False` and suppress warnings:

```python
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# then on every requests call:
requests.get(url, ..., verify=False, timeout=30)
requests.post(url, ..., verify=False, timeout=60)
```

## Creating a script

`POST {BASE}/os/mxapiautoscript?lean=1` with `autoscript`, `scriptlanguage`, `active`, `source`.

## Updating an existing script

**Never use PUT.** POST to the script's resource ID with `x-method-override: PATCH`.

`POST {BASE}/os/mxapiautoscript/{rest_id}?lean=1`
Header: `x-method-override: PATCH`
Body: only the fields changing (e.g. `source`, `active`).

Obtain `rest_id` from the last path segment of the `href` returned by:
`GET {BASE}/os/mxapiautoscript?lean=1&oslc.where=autoscript="<NAME>"&oslc.select=autoscript,href`

## Launch points are independent records

Launch points are **not** child objects of the script record. Do not embed them in the script POST. Create them separately:

`POST {BASE}/os/mxapilaunchpoint?lean=1`

Check for existence first:  
`GET {BASE}/os/mxapilaunchpoint?lean=1&oslc.where=autoscript="<NAME>"&oslc.select=launchpointname`  
Skip creation if the `member` array is non-empty.

Object LP payload: `launchpointname`, `launchpointtype=OBJECT`, `objectname`, `autoscript`, `event`, `add`, `update`, `delete` (booleans), `active=false`.

Attribute LP payload: same but `launchpointtype=ATTRIBUTE` and `attributename` instead of `add`/`update`/`delete` (also `active=false`).

## Correct event strings

| Event | String |
|---|---|
| Save | `SAVE` |
| Initialize | `INIT` |
| Action | `ACTION` |
| Retrieve List | `RETRIEVELIST` |

## Running Python scripts

Always run Python scripts using the virtual environment at `maximo-scripts/.venv`:

```bash
maximo-scripts/.venv/bin/python <script>
```

Never use a system or global `python` / `python3` executable for this lab.

## Creating the .env file

The `maximo-scripts/.env` file is blocked by `.gitignore`, so the `write_file` tool will fail with an access-denied error. Always create it using the shell instead:

```bash
cat > maximo-scripts/.env << 'EOF'
MAXIMO_URL=<user_provided_url>
MAXIMO_API_KEY=<user_provided_key>
EOF
```

Never attempt to create `.env` with `write_file` or `insert_content`.

## Pinned configuration for specific scripts

`LEGACY_COUNTRY_LOOKUP` calls an external API and its URL must be moved out of script source per `SEC-02`. For this lab, always use the system property name `ext.country.api.url` for that fix — do not invent or vary the property name across runs. Read it with `MXServer.getProperty("ext.country.api.url")`, document it in the script header, and include "create system property `ext.country.api.url` if it doesn't already exist" as an explicit step in the deployment plan (System Configuration → Platform Configuration → System Properties is the manual path; there is no REST endpoint for this in the lab, so this step is always manual — list it alongside other manual steps, not the automatable `autoscriptvars`/launch-point steps).

## PUBLISH channel scripts — must be INACTIVE

Any script whose name does not exactly match `PUBLISH.<channel>.USEREXIT.OUT.BEFORE` cannot be wired to a publish channel. Deploy such scripts with `active: false` and no launch point. Participants test them via the Automation Scripts Test dialog.

## Variable bindings (`autoscriptvars`)

Variables are defined on the **autoscript record's `autoscriptvars` sub-collection** — not on the launch point. The launch point's `launchpointvars` only overrides a binding's value per-LP; it does not define the variable itself.

**Checking existing bindings:**
`GET {BASE}/os/mxapiautoscript?lean=1&oslc.where=autoscript="<NAME>"&oslc.select=autoscript,autoscriptvars{*}`

**Field meanings:**

| Field | Meaning |
|---|---|
| `varname` | The variable name as referenced in script code |
| `vartype` | Direction — `IN`, `OUT`, or `INOUT` |
| `varbindingtype` | Source — `ATTRIBUTE` (from the MBO) or `LITERAL` (fixed value) |
| `varbindingvalue` | The bound attribute name, or the literal value |

**Creating a binding:** `POST` to the script's `autoscriptvars` sub-collection (via the script's resource ID, `x-method-override: PATCH` on the parent script resource, same pattern as updating script source) with `varname`, `vartype`, `varbindingtype`, `varbindingvalue`.

**Always verify after creating:** re-`GET` `autoscriptvars` for that script and confirm the new entry is present with the expected values.

# Made with Bob 
