# Maximo — Automation Scripting via REST & Integration (reference)

How scripting plugs into the **REST/JSON (OSLC) API** and the **Maximo Integration
Framework (MIF)**. This is the bridge between this skill's loaders/queries
(connect-auth.md, data-model-loading.md, query-cookbook.md) and server-side
scripts: when the out-of-the-box REST options can't express something, a script
fills the gap — invoked over the same `/oslc` or `/api` route you already use.

> **Golden rule.** Reach for a script only when configuration can't do it. For
> filtering, prefer a saved query / `oslc.where`; for status, prefer
> `?action=wsmethod:changeStatus`. Scripts are custom code with the usual
> performance and ordering caveats (see scripting-test-debug.md). Confirm route
> (`/oslc` vs `/api`) and auth per connect-auth.md.

---

## 1. Script Handler — call a script directly over REST

Create a **vanilla script** (no launch point) and invoke it by name:
```
GET|POST  https://<host>/maximo/api/script/<SCRIPTNAME>?lean=1
```
Implicit vars: `request` (OslcRequest — `request.getQueryParam("p")`,
`request.getHeader("h")`, `request.getUserInfo()`, `request.getHttpMethod()`),
`requestBody` (String, for POST/PATCH/PUT), `httpMethod`, plus OUT vars
`responseBody` (String or byte[]) and `responseHeaders` (HashMap).

```python
# /oslc/script/setinsertsite?siteid=BEDFORD - set session default insert site
from psdi.server import MXServer
mx = MXServer.getMXServer()
siteid = request.getQueryParam("siteid")
if siteid and mx.isValidSite(siteid):
    ui = request.getUserInfo()
    us = mx.getMboSet("MAXUSER", ui); us.setQbeExactMatch(True); us.setQbe("userid", ui.getUserName())
    u = us.moveFirst()
    if u:
        u.setValue("DEFSITE", siteid)
        mx.lookup("SECURITY").refreshSecurityInfo(ui.getUserName(), u, u.getMboSet("PERSON").getMbo(0))
        us.save()
    us.close()
else:
    service.error("system", "invalidsite", [siteid])
```

**Security** (any authenticated user can call any script otherwise):
- *Global*: Object Structures app → More Actions → **Add/Modify API Route**, filter
  `script`, tie the GET/POST routes to an app + sigoption.
- *Per script*: add IN/INOUT **LITERAL** vars `authapp` and `authsigoption`.

## 2. Object-Structure scripts (per-OS, configured in the OS app)

These attach to a specific object structure (e.g. `MXAPIWODETAIL`) and shape its
REST/integration behavior. Create via **Create Integration Scripts** in the
Autoscript app, then register in the Object Structures app.

### 2a. OS Query script — dynamic `oslc.where`
For filters the standard `oslc.where` can't express (e.g. mixing AND/OR before
Manage 8.3 / 7.6.1.3). Implicit `mboset` = the root set; you `setWhere(...)`.
Define IN **literal** vars (default e.g. `*`) supplied at call time as `sqp:<var>`.
```python
def isSet(v): return v and v != '*'
from psdi.mbo import SqlFormat
q = "historyflag=0 and istask=0 "
if isSet(assetnum) and isSet(location): q += " and (assetnum=:1 or location=:2) "
elif isSet(assetnum):                   q += " and assetnum=:1 "
elif isSet(location):                   q += " and location=:2 "
sqf = SqlFormat(q)
if isSet(assetnum): sqf.setObject(1, "WORKORDER", "ASSETNUM", assetnum)
if isSet(location): sqf.setObject(2, "WORKORDER", "LOCATION", location)
mboset.setWhere(sqf.format())
```
Call: `...&savedQuery=OSQUERY.MXAPIWODETAIL.EMXWOFILTER&sqp:assetnum=11430&sqp:location=BR430`

### 2b. OS Action script — custom action on a record/set
Register an **Action Definition** (impl type = Script) on the OS. Implicit `mbo`,
`mboset`, `request`, `requestBody`, `httpMethod`. Mark **Collection Action** for
set-level. Invoke `?action=<NAME>` (add `x-method-override: PATCH` on an existing
record):
```python
template = request.getQueryParam("template")
if template:
    c = mbo.createComm(); c.setValue("TEMPLATEID", template); c.sendMessage()
```
`POST /api/os/mxapisr/<rest id>?action=SENDCOMM&template=1014` + `x-method-override: PATCH`

### 2c. REST select attribute — `script.<name>` in `oslc.select`
Return a computed value as a pseudo-attribute. Implicit `mbo` (current/child),
set `evalresult` (String or list, non-null):
```python
from psdi.mbo import SqlFormat
codes = []
sqf = SqlFormat(mbo, "itemnum = :itemnum and orgid = :orgid and (siteid is null or siteid = :siteid)")
s = mbo.getThisMboSet().getSharedMboSet("INVVENDOR", sqf.format())
m = s.moveFirst()
while m:
    if m.getString("CATALOGCODE"): codes.append(m.getString("CATALOGCODE"))
    m = s.moveNext()
evalresult = ",".join(codes)
```
`...&oslc.select=countbooknum,siteid,script.vendorcatalog`

## 3. OS inbound/outbound processing (MIF + REST + app import)

A script on an OS affects **all** paths through it (REST, import, enterprise
service, invoke/publish channel). A `ctx` object (extends `service`) is passed in;
write **named functions** the framework calls.

**Inbound** functions (run per noun / per MBO):
`beforeProcess(ctx)` · `beforeCreateMboSet`/`afterCreateMboSet` · `mboRules(ctx)` ·
`beforeMboData(ctx)` / `afterMboData(ctx)` · `preSaveRules(ctx)` · `changeStatus(ctx)`.

Key `ctx` APIs: `getData()` (StructureData — `getCurrentData("COL")`,
`isCurrentDataNull`, `getCurrentDataAsDate`), `skipMbo()`, `skipTxn()`,
`complete()`, `process()`, `getMbo()`, `getMboSet()`/`setMboSet()`, `setMbo()`,
`getParentMbo()`, `getPrimaryMbo()`/`getPrimaryMboSet()`, `isPrimary()`,
`getUserInfo()`, `bypassMbo()`, `getMsgType()`/`setMsgType()`,
`getMosDetailInfo().getObjectName()`, `processAsAdd()`/`processAsUpdate()`,
`setSkipBaseAdditionalRules()`.
```javascript
function beforeProcess(ctx) {                      // filter early - cheapest place
  if (ctx.getData().getCurrentData("LOTTYPE") == "NOLOT") ctx.skipTxn();
}
function beforeMboData(ctx) {                      // conditionally default a field
  if (ctx.getMosDetailInfo().getObjectName() == "ITEM") {
    if (ctx.getData().getCurrentData("HIERARCHYPATH") == "PUMP \\ CNTRFGL") {
      var MboConstants = Java.type("psdi.mbo.MboConstants");
      ctx.getMbo().setValue("commoditygroup", "PUMP", MboConstants.DELAYVALIDATION);
    }
  }
}
```
*before vs after MboData*: `before` lets the MIF still set the field when your
condition isn't met; `after` requires the column be **Set Restricted** on the OS
(or `setFieldFlag("col", NOSETVALUE, false)`) so your value wins.

**Outbound** functions (define ≥1): `overrideValues(ctx)`, `skipMbo(ctx)`,
`skipCols(ctx)`. Use `ctx.getMboName()`, `ctx.getMbo()`, `ctx.overrideCol(...)`,
`ctx.skipCol([...])` — manipulate serialization *before* XML/JSON is built (cheaper
than exits).
```python
def overrideValues(ctx):
  if ctx.getMboName() == 'PO' and ctx.getMbo().isNull("description"):
    ctx.overrideCol("DESCRIPTION", "PO " + ctx.getMbo().getString("ponum"))
def skipCols(ctx):
  if ctx.getMboName() == 'POLINE' and not ctx.getMbo().getBoolean("taxed"):
    ctx.skipCol(['tax1','tax2','tax3','tax4','tax5'])
```

## 4. Publish-channel scripts (outbound JMS/Kafka)

Script points: **Event Filter** (best — runs before serialization), **External
Exit** (irData→erData transform), **User Exit Before/After External Exit**. Naming:
`PUBLISH.<channel>.EVENTFILTER`, `PUBLISH.<channel>.EXTEXIT.OUT`,
`PUBLISH.<channel>.USEREXIT.OUT.BEFORE|AFTER`. Vars: `irData`/`erData`
(StructureData), `ifaceName`, `osName`, `messageType`, `extSystem`, `userInfo`,
`conn`. **Event-filter `mbo` is buggy — use `service.getMbo()`.** `evalresult =
False` ⇒ publish the event.
```python
# Event filter - don't publish when status flips to BROKEN
if service.getMbo().isModified("status") and service.getMbo().getString("status") == "BROKEN":
  evalresult = False
else:
  evalresult = True
```

## 5. Endpoint / handler exit scripts (outbound transport)

Register handler class `com.ibm.tivoli.maximo.script.ScriptRouterHandler` (7.6.1.2+),
set the endpoint's `script` property to your script name. Vars: `requestData`
(byte[]), `requestDataS` (String), `responseData` (OUT), plus all endpoint
`metaData` as vars (e.g. `destination`).
```python
from psdi.server import MXServer
from java.lang import String
MXServer.getMXServer().sendEMail(to, sender, subject, String(requestData))
```
**Transport exits** register via `script:<name>` on a handler property:
- HTTP (`HTTPEXIT`): `urlProps(req)`, `getUrl(req)`, `headerProps(req)`,
  `processResponse(resp)` — `ScriptHTTPReq`/`Resp` (add headers/url/form params, read
  response code/data). Common use: fetch a token in `headerProps` and add it.
- Web service (`WSEXIT`): `setupHeaders(req)`, `responseOk(resp)`,
  `responseError(resp)` — e.g. inject a WS-Security UsernameToken header.
- JMS: `msgProps(req)`, `responseOk(resp)`, `responseError(resp)`.

## 6. Cron-task scripts

Register class `com.ibm.tivoli.maximo.script.ScriptCrontask` in the Cron Task app,
create an instance, set `SCRPTNAME` to the script name and a schedule. Use for
schedules **not** tied to a Maximo object (use Escalations for object-based jobs).
Vars: `runAsUserInfo` (the job's UserInfo), `arg` (the `SCRIPTARG` parameter).
```python
from psdi.server import MXServer
argval = int(arg)
cnt = MXServer.getMXServer().getMboSet("maxsession", runAsUserInfo).count()
if cnt > argval:
  service.logError("cnt exceeds limit:: " + str(cnt))
```

## 7. MMI (Maximo Management Interface) scripts

Add an admin/introspection REST apilet, distributed to every cluster member, via
the **MMI** dialog (Logging app → Monitor Environment Information). Var `br` has
`setProperty(name, val)` / `getProperty(name)`. A script named `SYSTEMLOCALE` is
served at `GET /oslc/members/{member id}/systemlocale`.
```python
from java.util import Locale
br.setProperty("syslocale", Locale.getDefault().toString())
```

---

See **scripting-launchpoints.md** for event-driven (non-REST) launch points and
special named scripts, **scripting-service-mbo-api.md** for the `service`/MBO API,
and **scripting-test-debug.md** for testing these over the Test dialog + logging.
