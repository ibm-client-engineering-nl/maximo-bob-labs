# Maximo — Automation Scripting: test, debug & best practices (reference)

How to prove a script works **before** it touches a live event, see what it did,
and keep it from dragging the server down. Scripts run in the triggering thread,
so a bad one is indistinguishable from bad Java — treat performance accordingly.

---

## The Test button (author-time, no logging setup needed)

The Automation Scripts app has a **Test** dialog: prepare test data, run the
script, read everything in the **Process Log** (any `service.log(...)` output
appears there without enabling loggers). The resulting MBO is serialized into the
**Data** field so you can confirm the end state. The dialog tries **not to commit**,
but can't always avoid it (after-commit events, or a `save()` in your code).

**Object Path** selects the MBO bound to `mbo`:
| Path | Meaning |
|------|---------|
| `ASSET` | a **new** Asset MBO |
| `ASSET[assetnum='SPFN0001']` | an existing Asset |
| `PO[ponum='1056']/POLINE` | navigate to a child set (e.g. for *Can Add*) |
| `ASSET[assetnum='ASSET1' and siteid='BEDFORD']/ASCHANGESTATUS` | non-persistent child (setup/execute) |

Use the **Set Attribute Value** table to seed attributes (e.g. `ASSETNUM=TESTADD10`,
`ASSETTYPE=FLEET`) and watch the validation fire. The dialog tests every script
type — Object/Attribute/Action/Condition LPs, OS inbound (`beforeProcess`,
`mboRules`, `beforeMboData`/`afterMboData`, `changeStatus`) and outbound, OS query
(`OSQUERY.<os>.<name>` + a where clause + `sqp:` params), OS action, publish event
filters/exits (`PUBLISH.<channel>...`), enterprise/invoke/endpoint exits, REST
handler (query params), role (`MAXROLE.<name>`), MXException, and formula scripts
(supply `param[0]`, `param[1]`, …). For XML/JSON-driven points (inbound, exits),
use **Select File** to load a sample message.

---

## Logging & debugging

- **Logger**: the `autoscript` logger drives script logging; default level
  **ERROR** (per script, settable on creation or in the app). For `print` /
  framework traces to appear, set `autoscript` to **INFO** (or **DEBUG** to see
  variable values passed in, launch point + script name, and **execution time**,
  which Maximo always logs in ms).
- **Per-script logger**: create a logger named after the script (e.g. `ABCD`) and
  set just it to INFO — real-time logs for that one script, silence for the rest.
- **`service.log(...)` beats `print`**: real-time, language-agnostic, shows in the
  Test dialog. `print` only flushes after the script ends and only if the logger
  level matches.
- **Dedicated file**: Logging app → Manage Appenders → new `MXFileAppender`
  (e.g. `autoscript.log`), then point the `autoscript` logger at only that appender.
- **No IDE breakpoint debugging** is officially supported (Nashorn remote debug
  via IntelliJ exists but is unverified).
- **Take the script out of the equation**: deactivate the launch point and re-run
  the scenario — if the behavior changes, the script owns it.

```python
print "iplr=" + iplr          # needs autoscript=INFO, not real-time
service.log("in Asset " + mbo.getString("assetnum"))   # preferred, real-time
```

---

## Best practices & performance checklist

Scripting is Maximo custom code — follow the same performance discipline.

1. **Pick the cheapest launch point.**
   - Attribute *Init Value* over Object *Init* for field defaults — the framework
     runs it **only when the attribute is referenced** (Object Init runs for every
     MBO selected, e.g. the List tab):
     ```python
     if priority is not None: thisvalue = 2 * priority
     ```
   - Publish-channel **Event Filter** over a **User Exit** to skip outbound
     messages — the exit runs *after* serialization (you've already paid the cost).
   - Filter inbound integration in `beforeProcess(ctx)` (before MBO work).
2. **Guard costly Object-init work to the Main tab** (skip it for List/bulk):
   The `app` implicit has three states: `None` (non-UI), a unicode string of the
   application name (list-tab load), and an app object with `isFromListTab()` (detail-tab).
   `app is not None` is insufficient — a string passes it. Do not import `UIContext`;
   those import paths are unreliable across Maximo versions. Use `hasattr` instead:
   ```python
   is_list_tab = hasattr(app, 'isFromListTab') and app.isFromListTab()
   if not is_list_tab:
       ...costly init...
   ```
   The structural fix is to migrate to an Attribute Init Value LP (see PERF-02).
3. **Cache `count()`** — it fires SQL each call; store it in a var.
4. **Don't `save()` mid-transaction**; enlist externally-created sets with
   `mbo.getMXTransaction().add(set)` so they ride the encompassing transaction.
5. **Close sets you created** via `MXServer...getMboSet(...)` in a `finally:` block
   (`set.cleanup()`) — leaks lead to OOM. Related sets are auto-released.
6. **One script per launch-point event where possible** — multiple scripts on the
   same event run in **unordered** fashion; don't build ordering dependencies.
7. **Guard expensive log arguments**: `if service.isLoggingEnabled():` (7.6.1.2+)
   or check `MXLoggerFactory.getLogger("maximo.script").isDebugEnabled()`.
8. **Nashorn, not the Mozilla compatibility shim** — the shim is slow on Java 8.
9. **Real-time errors** (`service.error`) over the deprecated
   `errorkey`/`errorgroup` flags (which don't stop execution and fire late).
10. **Respect read-only/validation deliberately** — use the binding metadata flags
    or `MboConstants` (`NOACCESSCHECK`/`NOVALIDATION`) intentionally, not as a
    blanket workaround.

---

See **scripting-launchpoints.md** (events + implicit vars per launch point),
**scripting-service-mbo-api.md** (`service`/MBO API, transactions), and
**scripting-rest-integration.md** (REST/MIF script points). For loading/querying
the data these scripts act on, see data-model-loading.md and query-cookbook.md.
