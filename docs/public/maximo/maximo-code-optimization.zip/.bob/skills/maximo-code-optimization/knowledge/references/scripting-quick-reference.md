# Maximo Scripting — Quick Reference

Companion to the deep-dive references. Contains patterns and API snippets not
covered elsewhere.

See also:
- **scripting-launchpoints.md** — launch point types, variable bindings, implicit vars
- **scripting-service-mbo-api.md** — `service` API, MBO/MboSet API, MboConstants, transactions
- **scripting-test-debug.md** — Test dialog, logging setup, best-practices checklist
- **scripting-rest-integration.md** — REST handler, OS scripts, publish-channel exits, cron, MMI

---

## Field Flags (MboConstants)

Use these when calling `mbo.setValue(...)` directly. Apply deliberately — not as a
blanket bypass.

```python
from psdi.mbo import MboConstants

# Common flags
MboConstants.READONLY
MboConstants.REQUIRED
MboConstants.HIDDEN
MboConstants.NOVALIDATION    # skip the field's validate routine on set
MboConstants.NOACCESSCHECK   # set the value even if the attribute is read-only
MboConstants.NOACTION        # skip the field's action routine on set
MboConstants.DELAYVALIDATION # defer validation to the save point

# Usage — combine flags with |
mbo.setFieldFlag("FIELD", MboConstants.READONLY, True)
mbo.setFieldFlag("FIELD", MboConstants.REQUIRED, False)
mbo.setValue("REPLACEMENTCOST", value, mbo.NOACCESSCHECK)
mbo.setValue("DESCRIPTION", "x", mbo.NOACCESSCHECK | mbo.NOVALIDATION)
```

---

## Common Exceptions

### MXApplicationException — business-rule errors

```python
from psdi.util import MXApplicationException

# With message group and key
raise MXApplicationException("system", "requiredfield", ["FIELDNAME"])

# With custom message
raise MXApplicationException("custom", "custommessage")
```

Prefer `service.error(group, key)` / `service.error(group, key, params[])` in
scripts — it is real-time and stops execution immediately without a Java import.
Use `raise MXApplicationException(...)` only when you need finer control over the
exception chain.

### MXException — general Maximo exception

```python
from psdi.util import MXException

raise MXException("system", "error")
```

---

## Date/Time Operations

```python
from psdi.server import MXServer
from java.util import Calendar

mx = MXServer.getMXServer()

# Current date/time
currentDate = mx.getDate()

# Date arithmetic
calendar = Calendar.getInstance()
calendar.setTime(currentDate)
calendar.add(Calendar.DAY_OF_MONTH, 7)   # add 7 days
futureDate = calendar.getTime()

# Set on MBO
mbo.setValue("DATEFIELD", currentDate)
mbo.setValue("TARGETFINISH", futureDate)
```

---

## String Operations

```python
# Get string (may return None — always guard before calling string methods)
value = mbo.getString("FIELD")

# Null guard before string operations
if value:
    upper = value.upper()
    lower = value.lower()
    trimmed = value.strip()
    replaced = value.replace("old", "new")
    starts = value.startswith("PREFIX")

# Concatenation
result = "Value: " + str(value)

# Format
result = "Value: {0}, Count: {1}".format(value, count)
```

---

## Numeric Operations

```python
# Typed getters (return 0 / 0.0 on null — safer than getString for arithmetic)
intValue = mbo.getInt("FIELD")
doubleValue = mbo.getDouble("FIELD")

# When using getString for a number — guard against None and non-numeric
raw = mbo.getString("FIELD")
if raw is not None:
    try:
        num = int(raw)
        if 1 <= num <= 100:
            mbo.setValue("RESULT", num)
    except (ValueError, TypeError):
        service.error("system", "invalidnumber", ["FIELD"])
```

---

## Boolean Operations

```python
# Get boolean
boolValue = mbo.getBoolean("FIELD")

# Set boolean
mbo.setValue("FIELD", True)
mbo.setValue("FIELD", False)

# Compound condition
if mbo.getBoolean("ACTIVE") and not mbo.getBoolean("DELETED"):
    # process
```

---

## Lookup Operations

```python
from psdi.server import MXServer
from psdi.mbo import SqlFormat

mx = MXServer.getMXServer()

# Resolve a single value's description
domainSet = mx.getMboSet("ALNDOMAIN", mx.getSystemUserInfo())
sqlf = SqlFormat(domainSet)
sqlf.setObject("domainid", "ALNDOMAIN", "DOMAINID")
sqlf.setObject("value", "ALNDOMAIN", "VALUE")
domainSet.setWhere(sqlf.format("domainid = :1 and value = :2", ["MYDOMAINID", value]))
domainSet.reset()

description = None
if not domainSet.isEmpty():
    description = domainSet.getMbo(0).getString("DESCRIPTION")
domainSet.close()

# Get the full list of values for a domain
listSet = mx.getMboSet("ALNDOMAIN", mx.getSystemUserInfo())
listSet.setWhere("domainid = 'MYDOMAINID'")
listSet.reset()
values = [listSet.getMbo(i).getString("VALUE") for i in range(listSet.count())]
listSet.close()
```

---

## User Context

```python
from psdi.server import MXServer

mx = MXServer.getMXServer()
ui = mx.getSystemUserInfo()   # system user — use mbo.getUserInfo() for the session user

# Identity
username = ui.getUserName()
personId = ui.getPersonId()
defaultSite = ui.getDefaultSite()

# Permissions
hasAccess = ui.hasApplicationAccess("APPNAME")
hasSiteAccess = ui.hasSiteAccess("SITEID")

# Group membership
groups = ui.getUserGroups()
if "ADMINGROUP" in groups:
    pass  # user is in the admin group
```

---

## Transaction Management

Maximo manages the transaction automatically — do not call `save()` inside a
launch-point script unless you have explicitly obtained a separate set via
`MXServer.getMboSet(...)` and need to commit it.

```python
# MBOs reached via mbo or relationship sets are part of the encompassing
# transaction automatically — no save() needed.

# MBOs created via MXServer.getMboSet() are NOT enlisted automatically.
# Enlist them so they save/roll back with the transaction:
mbo.getMXTransaction().add(newSet)

# Only call save() on a server-created set when you specifically need it
# committed independently:
newSet.save()

# Rollback (rare — usually let Maximo handle this via exception propagation)
newSet.rollback()
```

---

## Performance Metrics (target thresholds)

These are reference targets, not hard limits. Use them to flag scripts that may
need profiling.

| Script type | Target execution time |
|-------------|----------------------|
| Object LP (Init, Save) | < 500 ms |
| Attribute LP | < 200 ms |
| Action LP | < 2 s |
| Cron/Escalation script | < 5 min |

| Resource | Target |
|----------|--------|
| Single query | < 100 ms |
| Max rows per query | ≤ 1 000 (use `setMaxRows`) |
| Concurrent open MboSets | < 10 |
| Memory per script execution | < 100 MB |

---

## Testing Checklist

### Security
- [ ] Test WHERE clauses with SQL injection patterns (`' OR '1'='1`, `'; DROP TABLE ...`)
- [ ] Test with null/empty inputs
- [ ] Test with invalid data types
- [ ] Test with special characters: `< > ' " & ;`
- [ ] Test with an unauthorized user (no app access)

### Performance
- [ ] Test with 10 records
- [ ] Test with 100 records
- [ ] Test with 1 000 records
- [ ] Measure execution time via `autoscript` DEBUG log (reports ms)
- [ ] Confirm `count()` is called at most once per set

### Error handling
- [ ] Test with missing required fields
- [ ] Test with invalid relationships (broken FK)
- [ ] Verify error messages shown to users are generic (no stack traces)
- [ ] Confirm all `MXServer.getMboSet(...)` sets are closed in `finally`

---

## Severity Levels

| Level | Examples |
|-------|---------|
| **CRITICAL** | SQL injection (SEC-01), hardcoded credentials over HTTP (SEC-02), Python 2 `print` statement (SYN-01 — syntax error), unclosed server-created MboSet (RES-01 — cursor leak) |
| **HIGH** | Missing null guard on `getString()` result before string method/arithmetic (NULL-01/NULL-02), synonym-domain `getString()` comparison instead of `_internal` var (NULL-04), resource leak on error path, deprecated `errorgroup`/`errorkey` pattern (ERR-01), `importPackage` under Nashorn (API-01), missing try/catch around HTTP calls (ERR-02), HashMap `invokeScript` pattern (API-02), Object Init runs unconditionally (PERF-02), Publish Channel User Exit instead of Event Filter (ARCH-01) |
| **MEDIUM** | `service.log()` as sole logging — use `MXLoggerFactory` (LOG-01), missing guard on optional API return (NULL-03), no guard on empty API response (PERF-03) |
| **LOW** | Code readability issues, missing comments, inconsistent naming, minor non-functional optimizations |
