# Maximo — Automation Scripting: the `service` var, MBO API, library scripts (reference)

The implicit `service` object (a `com.ibm.tivoli.maximo.script.ScriptService`) is
available in **every** script. **Reach for it first** — it wraps error/warning,
logging, HTTP, MIF, and library-script calls so you avoid Java imports and
non-real-time error flags. (In MIF Object-Structure scripts it arrives as `ctx`,
an extended `service`.)

> **Golden rule.** Prefer `service.error(...)` / `service.setWarning(...)` over the
> deprecated `errorkey`/`errorgroup` implicit vars. Prefer the variable-binding
> metadata flags or `MboConstants` over fighting read-only attributes.
>
> **`errorgroup`/`errorkey` never halt execution — not even close.** These are plain variable assignments. The Maximo framework reads them only *after the entire script finishes*. Code below them always runs — unconditionally, with no exception-catching required.
>
> **`service.error()` is a throw, not a `return`.** It raises `MXApplicationException` and unwinds the call stack, which terminates normal launch-point execution. But it is **not a syntactic gate** — code below it is not structurally unreachable. Two specific scenarios cause fall-through past a `service.error()` call:
>
> 1. **A broad `except` in the call chain catches it.** `MXApplicationException` is not a `TypeError` or `ValueError` — narrowly-typed excepts won't catch it. A bare `except:` or `except Exception:` anywhere between the call and the Maximo framework boundary will swallow it, and execution resumes on the next line.
> 2. **Some after-commit contexts.** Community reports indicate that in some after-commit phases `service.error()` does not interrupt execution or surface the message. This is not confirmed in IBM documentation — treat it as unreliable in after-commit contexts rather than assume a specific mechanism.
>
> Always structure guards as `if/else` so downstream code is unreachable by structure, not just by relying on exception propagation.

---

## `service` function catalog

### JSON
| Function | In → Out |
|----------|----------|
| `jsonToString` / `jsonarrayToString` | JSONObject/JSONArray → String |
| `tojsonobject` / `tojsonarray` | String → JSONObject/JSONArray |

### Errors & warnings (real-time)
| Function | Effect |
|----------|--------|
| `error(group, key)` / `error(group, key, params[])` | throw a translated MXException — unwinds the call stack |
| `setWarning(group, key, params[])` | add a warning to `mbo.getThisMboSet()` (shown by REST/classic UI) |
| `yncerror(group, key[, params[]])` | throw MXApplicationYesNoCancelException |
| `yncuserinput()` | returns the user's choice (`service.YNC_YES/NO/NULL`) |

```python
service.error("po", "novendor")                 # throws — unwinds the call stack
service.setWarning("po", "nolines", None)        # non-blocking warning

# DEPRECATED — plain variable assignments, NOT guards. Code below always runs.
# errorgroup = "po"
# errorkey   = "nolines"
```

**Structural pattern for guards — always use `if/else`, never rely on propagation:**
```python
# WRONG — flat guard: a bare except:/except Exception: anywhere in the call chain
#         swallows MXApplicationException and resumes execution on the next line
if not assetnum:
    service.error("asset", "invalidassetnum")
process(assetnum)   # executes if exception is swallowed

# CORRECT — structurally unreachable regardless of exception handling
if not assetnum:
    service.error("asset", "invalidassetnum")
else:
    process(assetnum)   # only runs when assetnum is set
```

Alternatives (lower-level): `from psdi.util import MXApplicationException; raise
MXApplicationException(group, key, params)`.

### Logging (use the script logger, real-time)
`log(msg)` (DEBUG/INFO per script setting), plus `log_debug/info/warn/error/fatal`
(each also takes a `Throwable`). **`print` is not real-time** — it flushes only
after the script ends and only if the `autoscript` logger is at the matching
level; prefer `service.log(...)`. Guard expensive log args:
```python
if service.isLoggingEnabled():        # 7.6.1.2+
  service.log("count of mbos " + str(mboset.count()))
```

### HTTP & MIF
| Function | Notes |
|----------|-------|
| `httpget(url)` / `httpget(url, user, pwd)` | GET → String (string/null responses only) |
| `httppost(url, data)` / `httppost(url, user, pwd, data)` | POST → String |
| `httpgetasjson(url, user, headers, pwd)` | GET → JSON. `headers` = `"h1:v1,h2:v2"` |
| `httppostasjson(url, user, pwd, jsonData)` | POST JSON → JSON |
| `httpgetasbytes` / `httppostasbytes` | byte[] variants |
| `invokeEndpoint(endpoint, metaMap, data)` | call any MIF endpoint (String or byte[]) |
| `invokeChannel(channelName)` | fire a MIF invoke channel using the context `mbo` |
| `raiseSkipTransaction()` | MXException iface#SKIP_TRANSACTION — skip an inbound/outbound message |

### Classic UI
`closeDialog()`, `openURL(url, newWindow)`, `launchDialog("dialogid")`.

### Library scripts
| Function | Returns |
|----------|---------|
| `invokeScript(name, contextMap)` | void — pass/recover values via the Map |
| `invokeScript(name)` | Map<String,Object> — the invoked script's context |
| `invokeScript(name, funcName, args[])` | the function's return value |

---

## Library scripts (reusable logic, no launch point)

Two styles. The function-based style (preferred) needs **"Allow Invoking Script
Functions" enabled at creation** (cannot be changed later):

```python
# Library script CALC (function-based)
def mult(a, b): return a * b
def add(a, b):  return a + b
```
```python
# Caller — clean, no java Map plumbing
res = service.invokeScript("CALC", "mult", [2, 3])
```
Legacy Map style (works without the flag, but verbose):
```python
from java.util import HashMap
map = HashMap(); map.put("a", 2); map.put("b", 3)
service.invokeScript("CALC", map)
res = map.get("r")
```
Library scripts are stored/compiled/cached like any other script.

**Library script control-flow rules:**

1. **`service` availability.** When a library script is invoked via `service.invokeScript(name, map)`, the framework forwards `service` into the child binding automatically. However, if invoked by lower-level reflection or from an unusual context, `service` may not be bound. Calling `service.error(...)` in that case raises `NameError`. For library scripts meant to be called from arbitrary or unknown contexts, add an explicit `raise` after `service.error()` as a belt-and-suspenders fallback:
   ```python
   if a is None:
       if 'service' in dir():
           service.error("calc", "nullinput")
       raise ValueError("CALC: input 'a' is None")  # always aborts
   ```

2. **No `return` at top level.** Library scripts executing via the map/variable style are top-level Jython code, not functions. There is no `return` statement available to exit early. Use `if/else` to make later code structurally unreachable instead of relying on `service.error()` propagation to skip it.

3. **Function-based style is cleaner.** With "Allow Invoking Script Functions" enabled, define logic inside named functions — `return` works normally, guards are straightforward, and callers get the result directly without a shared mutable map:
   ```python
   # Library script body (function-based)
   def calc(op, a, b):
       if a is None or b is None:
           raise ValueError("CALC: null input")
       if op == "multiply": return float(a) * float(b)
       if op == "add":      return float(a) + float(b)
       raise ValueError("CALC: unknown op: " + str(op))
   ```
   ```python
   # Caller
   result = service.invokeScript("CALC", "calc", ["multiply", 2, 3])
   ```

---

## MBO / MboSet API essentials (Jython)

The implicit `mbo` is a `psdi.mbo.Mbo`; relationships and sets give you the rest.

```python
mbo.getString("status"); mbo.getInt("priority"); mbo.getDouble("totalcost")
mbo.getBoolean("taxed"); mbo.getDate("reportdate")
mbo.isNull("vendor"); mbo.isModified("status"); mbo.toBeAdded()
mbo.setValue("description", "x")
mbo.setValueNull("assetnum")
mbo.setFieldFlag(MboConstants.READONLY, True)            # whole MBO
mbo.setFieldFlag("vendor", MboConstants.READONLY, True)  # one attribute
mbo.getOwner()                       # parent MBO (or None)
relSet = mbo.getMboSet("RELATION")   # related set via a defined relationship
relSet.count(); relSet.moveFirst(); relSet.moveNext(); relSet.add()
relSet.sum("quantity")
mbo.getThisMboSet()                  # the set this mbo belongs to
```

Server / arbitrary sets (outside the relationship graph):
```python
from psdi.server import MXServer
s = MXServer.getMXServer().getMboSet("MAXUSER", userInfo)   # or runAsUserInfo in cron
s.setQbe("userid", userInfo.getUserName()); s.setQbeExactMatch(True)
m = s.moveFirst()
```

### MboConstants — set flags by name, not magic numbers
`MboConstants` is mixed into every MBO, so `mbo.NOACCESSCHECK` etc. work without
an import; combine with `|`.
```python
from psdi.mbo import MboConstants                  # (optional — also on mbo.*)
mbo.setValue("DESCRIPTION", "x", mbo.NOACCESSCHECK)             # set even if readonly
mbo.setValue("DESCRIPTION", "x", mbo.NOACCESSCHECK | mbo.NOVALIDATION)
```
Common flags: `NOACCESSCHECK` (ignore readonly), `NOVALIDATION` (skip validate),
`NOACTION` (skip action), `DELAYVALIDATION`, `NOSETVALUE`, `READONLY`.

### Synonym domains / internal values
For status-like (synonym-domain) attributes, compare the **internal** value, not
the localized display value. Either bind a var and use its `_internal` derived
var, or translate explicitly:
```python
from psdi.server import MXServer
atype = MXServer.getMXServer().getMaximoDD().getTranslator() \
          .toInternalString('ASSETTYPE', mbo.getString('assettype'))
```

---

## Transaction & lifecycle hygiene (avoid the classic foot-guns)

- **Don't `save()` mid-transaction.** Let your MBO changes ride the encompassing
  transaction. MBOs you reach via `mbo`/related sets are already part of it; MBOs
  created via `MXServer...getMboSet(...)` are **not** — enlist them:
  ```python
  mbo.getMXTransaction().add(newMboSet)
  ```
- **Close sets you created yourself.** Related sets are auto-released; sets from
  `MXServer...getMboSet(...)` are your responsibility or you leak → OOM:
  ```python
  try:
    ...
  finally:
    myset.cleanup()
  ```
- **Cache `count()`** — each call fires SQL:
  ```python
  cnt = mboset.count()
  if cnt <= 1: service.log("skipping, count=" + str(cnt))
  ```
- One launch-point event can have **multiple scripts with no guaranteed order**
  (the event topic is unordered). Combine them or remove cross-script ordering
  dependencies.

See **scripting-launchpoints.md** for which `mbo`/`mboset`/derived vars exist per
launch point, and **scripting-test-debug.md** for logging setup, the Test dialog,
and the full performance checklist.
