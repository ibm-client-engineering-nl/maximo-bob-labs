# Maximo — Automation Scripting: launch points & variables (reference)

Server-side customization that runs **inside** Maximo when a target event fires —
no Java, no EAR rebuild, no downtime. Scripts + their config live in the DB and
are compiled to JVM bytecode and cached; a save recompiles and propagates to all
JVMs in the cluster. **Script execution stops on the first error**, and runs in
the same thread as the triggering business logic — a slow script slows the app.

> **Golden rule — confirm the launch point and event against the running
> instance.** Available events, object/attribute names, message groups, and which
> implicit variables are injected depend on the deployment + version. Author and
> verify in the **Automation Scripts** app (`GoTo → System Configuration →
> Autoscript`) and use its **Test** button (see scripting-test-debug.md) before
> wiring a script to a live event.

---

## Engine & languages

- Based on **JSR-223**. Out of the box: **Nashorn (JavaScript)** (ships with the
  JDK) and **Jython 2.7.2** (ships with Maximo). Both compile to bytecode.
  Jython is referred to as both `Jython` and `Python`.
- Other JSR-223 engines (Groovy, JRuby) can be added to the classpath but are
  **not tested/supported** by IBM — expect issues.
- Examples in IBM's docs are mostly Jython (py); JS is used where native JSON
  parsing helps. Pick one and be consistent within a script.

## Script artifacts & creation

Create via wizards from the **List** tab → drop-down actions in the Automation
Scripts app: vanilla (no launch point), Object LP, Attribute LP, Action LP,
custom Condition LP, or Integration. A script can carry **one or more launch
points but they must all be the same type** (first association fixes the type).

Activate/deactivate from the **Launch Point** tab (per launch point) or the
**Main** page (whole script). A deactivated script is **not invoked** — the
fastest way to take a customization out of the equation while debugging. (The
`autoscript` *status* attribute has no effect on invocation.)

## Variables & bindings

Scripts talk to Maximo through **variables**:

- **IN** = pass-by-value (script changes don't propagate out). **INOUT / OUT** =
  pass-by-reference (script can set them back to the MBO).
- Bind a variable to an **MBO attribute**, a **maxvar**, a **system property**,
  or a **literal**. Maxvar/system-property bindings are always IN **String**.
  Literal types: ALN, INTEGER, SMALLINT, DECIMAL, YORN, DATETIME, FLOAT
  (`literaldatatype` in `autoscriptvars`).
- A var bound to an MBO attribute inherits that attribute's datatype.
- **Array binding**: suffix the bind with `*` (e.g. `sparepart.quantity*`) to get
  an array across a relationship. Array vars are always IN.
- Bindings can be set at script level or overridden at launch-point level (if
  allowed).

**Attribute-set flags** (binding metadata, for OUT/INOUT attribute bindings):

| Flag | Effect when true |
|------|------------------|
| Suppress Validation (`NOVALIDATION`) | skip the field's *validate* routine on set |
| Suppress Action (`NOACTION`) | skip the field's *action* routine on set |
| Suppress Access Control (`NOACCESSCHECK`) | set the value even if the attribute is read-only |

## Implicit variables (injected by the framework — no declaration needed)

| Name | Type | Meaning |
|------|------|---------|
| `service` | ScriptService | the global helper — error/warn/log/HTTP/MIF/library invoke (see scripting-service-mbo-api.md). **Use this first.** |
| `mbo` | psdi.mbo.Mbo | the current MBO in context (event MBO / attribute owner / action MBO) |
| `mboset` | MboSetRemote | the set in context (e.g. for *can add*, virtual-MBO setup) |
| `mboname`, `app`, `user` | String | current MBO name, initiating app, initiating userid |
| `interactive` | boolean | true = UI/interactive session, false = background (e.g. integration). `= userInfo.isInteractive()` |
| `onadd` / `onupdate` / `ondelete` | boolean | state of the MBO (most useful in Object LP) |
| `evalresult` | boolean (OUT) | result of a condition / publish-channel event filter |
| `scriptName`, `launchPoint` | String | names of the executing script / launch point |
| `action` | String | the Action name (Action LP) |
| `wfinstance` | WFInstance | workflow instance (Action LP launched from workflow) |
| `errorkey`/`errorgroup` | String | **deprecated** error mechanism — use `service.error(...)` instead |
| `listMboSet`, `srcKeys`, `targetKeys` | — | lookup scripts (Attribute LP – Retrieve List) |

**Implicit vars derived from an explicit MBO-attribute var `var`:**
`var_required`, `var_readonly`, `var_hidden` (settable if OUT/INOUT),
`var_internal` (synonym-domain internal/maxvalue), `var_previous` (attribute LP,
pre-change value), `var_initial`, `var_modified`. Setting `var_readonly = True`
makes the bound attribute read-only — no MBO API needed.

---

## Launch point catalog

### Object launch point (MBO lifecycle)
Listens to init / save / add / update / delete plus the pre-events *can add* and
*can delete*. Access via `mbo` (and `mboset`).

| Event | Use for |
|-------|---------|
| **Initialize** | calculated/non-persistent fields, conditional defaults, set readonly/required/hidden. *Costly inits → prefer an Attribute *Init Value* LP (just-in-time).* |
| **App Validate** | full-object validation. **Preferred over Before Save for validation** — framework calls validate even when Before Save isn't. |
| **Save → On Add / On Update / On Delete** | save-point business logic. On Delete is for *logic on delete*, not for *preventing* delete. |
| **Before / After Save / After Commit** | After Save = SQL issued, not committed (good for external writes you can still roll back). After Commit = data is durable (good for SMS/email/notify). |
| **Allow Object Creation (Can Add)** | reject an add before the MBO exists — only `mboset` is available, not `mbo`. |
| **Can Delete** | reject a delete — `mbo` exists here. |

```python
# Init: calculated read-only field from a related set (qtys bound to sparepart.quantity*)
sptqt_readonly = True
if qtys is not None:
  sptqt = sum(qtys)

# On Add: enforce assetnum prefix by assettype (real-time error)
if atype_internal == 'FLEET' and not anum.startswith('FL'):
  service.error('asset', 'invalidassetprefix', ['FL'])

# Can Add: block POLINE unless PO has a vendor (no `mbo` yet - use `mboset`)
if mboset.getOwner() is not None and mboset.getOwner().getName() == "PO" and mboset.getOwner().isNull("vendor"):
  service.error("po", "novendor_noline")
```

**Non-persistent (virtual) MBOs**: the Object init event gives an `onsetup`
callback to fill the set, and save/add maps to the `execute` callback (e.g.
validate a change-status dialog MBO like `ASCHANGESTATUS`). The `setup` callback
is off by default — enable with property `mxe.script.callsetuponinit=1` and
refresh the script cache.

### Attribute launch point (field-level)
Customizes a single attribute's **validate / action / init / init value /
retrieve list (lookup)** events. The attribute is injected as a lowercase-named
implicit var; `<attr>_previous` gives the pre-change value; `thisvalue` (and
`thisvalue_required/_readonly/_hidden`, `lookupname`) are used in the Init events.

```python
# Validate: cap a value
if purchaseprice > 200:
  service.error("some", "error")

# Action: drive required-flag + a calculated sibling (vend_required, rc are derived/OUT vars)
if purchaseprice >= 100:
  vend_required = True
else:
  vend_required = False
  rc = purchaseprice / 2
```

**Lookups (Retrieve List event)** — build a list MBOSet and map keys. Enough for
REST (`GET ...?getlist~attr`) but classic UI also needs `lookups.xml` + presentation
wiring:
```javascript
var jsonResp = service.httpget("..url..","..user..","..pwd..");
var countries = JSON.parse(jsonResp);
var countriesSet = Packages.psdi.server.MXServer.getMXServer().getMboSet("COUNTRY", userInfo);
for (var c in countries) { var m = countriesSet.add(); m.setValue("name", c); m.setValue("description", countries[c]); }
listMboSet = countriesSet;  srcKeys = ["NAME"];  targetKeys = ["ADDRESS5"];
```

### Action launch point
Scripts a custom **Action** invokable by Escalations, Workflow, UI menus/buttons.
The wizard creates the Action; **you** must attach it (e.g. to an escalation with
a condition). Object is optional — without it you can't bind MBO-attribute vars
(use literal/maxvar/system-property bindings, or the MBO APIs directly). Common
pattern: an escalation runs the scripted Action over a filtered MboSet to compute
meter values, statuses, etc.

### Custom condition launch point
Returns a boolean `evalresult` for Workflow conditions / Conditional UI.
```python
if vend is not None and qtys is not None and sum(qtys) > 10:
  evalresult = True
```
Wire it in the **workflow condition node**: set node title to
`scriptname:launchpointname` (or just `scriptname` if single LP — **10-char title
limit**, so keep both names ≤ 4 chars), condition type = custom, class =
`com.ibm.tivoli.maximo.script.ScriptCustomCondition`.

---

## Special named scripts (no launch point)

These are recognized by **naming convention** — create a vanilla script with the
exact name. (REST-callable and integration variants live in
scripting-rest-integration.md.)

| Name pattern | Fires when | Key vars | Use for |
|--------------|-----------|----------|---------|
| `OBJECT.NEW` | a new record is created (once) | `mbo` | conditional defaults you can't do in DB Config. One per object (views need one per base object). Prefer over Init events (fires once). |
| `OBJECT.DUPLICATE` | `duplicate()`/`copy()` on the MBO, **before** child sets copy | `mbo` (orig), `dupmbo` (new) | clear/seed values; copy custom child sets |
| `OBJECT.AFTERDUPLICATE` | after all duplication (DataBean / REST duplicate only — **not** `mbo.duplicate()` in script) | `mbo`, `dupmbo` | post-copy fixups on already-copied children |
| relation where = `script:<name>` | `mbo.getMboSet("relation")` resolves a "smart" relation | `mbo` (source), `mboset` (script must create it) | conditional/dynamic where clauses; `ctx`-driven filtering via API |
| `MAXROLE.<ROLENAME>` | a custom Role (class `com.ibm.tivoli.maximo.script.ScriptCustomRole`) resolves | `ctx` (ScriptRoleContext) | resolve a role to person(s)/email(s) with complex logic — declare `evalToPerson(ctx)` / `evalToEmail(ctx)`. **Must enable "Allow invoking script functions" at creation — cannot change later.** |
| `MXERR.<group>.<key>` | the matching MXException is **instantiated** | `egroup`,`ekey`,`eparams` (IN), `mxerrormsg` (OUT) | append context to a message; alert an admin |

```python
# OBJECT.NEW - default a field from the owner header
owner = mbo.getOwner()
if owner and owner.getName() == "PO":
  mbo.setValue("CUSTOMFIELD", owner.getString("CUSTOMFIELD"))

# OBJECT.DUPLICATE - clear a field and copy a custom child set
dupmbo.setValueNull("ASSETNUM")
mbo.getMboSet("MYCUSTOMRELATIONSHIP").copy(dupmbo.getMboSet("MYCUSTOMRELATIONSHIP"))

# MAXROLE.<name> - resolve to a person group by site
def evalToPerson(ctx):
  mbo = ctx.getMbo()
  grp = 'TIER1' if mbo.getString("SITEID") == "BEDFORD" else 'TIER2'
  s = mbo.getMboSet("$EMXPERSONGROUP", "PERSONGROUP", "persongroup='%s'" % grp)
  ctx.setPersonOrGroupMbo(s.moveFirst())
```

## UI interactions (classic UI, Action LP)

- `service.closeDialog()` — close a dialog after a scripted Action (7.6.1.0+).
- `service.launchDialog("dialogid")` — open a dialog from a scripted Action (7.6.1.1+).
- **YNC (Yes/No/Cancel)**: define an informational message with Y/N buttons, then
  branch on `service.yncuserinput()` against `service.YNC_NULL/YNC_YES/YNC_NO`;
  raise the prompt with `service.yncerror(group, key, params)`.

## Formula functions
Extend the Maximo Formula library with a scripted function. Register it (Formula
Functions, impl type = script, class/name = SCRIPT NAME in uppercase) then use in
an object/attribute formula. Implicit vars: `exp`, `ctx`, `mbo`, `params`; return
via `evalresult`. Test via REST: `oslc.select=...,exp.<formulaname>`.

---

See also: **scripting-service-mbo-api.md** (the `service` var, MBO/MboSet API,
MboConstants, library scripts, errors/warnings) ·
**scripting-rest-integration.md** (REST-callable scripts, OS query/action/select,
inbound/outbound OS processing, publish-channel & endpoint exits, cron, MMI) ·
**scripting-test-debug.md** (Test dialog, object path, logging, best practices).
