# Maximo Script Optimization Knowledge Base Index

## Overview

This knowledge base provides comprehensive guidance for optimizing IBM Maximo automation scripts. It covers security, performance, error handling, and code quality best practices.

## Quick Start

**New to Maximo scripting?** Start here:
1. [Maximo Scripting Fundamentals](core/maximo-scripting-fundamentals.md)
2. [Quick Reference](references/scripting-quick-reference.md)
3. [Optimization Example](../examples/optimization-example.md)

**Optimizing existing scripts?** Follow this path:
1. [Script Optimization Workflow](procedures/script-optimization-workflow.md)
2. [Security Best Practices](core/security-best-practices.md)
3. [Performance Optimization](core/performance-optimization.md)
4. [Common Issues](troubleshooting/common-issues.md)

## Core Knowledge

### Fundamentals
- **[Maximo Scripting Fundamentals](core/maximo-scripting-fundamentals.md)**
  - Script types (Object, Attribute, Action, Escalation, Custom Condition)
  - Core Maximo APIs (MBO, MboSet, MXServer, MXLoggerFactory)
  - Execution context and script variables
  - Common patterns and best practices
  - Performance considerations
  - Security fundamentals

### Security
- **[Security Best Practices](core/security-best-practices.md)**
  - SQL injection prevention (CRITICAL)
  - Input validation patterns
  - Access control implementation
  - Sensitive data protection
  - Error message security
  - Common vulnerability patterns
  - Security testing guidelines

### Performance
- **[Performance Optimization](core/performance-optimization.md)**
  - Database query optimization
  - Resource management strategies
  - Loop optimization techniques
  - String operation efficiency
  - Caching strategies
  - Batch processing patterns
  - Performance monitoring
  - Anti-patterns to avoid

## Procedures

### Optimization Workflow
- **[Script Optimization Workflow](procedures/script-optimization-workflow.md)**
  - Phase 1: Initial Assessment
  - Phase 2: Security Analysis
  - Phase 3: Resource Management Analysis
  - Phase 4: Error Handling Analysis
  - Phase 5: Performance Analysis
  - Phase 6: Code Quality Analysis
  - Optimization report template
  - Best practices checklist

## Reference Materials

### Quick Reference
- **[Quick Reference Guide](references/scripting-quick-reference.md)**
  - Field flags (MboConstants)
  - Common exceptions (MXApplicationException, MXException)
  - Date/Time, String, Numeric, Boolean, Lookup operations
  - User context (permissions, groups)
  - Transaction management
  - Performance target thresholds
  - Severity levels (Critical → Low)
  - Testing checklist (security, performance, error)

### Scripting Deep-Dive References
- **[Launch Points & Variables](references/scripting-launchpoints.md)**
  - Engine & languages (Nashorn / Jython)
  - Script artifacts, activation, variable bindings and attribute-set flags
  - Full implicit-variable catalog (service, mbo, mboset, derived vars)
  - Object, Attribute, Action, Custom Condition launch points with examples
  - Special named scripts (OBJECT.NEW, OBJECT.DUPLICATE, MAXROLE, MXERR)
  - UI interactions (closeDialog, launchDialog, YNC pattern)
  - Formula functions

- **[REST & Integration Scripting](references/scripting-rest-integration.md)**
  - Script Handler — calling scripts directly over REST (`/api/script/<NAME>`)
  - OS Query, OS Action, REST select-attribute scripts
  - OS inbound/outbound processing (MIF, REST, app import)
  - Publish-channel Event Filter, External Exit, User Exit scripts
  - Endpoint / handler exit scripts (HTTP, WS, JMS transports)
  - Cron-task scripts
  - MMI (Maximo Management Interface) scripts

- **[`service` Var, MBO API & Library Scripts](references/scripting-service-mbo-api.md)**
  - Full `service` function catalog (JSON, errors/warnings, logging, HTTP/MIF, classic UI, library scripts)
  - Library script patterns (function-based and Map styles)
  - MBO / MboSet API essentials (getters, setters, relationships, counts)
  - MboConstants flag reference (NOACCESSCHECK, NOVALIDATION, NOACTION, etc.)
  - Synonym domain / internal-value translation
  - Transaction & lifecycle hygiene (save, enlist, cleanup, ordering)

- **[Test, Debug & Best Practices](references/scripting-test-debug.md)**
  - Test dialog — Object Path syntax, Set Attribute Value, Process Log
  - Logging setup (autoscript logger, per-script logger, dedicated appender)
  - `service.log(...)` vs `print` — real-time vs deferred
  - Performance checklist (10 rules: cheapest LP, guard init, cache count, etc.)

## Troubleshooting

### Common Issues
- **[Common Issues and Solutions](troubleshooting/common-issues.md)**
  - Security issues (SQL injection, missing validation, access control)
  - Resource management issues (unclosed MboSets, leaks, connection issues)
  - Error handling issues (missing exceptions, no logging, exposed details)
  - Performance issues (N+1 queries, no WHERE clause, inefficient operations)
  - Logic issues (missing null checks, incorrect conditions, redundant checks)
  - Common error messages and their solutions
  - Debugging tips and prevention checklist

## Examples

### Complete Optimization Example
- **[Optimization Example](../examples/optimization-example.md)**
  - Original problematic script
  - Issues identified (10 issues across all severity levels)
  - Detailed optimization report
  - Optimized script with all fixes
  - Performance comparison (60% improvement)
  - Testing recommendations
  - Deployment checklist
  - Lessons learned

## Knowledge Organization

### By Topic

#### Security
- [Security Best Practices](core/security-best-practices.md)
- [SQL Injection Prevention](core/security-best-practices.md#sql-injection-vulnerabilities)
- [Input Validation](core/security-best-practices.md#input-validation)
- [Access Control](core/security-best-practices.md#access-control)

#### Performance
- [Performance Optimization](core/performance-optimization.md)
- [Database Query Optimization](core/performance-optimization.md#minimize-database-queries)
- [Resource Management](core/performance-optimization.md#resource-management)
- [Loop Optimization](core/performance-optimization.md#loop-optimization)

#### Error Handling
- [Error Handling Patterns](core/maximo-scripting-fundamentals.md#error-handling)
- [Logging Best Practices](core/maximo-scripting-fundamentals.md#mxloggerfactory)
- [Exception Handling](troubleshooting/common-issues.md#error-handling-issues)

#### Code Quality
- [Code Quality Standards](procedures/script-optimization-workflow.md#phase-6-code-quality-analysis)
- [Null Safety](troubleshooting/common-issues.md#issue-14-missing-null-checks)
- [Logic Validation](procedures/script-optimization-workflow.md#step-62-logic-validation)

### By Severity

#### Critical Issues
- [SQL Injection](core/security-best-practices.md#sql-injection-vulnerabilities)
- [Hardcoded Credentials](core/security-best-practices.md#sensitive-data-protection)
- [Resource Leaks](core/performance-optimization.md#always-close-mbosets)

#### High Issues
- [Unclosed MboSets](troubleshooting/common-issues.md#issue-4-mboset-not-closed)
- [Missing Error Handling](troubleshooting/common-issues.md#issue-7-missing-exception-handling)
- [N+1 Query Problems](troubleshooting/common-issues.md#issue-10-n1-query-problem)
- [Null Safety — getString() in string method without guard (NULL-01)](references/scripting-quick-reference.md#severity-levels)
- [Null Safety — arithmetic on getString()/getDouble() that may be None (NULL-02)](references/scripting-quick-reference.md#severity-levels)

#### Medium Issues
- [Missing Input Validation](troubleshooting/common-issues.md#issue-2-missing-input-validation)
- [Inefficient Queries](troubleshooting/common-issues.md#issue-11-no-where-clause)
- [No Logging](troubleshooting/common-issues.md#issue-8-no-logging)
- [Null Safety — optional API return used without guard (NULL-03)](references/scripting-quick-reference.md#severity-levels)

#### Low Issues
- [Code Readability](procedures/script-optimization-workflow.md#step-63-code-readability)
- [Missing Comments](procedures/script-optimization-workflow.md#step-63-code-readability)

### By Script Type

#### Object Scripts
- [Object Launch Point Scripts](core/maximo-scripting-fundamentals.md#1-object-launch-point-scripts)
- [Object Script Patterns](references/scripting-quick-reference.md#field-flags-mboconstants)

#### Attribute Scripts
- [Attribute Launch Point Scripts](core/maximo-scripting-fundamentals.md#2-attribute-launch-point-scripts)
- [Attribute Validation](core/security-best-practices.md#input-validation)

#### Action Scripts
- [Action Launch Point Scripts](core/maximo-scripting-fundamentals.md#3-action-launch-point-scripts)
- [Batch Processing](core/performance-optimization.md#batch-processing)

#### Escalation Scripts
- [Escalation Scripts](core/maximo-scripting-fundamentals.md#4-escalation-scripts)
- [Scheduled Processing](core/performance-optimization.md#process-in-chunks)

## Usage Guidelines

### For Script Authors
1. Review [Maximo Scripting Fundamentals](core/maximo-scripting-fundamentals.md) for basics
2. Follow [Script Optimization Workflow](procedures/script-optimization-workflow.md) when creating scripts
3. Use [Quick Reference](references/scripting-quick-reference.md) for common patterns
4. Check [Common Issues](troubleshooting/common-issues.md) to avoid known problems

### For Code Reviewers
1. Use [Script Optimization Workflow](procedures/script-optimization-workflow.md) as review checklist
2. Reference [Security Best Practices](core/security-best-practices.md) for security review
3. Check [Performance Optimization](core/performance-optimization.md) for performance issues
4. Verify against [Quick Reference](references/scripting-quick-reference.md) patterns

### For Troubleshooting
1. Check [Common Issues](troubleshooting/common-issues.md) for known problems
2. Review [Troubleshooting Tips](troubleshooting/common-issues.md#debugging-tips)
3. Reference [Quick Fixes](troubleshooting/common-issues.md#quick-fixes)
4. Consult relevant core knowledge documents

## Skill Integration

This knowledge base is designed to work with the **Maximo Script Optimizer** Bob skill. The skill uses this knowledge to:

1. **Analyze Scripts**: Systematically review scripts for issues
2. **Identify Problems**: Detect security, performance, and quality issues
3. **Provide Solutions**: Offer specific fixes with code examples
4. **Generate Reports**: Create detailed optimization reports
5. **Guide Users**: Walk through the optimization process step-by-step

## Version Information

- **Knowledge Base Version**: 1.0
- **Last Updated**: 2024-01-15
- **Maximo Versions Supported**: 7.6.x, 8.x, Maximo Application Suite
- **Script Languages**: Jython (Python 2.7 compatible)

## Contributing

To contribute to this knowledge base:

1. Follow the existing document structure
2. Include code examples for all patterns
3. Reference related documents
4. Update this INDEX.md when adding new documents
5. Maintain consistent formatting and style

## Support

For questions or issues:

1. Review the [Common Issues](troubleshooting/common-issues.md) guide
2. Check the [Quick Reference](references/scripting-quick-reference.md)
3. Consult the PDF references for detailed information
4. Use the Bob skill for interactive assistance

## Document Status

| Document | Status | Last Updated |
|----------|--------|--------------|
| INDEX.md | ✅ Complete | 2024-01-15 |
| maximo-scripting-fundamentals.md | ✅ Complete | 2024-01-15 |
| security-best-practices.md | ✅ Complete | 2024-01-15 |
| performance-optimization.md | ✅ Complete | 2024-01-15 |
| script-optimization-workflow.md | ✅ Complete | 2024-01-15 |
| references/scripting-quick-reference.md | ✅ Complete | 2025-07-15 |
| common-issues.md | ✅ Complete | 2024-01-15 |
| optimization-example.md | ✅ Complete | 2024-01-15 |
| references/scripting-launchpoints.md | ✅ Complete | 2025-07-14 |
| references/scripting-rest-integration.md | ✅ Complete | 2025-07-14 |
| references/scripting-service-mbo-api.md | ✅ Complete | 2025-07-14 |
| references/scripting-test-debug.md | ✅ Complete | 2025-07-14 |

## Quick Links

### Most Used Documents
1. [Quick Reference](references/scripting-quick-reference.md) - Fast lookup for field flags, exceptions, operations, thresholds
2. [Security Best Practices](core/security-best-practices.md) - Critical security guidance
3. [Common Issues](troubleshooting/common-issues.md) - Problem solving guide
4. [Optimization Workflow](procedures/script-optimization-workflow.md) - Step-by-step process

### By Role
- **Developers**: [Fundamentals](core/maximo-scripting-fundamentals.md), [Quick Reference](references/scripting-quick-reference.md)
- **Reviewers**: [Workflow](procedures/script-optimization-workflow.md), [Security](core/security-best-practices.md)
- **Troubleshooters**: [Common Issues](troubleshooting/common-issues.md), [Quick Reference](references/scripting-quick-reference.md)
- **Learners**: [Example](../examples/optimization-example.md), [Fundamentals](core/maximo-scripting-fundamentals.md)

---

**Note**: This knowledge base is continuously updated based on real-world script optimization experiences and Maximo best practices. Always refer to the latest version for the most current guidance.