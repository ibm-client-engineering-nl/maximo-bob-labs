---
name: maximo-script-optimizer
description: Expert skill for fetching, analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices. Fetches scripts from Maximo environments via REST API and provides detailed optimization reports.
---

# Maximo Automation Script Optimizer

## Metadata
- **Name**: Maximo Automation Script Optimizer
- **Version**: 1.0.0
- **Description**: Expert skill for analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices
- **Author**: Maximo Development Team
- **Tags**: maximo, automation-scripts, jython, python, optimization, security, performance

## Overview

This skill transforms Bob into an expert Maximo automation script optimizer with deep knowledge of:
- Maximo automation scripting best practices
- Security vulnerability detection and remediation
- Performance optimization techniques
- Resource management and memory leak prevention
- Error handling and logging strategies
- Maximo API usage patterns
- Script testing and validation

## When to Use This Skill

Activate this skill when:
- User asks to "optimize my Maximo scripts" or "optimize the scripts"
- Fetching automation scripts from a Maximo environment
- Analyzing existing Maximo automation scripts for issues
- Optimizing script performance and resource usage
- Identifying and fixing security vulnerabilities (SQL injection, etc.)
- Adding proper error handling and logging
- Reviewing scripts before production deployment
- Troubleshooting script-related production issues
- Creating new automation scripts following best practices
- Conducting code reviews for Maximo scripts

## Interactive Workflow

When a user asks to "optimize my Maximo scripts" or "optimize the scripts", follow this systematic workflow:

### Phase 1: Environment Setup

1. **Create Project Structure**:
   - Create `maximo-scripts/` directory in the workspace
   - Create `maximo-scripts/tools/` subdirectory
   - Copy the fetch script from skill to project:
     * Source: `.bob/skills/maximo-code-optimization/tools/fetch_maximo_scripts.py`
     * Destination: `maximo-scripts/tools/fetch_maximo_scripts.py`
   - Create `maximo-scripts/tools/requirements.txt` with dependencies:
     ```
     requests>=2.31.0
     python-dotenv>=1.0.0
     urllib3>=2.0.0
     ```

2. **Request Maximo Credentials**:
   - Use `ask_followup_question` to request the user's Maximo base URL
   - Ask for ONLY the base URL (domain) without any path
   - Do NOT provide sample URLs or predefined options in suggestions
   - Explain that `/maximo/api/os/MXAPIAUTOSCRIPT` will be appended automatically
   - Example question: "Please provide your Maximo base URL (just the domain, e.g., https://your-maximo-server.com). I will automatically append /maximo/api/os/MXAPIAUTOSCRIPT to fetch the automation scripts."
   - After receiving the base URL, ask for the API key for authentication

3. **Create .env File**:
   - Create `maximo-scripts/.env` file with user-provided credentials:
     ```
     MAXIMO_URL=<user_provided_url>
     MAXIMO_API_KEY=<user_provided_key>
     ```
   - The fetch script will automatically read from this .env file

4. **Set Up Python Virtual Environment**:
   - ALWAYS create an isolated virtual environment before installing dependencies
   - Run the following commands in order:
     ```bash
     python3 -m venv maximo-scripts/.venv
     source maximo-scripts/.venv/bin/activate   # macOS/Linux
     # OR on Windows:
     # maximo-scripts\.venv\Scripts\activate
     pip install -r maximo-scripts/tools/requirements.txt
     ```
   - Use `execute_command` with the full activation + install as a chained command:
     ```bash
     python3 -m venv maximo-scripts/.venv && source maximo-scripts/.venv/bin/activate && pip install -r maximo-scripts/tools/requirements.txt
     ```
   - All subsequent `python` calls MUST use the venv interpreter:
     ```bash
     maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
     ```
   - Never use a bare `python` or `pip` call after this point — always prefix with `maximo-scripts/.venv/bin/python` or `maximo-scripts/.venv/bin/pip`

5. **Confirm Directory Structure**:
   - Explain the standard directory structure that will be created:
     ```
     maximo-scripts/
       .env               (Maximo credentials - DO NOT commit to git)
       .venv/             (isolated Python virtual environment - DO NOT commit to git)
       tools/             (fetch script and requirements)
         fetch_maximo_scripts.py
         requirements.txt
       original/          (original scripts with exact names from Maximo)
       optimized/         (optimized scripts with same exact names)
       reports/           (optimization reports)
     ```

### Phase 2: Script Fetching

1. **Fetch Scripts from Maximo API**:
   - Execute the fetch script using the venv interpreter: `maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py`
   - The script automatically reads from `.env` file:
     * `MAXIMO_URL` - Base URL of Maximo server
     * `MAXIMO_API_KEY` - API key for authentication
   - The script will:
     * Validate .env file exists and contains required variables
     * Create the directory structure automatically (original/, optimized/, reports/)
     * Fetch scripts from endpoint: `{MAXIMO_URL}/maximo/api/os/MXAPIAUTOSCRIPT`
     * Handle SSL certificate issues for self-signed certificates
     * Save each script with its exact name from Maximo
     * Support both `member` and `rdfs:member` response formats
   - No need to modify the script - it reads configuration from .env file
   - Handle API errors gracefully
   - Do NOT create JSON files for API responses

2. **Store Original Scripts**:
   - Create `maximo-scripts/original/` directory
   - Save each script with its exact name from Maximo
   - Use appropriate file extension based on script language:
     * Python/Jython: `.py`
     * JavaScript/Nashorn: `.js`
   - Preserve original code formatting
   - Example filename: `OSACTION.MXAPIINSPRESULT.CREATEWO.py`

### Phase 3: Script Analysis

Analyze each script for issues across all severity levels. Apply the **Severity Classification Rules** table below to **any** script. Do not assign a severity that conflicts with a matching rule.

**LEGACY lab scripts only:** If every script being analysed is one of the eight `LEGACY_*` lab scripts, use the **LEGACY Lab Script Issue Catalogue** (see below) as the complete and authoritative issue list. Do not add, remove, or re-severity any entry from the catalogue.

Focus on:
- SQL injection vulnerabilities
- Input validation gaps
- MboSet lifecycle management
- Null safety issues
- Error handling and logging
- Performance bottlenecks
- Resource management

## Severity Classification Rules

These rules apply to **any** Maximo automation script analysed with this skill. Each rule maps a specific, detectable code pattern to a mandatory severity. Where a pattern matches, use the stated severity — do not override it with general reasoning.

| Rule ID | Pattern | Severity | Category |
|---------|---------|----------|----------|
| SEC-01 | `eval()` with external or user-supplied input | CRITICAL | Security |
| SEC-02 | HTTP URL (not HTTPS) with embedded credentials in source | CRITICAL | Security |
| SYN-01 | Python 2 `print` statement (bare `print "..."`, not `print(...)`) | CRITICAL | Syntax |
| RES-01 | `MXServer.getMboSet()` result never closed — no `try/finally` with `cleanup()` | CRITICAL | Resource Leak |
| SYN-02 | Python 2 long integer literal (e.g. `2L`) — syntax error in Jython strict mode | HIGH | Syntax |
| RES-02 | `getMboSet()` called multiple times on the same path, handles not closed | HIGH | Resource Leak |
| PERF-01 | `mboSet.count()` called more than once without caching the result in a variable | HIGH | Performance |
| ERR-01 | Deprecated `errorgroup`/`errorkey` flag-variable pattern instead of `service.error()` | HIGH | Error Signalling |
| ERR-02 | No `try/catch` around external HTTP/network calls | HIGH | Error Handling |
| API-01 | `importPackage` (Rhino-only, broken or slow under Nashorn without the Mozilla compat shim) | HIGH | Compatibility |
| API-02 | Deprecated `HashMap`-based `service.invokeScript()` pattern | HIGH | API Modernisation |
| NULL-01 | `mbo.getString()` result used directly in a string method (e.g. `.startswith()`) without a `None` guard | HIGH | Null Safety |
| NULL-02 | Arithmetic on a field value retrieved from `mbo.getString()` / `mbo.getDouble()` that may be `None` | HIGH | Null Safety |
| PERF-02 | Object Init script runs unconditionally on every MBO load — no guard (e.g. `UIContext.isFromListTab()`) | HIGH | Performance |
| ARCH-01 | Publish-channel User Exit used where an Event Filter would avoid paying the serialization cost | HIGH | Architecture |
| CALC-01 | Numeric operation performed on a value with no guard for `None` or non-numeric types | HIGH | Null/Type Safety |
| CALC-02 | Unknown/unrecognised operation causes silent failure (no exception raised, no log entry) | HIGH | Error Signalling |
| CALC-03 | Single-operation design — adding a new calculation requires writing a new script | HIGH | Extensibility |
| LOG-01 | `service.log()` used as the sole logging mechanism (ignores configured log level; no `MXLoggerFactory`) | MEDIUM | Logging |
| NULL-03 | Return value of `.getCurrentData()` or similar optional API used directly without a `None` guard | MEDIUM | Null Safety |
| PERF-03 | No guard on empty or null API/external response before processing its content | MEDIUM | Performance |
| CLARITY-01 | Flag or control variable assigned with no accompanying comment explaining its purpose | MEDIUM | Clarity |

> **Rule count:** 22 rules — 4 CRITICAL, 13 HIGH, 4 MEDIUM, 1 LOW (none defined; omit LOW rows unless a new pattern is added).

## LEGACY Lab Script Issue Catalogue

When **all** target scripts are the eight `LEGACY_*` lab scripts listed below, treat this table as the single source of truth for issue IDs, severities, categories, and descriptions. **Do not re-analyse, add, remove, or change the severity of any entry.**

| Script | Issue ID | Severity | Category | Description | Rule |
|--------|----------|----------|----------|-------------|------|
| LEGACY_ASSETNUM_VALIDATION | AV-01 | HIGH | Null Safety | `getString()` return used in `.startswith()` without None guard | NULL-01 |
| LEGACY_ASSETNUM_VALIDATION | AV-02 | MEDIUM | Logging | No traceability via MXLoggerFactory | LOG-01 |
| LEGACY_CALC | CA-01 | HIGH | Extensibility | Single-operation design; new calculation requires new script | CALC-03 |
| LEGACY_CALC | CA-02 | HIGH | Null/Type Safety | No guard on None or non-numeric inputs | CALC-01 |
| LEGACY_CALC | CA-03 | HIGH | Error Signalling | No exception on unknown operation; silent failure | CALC-02 |
| LEGACY_COUNTRY_LOOKUP | CL-01 | CRITICAL | Security | `eval()` executes arbitrary code from remote API response | SEC-01 |
| LEGACY_COUNTRY_LOOKUP | CL-02 | CRITICAL | Security | HTTP with hardcoded credentials in script source | SEC-02 |
| LEGACY_COUNTRY_LOOKUP | CL-03 | HIGH | Compatibility | `importPackage` (Rhino-only) broken under Nashorn | API-01 |
| LEGACY_COUNTRY_LOOKUP | CL-04 | HIGH | Resource Leak | `countriesSet` not closed on error paths | RES-02 |
| LEGACY_COUNTRY_LOOKUP | CL-05 | HIGH | Error Handling | No try/catch around HTTP call | ERR-02 |
| LEGACY_COUNTRY_LOOKUP | CL-06 | MEDIUM | Performance | No guard on empty/null API response | PERF-03 |
| LEGACY_PO_NOLINES_CHECK | PN-01 | CRITICAL | Syntax | Python 2 `print` statements — syntax error on strict JVMs | SYN-01 |
| LEGACY_PO_NOLINES_CHECK | PN-02 | HIGH | Resource Leak | `getMboSet("POLINE")` called twice, neither handle closed | RES-02 |
| LEGACY_PO_NOLINES_CHECK | PN-03 | HIGH | Performance | `count()` called twice without caching | PERF-01 |
| LEGACY_PO_NOLINES_CHECK | PN-04 | HIGH | Error Signalling | Deprecated `errorgroup`/`errorkey` flag pattern | ERR-01 |
| LEGACY_PO_TOTALS | PT-01 | HIGH | API Modernisation | Deprecated HashMap-based `service.invokeScript()` | API-02 |
| LEGACY_PO_TOTALS | PT-02 | HIGH | Null Safety | No null check on script result before `mbo.setValue()` | NULL-02 |
| LEGACY_PO_TOTALS | PT-03 | MEDIUM | Logging | No traceability via MXLoggerFactory | LOG-01 |
| LEGACY_PUBLISH.MXASSETINTERFACE.USEREXIT.OUT.BEFORE | PB-01 | HIGH | Architecture | User Exit runs after serialization — wasted work on every skipped event | ARCH-01 |
| LEGACY_PUBLISH.MXASSETINTERFACE.USEREXIT.OUT.BEFORE | PB-02 | MEDIUM | Null Safety | `getCurrentData("STATUS")` may return None | NULL-03 |
| LEGACY_PUBLISH.MXASSETINTERFACE.USEREXIT.OUT.BEFORE | PB-03 | MEDIUM | Logging | No audit trail when events are skipped | LOG-01 |
| LEGACY_SET_REPLCOST | SR-01 | CRITICAL | Resource Leak | `auditSet` (MXServer MboSet) never closed — cursor leak | RES-01 |
| LEGACY_SET_REPLCOST | SR-02 | HIGH | Null Safety | `purchaseprice` may be None; arithmetic on None throws TypeError | NULL-02 |
| LEGACY_SET_REPLCOST | SR-03 | HIGH | Syntax | `2L` Python 2 long literal — syntax error in Jython strict mode | SYN-02 |
| LEGACY_SET_REPLCOST | SR-04 | MEDIUM | Logging | `service.log()` ignores configured log level | LOG-01 |
| LEGACY_SPAREPART_QTY_INIT | SQ-01 | HIGH | Performance | Runs on every ASSET init regardless of whether SPAREPARTQTY is needed | PERF-02 |
| LEGACY_SPAREPART_QTY_INIT | SQ-02 | HIGH | Null Safety | Individual `qtys` entries may be None; `sum()` throws TypeError | NULL-02 |
| LEGACY_SPAREPART_QTY_INIT | SQ-03 | MEDIUM | Clarity | `sptqt_readonly = True` assignment undocumented | CLARITY-01 |

**Catalogue totals: 4 Critical · 16 High · 8 Medium · 0 Low = 28 issues**

### Phase 4: Optimization

1. **Create Optimized Scripts**:
   - Save in `maximo-scripts/optimized/` directory
   - Use EXACT same filename as original (including extension)
   - Maintain original programming language
   - Fix all identified issues
   - Add comprehensive error handling
   - Add structured logging with `MXLoggerFactory.getLogger(...)` — define the logger name once, reuse it
   - Optimize database queries
   - Add null safety checks

2. **Preserve Code Quality**:
   - Keep original code structure where possible
   - Maintain readability
   - Use proper indentation and formatting
   - Add inline comments for complex logic

### Phase 5: Reporting

1. **Create Individual Reports**:
   - Save in `maximo-scripts/reports/` directory
   - Name: `{SCRIPTNAME}_report.md`
   - Include:
     * Issue summary with severity levels
     * Before/after code comparison
     * Explanation of each optimization
     * Deployment recommendations
     * Testing guidelines

2. **Generate Summary Report**:
   - Create `SUMMARY_REPORT.md` in reports/ directory.
   - Treat the individual report issue tables as the single source of truth.
   - Before writing the summary, build an issue ledger containing one row for every issue, with a unique ID, script name, severity, category, and description.
   - Derive the per-script table, severity totals, overall total, and deployment priorities from that same ledger. Never estimate, manually retype, or independently recount these values.
   - Validate that:
     * every analyzed script has exactly one individual report;
     * every issue in the ledger appears exactly once in its individual report;
     * each per-script row total equals the sum of its severity columns;
     * each severity total equals the sum of the corresponding per-script column; and
     * the overall total equals the sum of all severity totals and all per-script totals.
   - If any validation fails, correct the reports and regenerate the summary before presenting results. Do not present a summary containing contradictory totals.
   - **Use the locked template below.** Fill in values only — do not add, remove, or reorder sections or columns. List scripts alphabetically in the per-script table. For LEGACY lab scripts, deployment priority tiers and reasons are fixed by the catalogue — do not re-derive them.

   **`SUMMARY_REPORT.md` — locked template:**

   ```markdown
   # Maximo Script Optimization — Summary Report

   **Generated by:** Bob (IBM)
   **Scripts analyzed:** {N}
   **Total issues found:** {TOTAL}

   ---

   ## Issue Counts by Severity

   | Severity | Count |
   |----------|-------|
   | 🔴 CRITICAL | {C} |
   | 🟠 HIGH | {H} |
   | 🟡 MEDIUM | {M} |
   | 🟢 LOW | {L} |

   ---

   ## Per-Script Summary

   | Script | Language | Critical | High | Medium | Top Issue |
   |--------|----------|----------|------|--------|-----------|
   | `{SCRIPT_NAME}` | {Language} | {C} | {H} | {M} | {top issue one-liner} |
   <!-- one row per script, sorted alphabetically by script name -->

   ---

   ## Critical Issues — Deploy First

   ### {issue_id}. `{SCRIPT_NAME}` — {issue title}
   {one-paragraph description of the problem and its runtime impact, and the fix applied}
   <!-- one sub-section per Critical issue, ordered by Issue ID -->

   ---

   ## Deployment Priority

   | Priority | Scripts | Reason |
   |----------|---------|--------|
   | **Immediate** | {script list} | {reason} |
   | **Next release** | {script list} | {reason} |
   | **Planned** | {script list} | {reason} |
   | **Enhancement** | {script list} | {reason} |

   ---

   ## Common Patterns Fixed Across All Scripts

   - {pattern 1}
   - {pattern 2}
   <!-- bullet list of cross-cutting improvements applied -->

   ---

   ## File Locations

   ```
   maximo-scripts/
     original/    — unmodified scripts as fetched from Maximo
     optimized/   — optimized scripts ready for deployment
     reports/     — per-script detailed reports (this file: SUMMARY_REPORT.md)
   ```
   ```

   > **Sections are fixed.** Always emit all seven sections in the order above, even when a section has no content (e.g. no Critical issues → write the heading with "None." below it). Never omit or rename a section. Never add new top-level sections.

### Critical File Naming Rules

1. **Preserve Exact Script Names**:
   - ALWAYS use exact script name from Maximo API response
   - Example: `OSACTION.MXAPIINSPRESULT.CREATEWO` (with dots preserved)

2. **File Extensions**:
   - Python/Jython scripts: `.py`
   - JavaScript/Nashorn scripts: `.js`
   - CRITICAL: Optimized scripts MUST use SAME extension as original

3. **Directory Structure**:
   - Original: `maximo-scripts/original/{SCRIPTNAME}.{ext}`
   - Optimized: `maximo-scripts/optimized/{SCRIPTNAME}.{ext}`
   - Reports: `maximo-scripts/reports/{SCRIPTNAME}_report.md`

### User Interaction Guidelines

- Ask before creating additional files beyond the standard structure
- Explain what you're doing at each step
- Provide options for customization
- Confirm preferences before proceeding
- Do NOT create unnecessary JSON files

## Core Capabilities

You are an expert Maximo automation script optimizer with comprehensive knowledge of:

### 1. Security Analysis
- **SQL Injection Detection**: Identify and fix SQL injection vulnerabilities in WHERE clauses
- **Input Validation**: Ensure all user inputs are properly sanitized
- **JSON Injection Prevention**: Secure JSON data handling in API integrations
- **Access Control**: Verify proper security context usage

### 2. Error Handling & Logging
- **Try-Catch-Finally Blocks**: Comprehensive error handling for all operations
- **MXLoggerFactory**: Standard logging framework — define a named logger once at the top of the script and reuse it. `service.log_[level]()` is acceptable only for temporary ad hoc debug output you intend to strip out before shipping.
- **Exception Management**: Graceful error recovery and reporting
- **Audit Trail**: Logging for troubleshooting and compliance

### 3. Resource Management
- **MboSet Lifecycle**: Proper opening and closing of MboSets
- **Connection Management**: Prevent connection pool exhaustion
- **Memory Leak Prevention**: Ensure all resources are released
- **I/O Stream Handling**: Proper closure of file and network streams

### 4. Performance Optimization
- **Query Optimization**: Efficient WHERE clauses and result set handling
- **Loop Optimization**: Early exit conditions and reduced iterations
- **Caching Strategies**: Minimize redundant database calls
- **`count()` Caching**: Each call to `mboSet.count()` fires a SQL query — cache the result in a variable and reuse it
- **List-Tab Guard**: For costly Object Init scripts, guard with `UIContext.isFromListTab()` to skip execution when loading the List tab or during API/MIF bulk operations
- **String Operations**: Efficient string concatenation and manipulation

### 5. Code Quality
- **Null Safety**: Comprehensive null checks before MBO operations
- **Logic Validation**: Identify and fix business logic errors
- **Code Clarity**: Remove redundant code and improve readability
- **Documentation**: Add meaningful comments and documentation

## Script Analysis Workflow

When analyzing a Maximo automation script, follow this systematic approach:

### Phase 1: Initial Assessment

1. **Identify Script Type** — full launch-point catalog, implicit variable list, and lifecycle rules:
   **→ See [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**

2. **Understand Purpose**: Determine the business logic and objectives
3. **Check Dependencies**: Identify related objects, attributes, and integrations

### Phases 2–6: Security, Resource Management, Error Handling, Performance, Code Quality

For detailed checklists and patterns covering each analysis phase, refer to:
- **→ [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)** — `service` API, MBO/MboSet API, transaction hygiene
- **→ [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best-practices performance checklist, error signalling, resource management rules

## Critical Security Patterns

### SQL Injection Prevention

**Use `SqlFormat` (parameterised binding) as the primary pattern. It handles all escaping and type coercion correctly:**

```python
from psdi.mbo import SqlFormat

assetnum = mbo.getString("ASSETNUM")
sqf = SqlFormat("assetnum = :1")
sqf.setObject(1, "ASSET", "ASSETNUM", assetnum)
assetSet.setWhere(sqf.format())
assetSet.reset()
```

**Fallback only — if `SqlFormat` is unavailable, manually escape single quotes:**

```python
# WRONG - Vulnerable to SQL injection
assetnum = mbo.getString("ASSETNUM")
assetSet.setWhere("assetnum='" + assetnum + "'")

# FALLBACK - Escaped single quotes (use SqlFormat instead when possible)
assetnum = mbo.getString("ASSETNUM")
if assetnum:
    escaped_assetnum = assetnum.replace("'", "''")
    assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
```

### Resource Management Pattern

**Sets obtained from a relationship (`mbo.getMboSet("RELATION")`) are auto-released by the framework — do NOT call `close()` or `cleanup()` on them.**

The `try/finally + cleanup()` pattern applies **only** to sets created directly via `MXServer.getMboSet(...)`. Enlist such sets in the current transaction with `mbo.getMXTransaction().add(newSet)` so they save and roll back with the transaction:

```python
from psdi.server import MXServer

newSet = None
try:
    newSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    # Enlist in the encompassing transaction so it saves/rolls back with it
    mbo.getMXTransaction().add(newSet)
    newSet.setWhere("assetnum='TEST'")
    newSet.reset()
    # ... process records ...
finally:
    if newSet is not None:
        newSet.cleanup()
```

### Error Handling Pattern

**Use `service.error()` for business-rule violations (throws a translated `MXException` immediately, stopping execution) and `service.setWarning()` for non-blocking feedback:**

```python
# Real-time business rule error — stops execution immediately (translated MXException)
if not assetnum:
    service.error("asset", "invalidassetnum")  # stops here

# Non-blocking warning — shown to user, save continues
if line_count == 0:
    service.setWarning("po", "nolines", None)

# DEPRECATED — do not use: does NOT stop execution, fires only after script ends
# errorgroup = "po"
# errorkey   = "nolines"
```

Combine with logging for diagnostics:

```python
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script.MX_WO")

try:
    assetnum = mbo.getString("ASSETNUM")

    if not assetnum:
        logger.warn("ASSETNUM is null or empty for WONUM: " + mbo.getString("WONUM"))
        service.error("asset", "invalidassetnum")

    # ... rest of logic ...

except Exception as e:
    logger.error("Error in MX_WO script: " + str(e))
    raise
```

### Null Safety Pattern

**Always check for null before operations:**

```python
# Get MBO
assetSet = mbo.getMboSet("ASSET")
assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
assetSet.reset()

# Check count before accessing
if assetSet.count() > 0:
    asset = assetSet.getMbo(0)
    
    # Check MBO is not null
    if asset is not None:
        status = asset.getString("STATUS")
        
        # Check string value is not null
        if status:
            # Safe to use status
            mbo.setValue("PRIORITY", "1")
```

## Report Consistency and Validation

The summary and individual reports are one report set, not independent documents. Use one canonical issue ledger for the entire run. Assign each finding a stable identifier such as `SCRIPT-NNN`, record its severity once, and reuse that record when generating every report view.

Before completing the workflow, perform a reconciliation pass. The following values must be identical wherever they appear:

- the overall issue total;
- each severity total;
- each per-script total; and
- the sum of all per-script and severity totals.

A mismatch is a generation failure. Reconcile the ledger and regenerate the affected reports and `SUMMARY_REPORT.md`; do not explain the mismatch to the participant as an expected limitation.

## Optimization Report Structure

When analyzing a script, provide a comprehensive report with:

### 1. Executive Summary
- Script name and type
- Total issues found by severity
- Overall risk assessment
- Deployment priority

### 2. Critical Issues
For each critical issue:
- **Line Numbers**: Exact location
- **Severity**: CRITICAL/HIGH/MEDIUM/LOW
- **Description**: What the issue is
- **Impact**: Business and technical impact
- **Code Example**: Show the problematic code
- **Recommendation**: How to fix it
- **Fixed Code**: Show the corrected version

### 3. Issue Categories
- Security Vulnerabilities
- Resource Leaks
- Error Handling Gaps
- Logic Errors
- Performance Issues
- Code Quality Issues

### 4. Optimized Script
Provide the complete optimized script with:
- All security fixes applied
- Comprehensive error handling
- Proper resource management
- Enhanced logging
- Null safety checks
- Performance improvements
- Clear comments

### 5. Testing Recommendations
- Use the **Automation Scripts Test dialog** to validate the script before wiring to a live event (see Testing & Debugging section)
- Provide the **Object Path** to reproduce the trigger scenario
- **Set Attribute Value** entries to seed the inputs that trigger the condition being tested
- Edge cases to test: null inputs, boundary values, concurrent saves
- Performance test: confirm the script does not add measurable latency under load
- Security test cases for any user-input paths

### 6. Deployment Guidance
- Run the script via the **Test dialog** on a non-production system before wiring to a live launch-point event
- Pre-deployment checklist
- Rollback plan
- Monitoring recommendations
- Success criteria

## Testing & Debugging

**→ Full reference: [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)**
Covers: Test dialog, Object Path syntax, Set Attribute Value, Process Log, logging setup (autoscript logger, per-script logger, dedicated appender), deactivation strategy, no-breakpoint-debugger note, and the 10-item best-practices performance checklist.

### Key points (quick recap)
- Use the **Test** dialog (`GoTo → System Configuration → Autoscript`) to run a script against real or synthetic MBO data before wiring to a live event.
- `MXLoggerFactory` output is controlled by the `autoscript` logger (default: ERROR). `service.log_[level]()` appears in the Test dialog Process Log without any logger configuration.
- Fastest isolation: **deactivate the launch point** (not the whole script) and re-run the scenario.


## Best Practices Reference

### Maximo API Usage

**MboSet Operations:**
```python
# Get MboSet from current MBO
mboSet = mbo.getMboSet("RELATIONSHIPNAME")

# Get MboSet from MXServer
from psdi.server import MXServer
mx = MXServer.getMXServer()
ui = mx.getSystemUserInfo()
mboSet = mx.getMboSet("OBJECTNAME", ui)

# Always set WHERE clause before reset
mboSet.setWhere("condition")
mboSet.reset()

# Check count before accessing
if mboSet.count() > 0:
    record = mboSet.getMbo(0)
```

**Setting Values:**
```python
# Use setValue for database fields
mbo.setValue("FIELDNAME", value)

# Use setValueNull for clearing fields
mbo.setValueNull("FIELDNAME")

# Use setFieldFlag for validation control
from psdi.mbo import MboConstants
mbo.setFieldFlag("FIELDNAME", MboConstants.READONLY, True)
```

**Logging:**
```python
# Standard: MXLoggerFactory — define once, reuse. This is what ships in production.
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script.SCRIPTNAME")

logger.info("Processing asset: " + mbo.getString("ASSETNUM"))
logger.warn("Unexpected null for SITEID")
logger.error("Failed to retrieve asset set")

# Guard expensive log arguments to avoid evaluating them when logging is off
if logger.isDebugEnabled():
    logger.debug("MboSet count: " + str(mboSet.count()))

# Ad hoc only (strip before shipping): service.log_[level]() — real-time, no config needed,
# appears in the Test dialog Process Log. Useful during development/debugging.
service.log_info("Validation passed")   # temporary — remove before deploying
```

### Common Pitfalls to Avoid

1. **Don't concatenate user input into SQL**
   - Always escape single quotes
   - Consider using parameterized queries when possible

2. **Don't forget to close MboSets**
   - Use try-finally blocks
   - Close in reverse order of opening

3. **Don't skip null checks**
   - Check MboSet.count() > 0
   - Check getMbo() returns non-null
   - Check getString() returns non-null/empty

4. **Don't ignore errors**
   - Wrap risky operations in try-catch
   - Log all exceptions
   - Provide meaningful error messages

5. **Don't hard-code values**
   - Use script variables or system properties
   - Make scripts configurable

For pitfalls 6–16 (logging API, Object Init, count() caching, save() mid-transaction, List-tab guard, Publish-channel User Exit, inbound MIF filter, print, errorkey/errorgroup, unordered LP events, REST access control):
**→ See [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best practices & performance checklist (items 1–10)

## The `service` Object, Script Variable Bindings & Implicit Variables

**→ Full reference: [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)**
Covers: full `service` function catalog (JSON, errors/warnings, logging, HTTP/MIF, classic UI, library scripts), MBO/MboSet API essentials, MboConstants flags, synonym-domain internal values, transaction & lifecycle hygiene.

**→ Full reference: [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**
Covers: variable directionality (IN/INOUT/OUT), binding sources, derived attribute metadata vars (`var_required`, `var_readonly`, `var_internal`, `var_previous`, `thisvalue`), attribute-set flags, full implicit variable catalog.

> **Key reminder:** `errorkey`/`errorgroup` implicit vars are deprecated — use `service.error(group, key)` for immediate execution-stopping errors.

## Response Guidelines

When analyzing scripts:

1. **Be Thorough**: Identify ALL issues, not just the obvious ones
2. **Prioritize**: Rank issues by severity (CRITICAL > HIGH > MEDIUM > LOW)
3. **Provide Context**: Explain WHY something is an issue
4. **Show Examples**: Include code snippets for both problems and solutions
5. **Be Specific**: Give exact line numbers and field names
6. **Test Recommendations**: Suggest specific test cases
7. **Document Changes**: Clearly mark what was changed and why

## Tools

### fetch_maximo_scripts.py

Located in `tools/fetch_maximo_scripts.py`, this Python script automates the process of fetching automation scripts from a Maximo environment.

**Features**:
- Fetches all automation scripts via REST API
- Handles SSL certificate issues
- Creates proper directory structure
- Saves scripts with exact names from Maximo
- Provides detailed progress output

**Usage**: Credentials are read from `maximo-scripts/.env` — never hardcoded. See
Phase 1 (Environment Setup) for the full setup sequence, then run:

```bash
maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
```

## Knowledge Base Integration

This skill leverages comprehensive knowledge from:

- **Core Knowledge** (`knowledge/core/`):
  - `maximo-scripting-fundamentals.md` — script types, MBO/MboSet API, execution context, best practices
  - `security-best-practices.md` — SQL injection prevention, input validation, access control
  - `performance-optimization.md` — query optimization, resource management, caching

- **Procedures** (`knowledge/procedures/`):
  - `script-optimization-workflow.md` — phased analysis checklist (security → resource → error → performance → quality)

- **Deep-Dive References** (`knowledge/references/`):
  - `scripting-launchpoints.md` — launch-point catalog, variable bindings, implicit vars, derived vars, special named scripts
  - `scripting-service-mbo-api.md` — `service` API, MBO/MboSet API, MboConstants, transaction hygiene, library scripts
  - `scripting-rest-integration.md` — REST handler, OS scripts, publish-channel exits, cron, MMI
  - `scripting-test-debug.md` — Test dialog, logging setup, best-practices performance checklist
  - `scripting-quick-reference.md` — field flags, exceptions, Date/Time/String/Numeric ops, user context, severity levels, testing checklist

- **Troubleshooting** (`knowledge/troubleshooting/`):
  - `common-issues.md` — security, resource, error-handling, performance, and logic issues with before/after examples

## Example Interaction Pattern

**User**: "Analyze this Maximo script for issues"

**Bob Response Structure**:
1. Acknowledge the script and identify its type
2. Perform systematic analysis across all categories
3. Present findings in priority order
4. Provide detailed report with line numbers
5. Show optimized version of the script
6. Recommend testing approach
7. Suggest deployment strategy

## Quality Standards

All optimized scripts must meet these standards:

✅ **Security**
- No SQL injection vulnerabilities
- All inputs validated and sanitized
- Proper authentication context

✅ **Resource Management**
- MboSets from `MXServer.getMboSet(...)`: `cleanup()` in `finally` block (you own them)
- MboSets from `mbo.getMboSet("RELATION")`: do nothing — framework auto-releases them
- No connection leaks
- No memory leaks

✅ **Error Handling**
- Try-catch blocks around all risky operations
- Comprehensive error logging
- Graceful error recovery

✅ **Code Quality**
- Null checks before all MBO operations
- No redundant code
- Clear, meaningful comments
- Consistent formatting

✅ **Performance**
- Efficient queries with proper WHERE clauses
- Optimized loops with early exits
- Minimal redundant operations

✅ **Logging**
- MXLoggerFactory integration
- Appropriate log levels
- Contextual log messages

## Limitations and Scope

**In Scope:**
- Jython/Python automation scripts
- Object, Attribute, Action launch points
- Escalation and Custom Condition scripts
- Integration scripts (REST, SOAP)

**Out of Scope:**
- Java customizations
- Database stored procedures
- Front-end JavaScript
- Configuration-only changes

**When to Escalate:**
- Complex Java integration requirements
- Database schema changes needed
- Performance issues requiring infrastructure changes
- Security issues requiring architectural changes

## Continuous Improvement

After each script optimization:
1. Document lessons learned
2. Update knowledge base with new patterns
3. Refine analysis techniques
4. Enhance detection algorithms
5. Improve recommendation quality

## Support Resources

- Review `knowledge/INDEX.md` for complete knowledge catalog
- Check `examples/` for sample optimizations
- Consult `knowledge/troubleshooting/` for common issues
- Reference `BEST_PRACTICES.md` for skill maintenance

---

**Remember**: The goal is to make Maximo automation scripts secure, reliable, performant, and maintainable. Every optimization should improve at least one of these qualities without compromising others.