---
name: maximo-code-optimization
description: Expert skill for fetching, analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices. Fetches scripts from Maximo environments via REST API and provides detailed optimization reports.
---

# Maximo Automation Script Optimizer

## Metadata
- **Name**: Maximo Automation Script Optimizer
- **Version**: 1.0.0
- **Description**: Expert skill for analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices
- **Author**: Maximo Development Team
- **Tags**: maximo, automation-scripts, jython, python, optimization, security, performance

## Overview

This skill transforms Bob into an expert Maximo automation script optimizer with deep knowledge of:
- Maximo automation scripting best practices
- Security vulnerability detection and remediation
- Performance optimization techniques
- Resource management and memory leak prevention
- Error handling and logging strategies
- Maximo API usage patterns
- Script testing and validation

## When to Use This Skill

Activate this skill when:
- User asks to "optimize my Maximo scripts" or "optimize the scripts"
- Fetching automation scripts from a Maximo environment
- Analyzing existing Maximo automation scripts for issues
- Optimizing script performance and resource usage
- Identifying and fixing security vulnerabilities (SQL injection, etc.)
- Adding proper error handling and logging
- Reviewing scripts before production deployment
- Troubleshooting script-related production issues
- Creating new automation scripts following best practices
- Conducting code reviews for Maximo scripts

## Interactive Workflow

When a user asks to "optimize my Maximo scripts" or "optimize the scripts", follow this systematic workflow:

### Phase 1: Environment Setup

1. **Create Project Structure**:
   - Create `maximo-scripts/` directory in the workspace
   - Create `maximo-scripts/tools/` subdirectory
   - Copy the fetch script from skill to project:
     * Source: `.bob/skills/maximo-code-optimization/tools/fetch_maximo_scripts.py`
     * Destination: `maximo-scripts/tools/fetch_maximo_scripts.py`
   - Create `maximo-scripts/tools/requirements.txt` with dependencies:
     ```
     requests>=2.31.0
     python-dotenv>=1.0.0
     urllib3>=2.0.0
     ```

2. **Request Maximo Credentials**:
   - Use `ask_followup_question` to request the user's Maximo base URL
   - Ask for ONLY the base URL (domain) without any path
   - Do NOT provide sample URLs or predefined options in suggestions
   - Explain that `/maximo/api/os/MXAPIAUTOSCRIPT` will be appended automatically
   - Example question: "Please provide your Maximo base URL (just the domain, e.g., https://your-maximo-server.com). I will automatically append /maximo/api/os/MXAPIAUTOSCRIPT to fetch the automation scripts."
   - After receiving the base URL, ask for the API key for authentication

3. **Create .env File**:
   - Create `maximo-scripts/.env` file with user-provided credentials:
     ```
     MAXIMO_URL=<user_provided_url>
     MAXIMO_API_KEY=<user_provided_key>
     ```
   - The fetch script will automatically read from this .env file

4. **Set Up Python Virtual Environment**:
   - ALWAYS create an isolated virtual environment before installing dependencies
   - Run the following commands in order:
     ```bash
     python3 -m venv maximo-scripts/.venv
     source maximo-scripts/.venv/bin/activate   # macOS/Linux
     # OR on Windows:
     # maximo-scripts\.venv\Scripts\activate
     pip install -r maximo-scripts/tools/requirements.txt
     ```
   - Use `execute_command` with the full activation + install as a chained command:
     ```bash
     python3 -m venv maximo-scripts/.venv && source maximo-scripts/.venv/bin/activate && pip install -r maximo-scripts/tools/requirements.txt
     ```
   - All subsequent `python` calls MUST use the venv interpreter:
     ```bash
     maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
     ```
   - Never use a bare `python` or `pip` call after this point — always prefix with `maximo-scripts/.venv/bin/python` or `maximo-scripts/.venv/bin/pip`

5. **Confirm Directory Structure**:
   - Explain the standard directory structure that will be created:
     ```
     maximo-scripts/
       .env               (Maximo credentials - DO NOT commit to git)
       .venv/             (isolated Python virtual environment - DO NOT commit to git)
       tools/             (fetch script and requirements)
         fetch_maximo_scripts.py
         requirements.txt
       original/          (original scripts with exact names from Maximo)
       optimized/         (optimized scripts with same exact names)
       reports/           (optimization reports)
     ```

### Phase 2: Script Fetching

1. **Fetch Scripts from Maximo API**:
   - Execute the fetch script using the venv interpreter: `maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py`
   - The script automatically reads from `.env` file:
     * `MAXIMO_URL` - Base URL of Maximo server
     * `MAXIMO_API_KEY` - API key for authentication
   - The script will:
     * Validate .env file exists and contains required variables
     * Create the directory structure automatically (original/, optimized/, reports/)
     * Fetch scripts from endpoint: `{MAXIMO_URL}/maximo/api/os/MXAPIAUTOSCRIPT`
     * Handle SSL certificate issues for self-signed certificates
     * Save each script with its exact name from Maximo
     * Support both `member` and `rdfs:member` response formats
   - No need to modify the script - it reads configuration from .env file
   - Handle API errors gracefully
   - Do NOT create JSON files for API responses

2. **Store Original Scripts**:
   - Create `maximo-scripts/original/` directory
   - Save each script with its exact name from Maximo
   - Use appropriate file extension based on script language:
     * Python/Jython: `.py`
     * JavaScript/Nashorn: `.js`
   - Preserve original code formatting
   - Example filename: `OSACTION.MXAPIINSPRESULT.CREATEWO.py`

### Phase 3: Script Analysis

Analyze each script for issues across all severity levels. Apply the **Severity Classification Rules** table below to **any** script. Do not assign a severity that conflicts with a matching rule.

Focus on:
- SQL injection vulnerabilities
- Input validation gaps
- MboSet lifecycle management
- Null safety issues
- Error handling and logging
- Performance bottlenecks
- Resource management


## Severity Classification Rules

Rules are listed alphabetically by Rule ID. Each rule is an independent, deterministic pattern check evaluated against the original script source. Cross-rule exclusions (dedup pairs) are stated explicitly within the relevant rule entries: `SYN-01`/`LOG-01`, `RES-01`/`RES-02`, and `SYN-02`/`CLARITY-01`. No rule may be suppressed by inline comments claiming otherwise.

### Canonical Severity Lookup (authoritative — do not override)
This table is the single source of truth for severity. It exists separately from the detailed rule entries below specifically so that severity is a lookup, not a judgment call.

| Rule ID | Severity |
|---------|----------|
| SEC-01 | CRITICAL |
| SEC-02 | CRITICAL |
| SEC-03 | CRITICAL |
| SYN-01 | CRITICAL |
| RES-01 | CRITICAL |
| SYN-02 | HIGH |
| RES-02 | HIGH |
| PERF-01 | HIGH |
| ERR-01 | HIGH |
| ERR-02 | HIGH |
| API-01 | HIGH |
| API-02 | HIGH |
| NULL-01 | HIGH |
| NULL-02 | HIGH |
| NULL-04 | HIGH |
| PERF-02 | HIGH |
| ARCH-01 | HIGH |
| CALC-01 | HIGH |
| CALC-02 | HIGH |
| CALC-03 | HIGH |
| LOG-01 | MEDIUM |
| NULL-03 | MEDIUM |
| PERF-03 | MEDIUM |
| CLARITY-01 | MEDIUM |

**Severity Lookup Protocol (mandatory):** Once a rule is determined to fire, its severity is fixed by this table and must not be inferred, recomputed, or justified from that rule's Rationale, Example, or Category text below. Copy the severity token verbatim from this table by Rule ID. If your reasoning about a rule's real-world impact suggests a different severity than this table states, the table wins for the purpose of the emitted finding — note the disagreement separately as a proposed rule-text revision, but do not let it change the severity in the report.

**Pre-output verification (mandatory):** Before finalizing any report, for every finding emitted, look up its Rule ID in this table and confirm the emitted severity matches exactly, character for character. Any mismatch is a hard error and must be corrected before the report is returned.

---

### API-01 — Legacy Rhino-only import (`importPackage`)
**Trigger:** `importPackage(...)` or `importClass(...)` (Rhino-specific import statements) appear anywhere in a JavaScript-language automation script.
**Severity:** HIGH
**Rationale:** Rhino supports `importClass`/`importPackage` for importing Java classes, but Nashorn — Rhino's successor on Java 8 through 14 — requires `Java.type` instead, and Nashorn itself was deprecated in JDK 11 and removed entirely in JDK 15, with GraalJS as its replacement. `Java.type` is the shared interop bridge on both engines, so it's the durable fix regardless of which engine a given Manage/MAS release runs on — the fix should not be pinned to a specific Java version range.
**Example (illustrative, not exhaustive):**
```javascript
importPackage(java.util);   // Rhino-only construct → flag
```
**Mandatory fix:** Replace with `Java.type("fully.qualified.ClassName")`.

---

### API-02 — Deprecated `HashMap`-based `invokeScript()` pattern
**Trigger:** `service.invokeScript()` is called using the legacy pattern that packs arguments into a `HashMap` rather than the function-based `service.invokeScript(name, fnName, args[])` form.
**Severity:** HIGH
**Rationale:** The function-based form is the current API convention and avoids the overhead/ambiguity of map-based argument passing.
**Example (illustrative, not exhaustive):**
```python
args = HashMap()
args.put("qty", 5)
service.invokeScript("CALCLIB", args)   # legacy HashMap pattern → flag
```
**Mandatory fix:** Default to function-based style: `service.invokeScript(name, fnName, args[])`. Note in the deployment section that "Allow Invoking Script Functions" must be ON (verify before deploying — the flag is immutable once set). If it's OFF and cannot be changed, fall back to a plain Python `dict` instead of `HashMap`.

---

### ARCH-01 — Publish-Channel User Exit used where an Event Filter would do
**Trigger:** A Publish Channel is wired to a User Exit script for logic that only decides whether a record should be published (a boolean filter decision), rather than to an Event Filter.
**Severity:** HIGH
**Rationale:** A User Exit runs after the outbound payload has already been built and serialized; an Event Filter runs before that work happens, so filter-only logic implemented as a User Exit pays a serialization cost for records that get discarded anyway.
**Example (illustrative, not exhaustive):**
```python
# User Exit script that only inspects a status and returns without publishing
if mbo.getString("STATUS") != "APPR":
    return   # filter-only logic running after serialization → flag
```
**Mandatory fix:** Migrate to an Event Filter script under its own launch point, setting `evalresult = False`/`True` to skip/publish, and retire the User Exit attachment. This is not an in-place script edit — it requires a new launch-point record and Publish Channel reconfiguration; document this clearly in the report. **Lab deployment note:** per `lab-guidelines.md`, only a script named exactly `PUBLISH.<channel>.USEREXIT.OUT.BEFORE` can be wired to a publish channel via this lab's API; the new `PUBLISH.<CHANNEL>.EVENTFILTER` script does not match that pattern and therefore cannot be deployed active with a live launch point in this environment. Produce and document the Event Filter script as the correct fix, but deploy it with `active: false` and no launch point, same as any other non-matching script — do not attempt to wire it live.

---

### CALC-01 — Unguarded numeric operation in a calculation-dispatch script
**Trigger:** A numeric operation is performed on an input value with no guard against that value being `None` or a non-numeric type, in the context of a general calculation/dispatch function (as opposed to a specific documented Maximo API getter, which `NULL-02` covers).
**Severity:** HIGH
**Rationale:** Calculation library scripts commonly take loosely-typed inputs (function parameters, dict lookups, `invokeScript` arguments) that aren't guaranteed numeric; an unguarded operation fails with a raw `TypeError`/`AttributeError` instead of a controlled error path.
**Example (illustrative, not exhaustive):**
```python
def calc(value):
    return value * 1.05   # value's type/nullness never checked → flag
```
**Dedup note:** May co-fire with `NULL-02` only when the same value simultaneously matches both definitions (e.g., an `invokeScript()`-sourced value flowing straight into a dispatch function's arithmetic); otherwise the two rules address different code contexts.
**Mandatory fix:** Guard inputs before arithmetic; use an `if/else` structure.

---

### CALC-02 — Silent failure on unrecognised operation
**Trigger:** A dispatch-style calculation function receives an operation/type identifier it doesn't recognize, and the code path for that case assigns a default/`None` result and returns normally, with no exception raised and no log entry written.
**Severity:** HIGH
**Rationale:** A silently wrong (or null) calculation result is harder to detect and diagnose than a raised error — it can propagate into saved data before anyone notices.
**Example (illustrative, not exhaustive):**
```python
else:
    r = None   # unknown op falls through silently → flag
```
**Mandatory fix:** Raise explicitly on an unknown operation — never assign `r = None` silently.

---

### CALC-03 — Single-operation calculation design
**Trigger:** The script's structure requires a new script (rather than a new entry in a shared function/dispatch table) to add each additional calculation type.
**Severity:** HIGH
**Rationale:** This is an extensibility/maintainability concern rather than a runtime defect — each new calculation requires duplicating launch-point wiring instead of extending one script.
**Example (illustrative, not exhaustive):** A script hardcoded to one calculation with no dispatch structure, where a second calculation type would require copy-pasting the script under a new name rather than adding a branch/function.
**Mandatory fix:** Convert to function-based or dispatch-table style.

---

### CLARITY-01 — Undocumented control-flow variable
**Trigger:** A boolean or control-flow variable — one later tested in an `if`/`elif`/`while` condition **within this script** to change execution path — is assigned with no comment, on that line or the line immediately preceding it, explaining what the value represents or controls. The "later tested in a conditional" requirement is checked literally: if the variable is never referenced again anywhere in the script after assignment, this rule does not fire, regardless of how the variable is named.
**Severity:** MEDIUM
**Rationale:** Automation scripts are frequently maintained by admins other than the original author, often years later with no formal review step; undocumented control flags are a disproportionate source of misconfiguration during maintenance.
**Example (illustrative, not exhaustive):**
```python
isEligible = True   # no comment, drives branching later in the script → flag
```
**Exclusion — Maximo implicit UI-control variables:** Does not fire on assignments to Maximo's implicit attribute-flag variables — names of the form `<attribute>_readonly`, `<attribute>_required`, `<attribute>_hidden`, `<attribute>_modified`, or similar recognized launch-point conventions — even when they are boolean-valued and superficially uncommented. These are not control-flow variables the script itself branches on; they are output flags the Maximo runtime reads after the script completes to set field-level access behavior. A variable matching this naming convention that genuinely is also tested in a conditional elsewhere in the script (an unusual case) still falls outside this exclusion and should be evaluated normally.
**Dedup note (reciprocal to `SYN-02`):** Does not fire on a line that already triggers `SYN-02` (or any other `SYN-*` rule) on the same token — avoid raising both a syntax finding and a clarity finding against one root cause. Still fires independently wherever the undocumented flag and any syntax issue occur on different lines.
**Mandatory fix:** Add an inline comment on the same line (or immediately above it) explaining what the value means and which branch(es) it controls.

---

### ERR-01 — Deprecated `errorgroup`/`errorkey` flag-variable pattern
**Trigger:** Script assigns `errorgroup`/`errorkey` variables directly (the legacy flag-based error-signalling convention) instead of calling `service.error()`. Fires deterministically whenever the assignment pattern is present, independent of what follows it.
**Severity:** HIGH
**Rationale:** The flag-variable convention predates `service.error()` and is easy to leave inert (assigned but never actually checked/acted upon by calling code), silently swallowing what was meant to be a blocking validation failure.
**Example (illustrative, not exhaustive):**
```python
errorgroup = "MyApp"
errorkey = "INVALID_QTY"
```
**Mandatory fix:** The trigger and severity are unconditional on the pattern's presence. What follows the assignment only selects the advisory note attached to the finding, not whether it fires:
- No state-modifying statement (attribute assignment, `mbo.setValue()`, `save()`, etc.) follows before script end → note recommends replacing with `service.error()` directly.
- State-modifying code does follow → note recommends manual developer review of blocking vs. non-blocking semantics before choosing a replacement, since converting to `service.error()` here changes transaction behavior.

---

### ERR-02 — Missing `try/catch` around external network calls
**Trigger:** A call to `service.httpget()` or any external/network-facing API (webservice, socket, non-Maximo-managed connection) has no enclosing `try/catch` (or `try/except`) anywhere on the calling path.
**Severity:** HIGH
**Rationale:** Network calls fail in ways local code doesn't (timeouts, DNS, connection reset); an unhandled exception here propagates into the triggering Maximo transaction and can produce an unrecoverable rollback with a raw stack trace shown to the end user.
**Example (illustrative, not exhaustive):**
```python
resp = service.httpget(url)   # no surrounding try/except anywhere on this path → flag
```
**Dedup note:** Independent of `PERF-03` — `ERR-02` addresses an unhandled exception from the call itself; `PERF-03` addresses unvalidated content once a response is successfully received. Both may fire on the same call.
**Mandatory fix:** Wrap the HTTP call and all downstream processing in `try/catch`; log the error and re-raise or call `service.error()`.

---

### LOG-01 — Wrong logging API actively in use
**Trigger:** `service.log()` or `service.log_[level]()` is used **and** is the only logging mechanism present — no `MXLoggerFactory` logger exists anywhere in the script. Does not fire on a script with no logging at all; absence of logging is not itself a violation.
**Severity:** MEDIUM
**Rationale:** `service.log()` bypasses the standard logger hierarchy (level-based filtering, per-script/per-object log categories), making it harder to control log verbosity in production.
**Example (illustrative, not exhaustive):**
```python
service.log("Processing " + assetnum)   # only logging call in the script, no MXLoggerFactory logger → flag
```
**Dedup note (reciprocal to `SYN-01`):** If `SYN-01` also fires on this script, do not raise `LOG-01` separately — `SYN-01`'s mandatory fix (installing an `MXLoggerFactory` logger to replace the `print` statement) already satisfies what `LOG-01` would require.
**Mandatory fix:** Replace with `MXLoggerFactory.getLogger("maximo.script.<SCRIPTNAME>")` — define the logger once at the top and reuse it. Never replace `service.log()` with another `service.log_[level]()` call.

---

### NULL-01 — Method called on a possibly-absent single-record fetch result
**Trigger:** The result of a call that can return no record — `mboSet.getMbo(index)`, `mboSet.moveFirst()` followed by `getMbo()`, or an equivalent single-record accessor on a set that may be empty — has a method or attribute getter invoked on it directly, with no existence/`None` check between the fetch and the call.
**Severity:** HIGH
**Rationale:** These accessors return `None` when the set has no record at that index; calling any method on that `None` raises an `AttributeError` that propagates uncaught into the transaction. (Retargeted: `mbo.getString()`'s return value is not a source of `None` in Maximo — it returns an empty string for an unset field — so a guard on a string method's input does not belong here; the real, common crash pattern is an unguarded call on a possibly-empty fetch result, which is what this rule now targets.)
**Example (illustrative, not exhaustive):**
```python
craftrate = craftrateSet.getMbo(0)
rate = craftrate.getDouble("STANDARDRATE")   # craftrateSet may be empty → craftrate is None → flag
```
**Mandatory fix:** Add an `if craftrate is not None:` guard (or equivalent existence check) before calling any method on the fetch result; use an `if/else` structure.

---

### NULL-02 — Arithmetic on a genuinely nullable value
**Trigger:** An arithmetic operator (`+ - * / % ** //`) is applied directly to a value that may be `None`, where that value comes from one of the following object-returning sources, with no intervening `is not None`, `is None`, truthiness check, or `try/except` guard between the source and the arithmetic use:
- **(a)** `mbo.getDate()`, `mbo.getMboValueData(...)`/`getDatabaseValue(...)`, or any equivalent Mbo accessor whose Java return type is an object (not a primitive) — `mbo.getDouble()`/`getInt()`/`getFloat()`/`getLong()` are excluded from this rule because their Java return types are primitives and cannot hold `null`;
- **(b)** a variable whose entry in the script's `# Variables:` header comment contains the substring `(implicit -` (e.g. `purchaseprice (implicit - the attribute in context)`), triggered only when that header annotation is literally present in the script source — do not infer bound-variable status from naming convention, launch point type, or schema metadata;
- **(c)** the return value of `service.invokeScript()` assigned to a variable and then used in arithmetic or passed directly to `mbo.setValue()` without an intervening guard — `invokeScript()` returns `None` when the called script fails to assign a result.

String concatenation (`+` on strings) is out of scope — `NULL-01` and `CALC-01` cover string/type misuse separately.
**Severity:** HIGH
**Rationale:** (a)/(b)/(c) can genuinely hold a Python `None` at runtime, so unguarded arithmetic on them raises a `TypeError`. `getDouble()`/`getInt()`/`getFloat()`/`getLong()` return Java primitives and default to `0`/`0.0` for an unset field — they can never be `None`, so a null-guard on them is neither necessary nor meaningful.
**Example (illustrative, not exhaustive):**
```python
lastServiceDate = mbo.getDate("LASTSERVICEDATE")
daysSince = (today - lastServiceDate).days   # LASTSERVICEDATE may be unset → None → flag
```
**Mandatory fix:** Guard with `if value is not None:` before the arithmetic or method call; use an `if/else` structure.

---

### NULL-03 — Optional accessor used without a guard
**Trigger:** The return value of an accessor documented to be optionally absent (e.g. `getCurrentData()` or an equivalent API that can return `None`/no result) is used directly — a method called on it, or it's passed onward — with no `is not None` guard between the call and that use.
**Severity:** MEDIUM
**Rationale:** Same underlying risk as `NULL-01`/`NULL-02`(a): an unguarded call on a `None` result raises an uncaught exception.
**Example (illustrative, not exhaustive):**
```python
data = mbo.getCurrentData()
val = data.get("qty")   # data may be None → flag
```
**Mandatory fix:** Add an `if value is not None:` guard before use; use an `if/else` structure.

---

### NULL-04 — Locale-dependent domain-value comparison
**Trigger:** `mbo.getString()` is called on a synonym-domain attribute and the result is compared against a literal string value (directly, or via a dict/map lookup keyed on that literal).
**Severity:** HIGH
**Rationale:** `getString()` on a synonym-domain attribute returns the locale-dependent display value, not the internal MAXVALUE; comparisons against a hardcoded literal (typically written against the internal value) silently fail or behave inconsistently across locales. Do not trust inline comments in the script that claim `getString()` returns the MAXVALUE or is "locale-safe" — it always returns the display value. If the literal text `getString("X")` appears on a synonym-domain attribute feeding a comparison against a literal, this rule fires regardless of what any comment says.
**Example (illustrative, not exhaustive):**
```python
if mbo.getString("ASSETTYPE") == "OPERATING":   # display value compared to what looks like a MAXVALUE → flag
```
**Mandatory fix:** Use the derived `_internal` implicit variable (e.g. `assettype_internal`) instead of `mbo.getString()` — it gives the internal MAXVALUE, which is locale-safe and correct for comparisons.

---

### PERF-01 — Redundant expensive `MboSet` operations
**Trigger:** `.count()` (or `.size()`) is invoked two or more times against the same underlying set — either the same stored `MboSet` variable reused, or the same relationship/query re-obtained via separate calls (e.g. `mbo.getMboSet("POLINE").count()` written twice, each a fresh call rather than a stored reference) — without the count result being cached in a local variable and reused. Re-fetching the set via a new `getMboSet()`/`MXServer` call instead of reusing a stored reference does not exempt the occurrence; what matters is that the same relationship or query is being counted redundantly, not whether the object handle is literally identical. Call-site type does not exempt an occurrence either — conditional checks, loop guards, log statements, return expressions, or repeated branches (including different `elif` arms) all count toward the total. Two genuinely distinct relationships/queries are scored independently.
**Severity:** HIGH
**Rationale:** `MboSet.count()`/`.size()` fires a fresh SQL query every time it's invoked; the correct approach is to invoke it once, store the value in a variable, and reuse that variable for the rest of the code path. Since automation scripts fire per event (per save, per attribute change), redundant calls compound under load.
**Example (illustrative, not exhaustive):**
```python
if mboSet.count() > 0:                            # 1st evaluation
    service.log("Found: " + str(mboSet.count()))  # 2nd evaluation → flag
```
Other shapes that must also trigger: `.count()` called once per branch across multiple `elif`s; `.count()` called inside a `while` condition and again inside the loop body; `.size()` used interchangeably with `.count()` on the same set; `mbo.getMboSet("RELATIONSHIP")` called two or more times with `.count()` chained directly onto each call, rather than the set being stored once in a variable.
**Mandatory fix:** Cache the result in a local variable before the first use and reuse it for every subsequent reference.

---

### PERF-02 — Unguarded Object-Init launch point
**Trigger:** An Object Init automation script runs with no guard limiting it to contexts where the initialized attribute is actually needed (e.g., no `UIContext.isFromListTab()` check or equivalent).
**Severity:** HIGH
**Rationale:** The Object Launch Point init event script executes for every Mbo selected in the MboSet, even when the attribute it initializes is never used or shown, which is wasteful when large sets are selected via list tabs, APIs, MIF, or escalations.
**Example (illustrative, not exhaustive):**
```python
if priority is not None:
    thisvalue = 2 * priority   # runs on every load, no guard for whether it's needed → flag
```
**Mandatory fix:** Migrate the calculation to an Attribute Init Value launch point on the target attribute — this makes execution just-in-time (fires only when the attribute is referenced) and eliminates the problem structurally. This requires creating a new attribute launch point and removing the Object Init wiring; note this in the report.

---

### PERF-03 — Unvalidated external response before use
**Trigger:** The return value of an external/API call (e.g. `service.httpget()`) is passed into `JSON.parse()`, `eval()`, a string method, or iteration, with no preceding check of its null/empty/error state anywhere on the path between the call and that use. Any mechanism establishing the value is non-null and non-empty before use satisfies the rule — an `if`/truthiness/length check, an HTTP-status check, or a `try/except` that specifically handles malformed/empty content.
**Severity:** MEDIUM
**Rationale:** An external call can return an empty body, an error page, or malformed content even when the connection itself succeeds; processing that content without validation produces a downstream parse error or, worse, silently wrong data.
**Example (illustrative, not exhaustive):**
```python
resp = service.httpget(url)
data = JSON.parse(resp)   # no null/empty/error check anywhere before this line → flag
```
**Dedup note:** Independent of `ERR-02` — see that rule's dedup note.
**Mandatory fix:** Add an explicit null/empty (or equivalent) guard on the response immediately after the call and before it is parsed, evaluated, or iterated.

---

### RES-01 — Unclosed `MXServer`-obtained `MboSet` (single instance)
**Trigger:** A set obtained via `MXServer.getMXServer().getMboSet(...)` (an explicit server-level fetch — not a relationship-based `mbo.getMboSet("RELATIONSHIP")` call, which the Mbo framework manages automatically) has no `try/finally` block whose `finally` calls `.cleanup()` on that set, and exactly **one** such uncleaned set exists on the path.
**Severity:** CRITICAL
**Rationale:** Sets obtained directly from `MXServer` are not automatically released the way a launch-point Mbo's own related sets are; leaked handles accumulate and can cause out-of-memory conditions under sustained script execution.
**Example (illustrative, not exhaustive):**
```python
craftrateSet = MXServer.getMXServer().getMboSet("LABORCRAFTRATE", userInfo)
rate = craftrateSet.getMbo(0).getDouble("STANDARDRATE")   # no try/finally + cleanup() → flag
```
**Dedup note:** Mutually exclusive with `RES-02` on the same script — if exactly one uncleaned `MXServer`-obtained set exists, fire `RES-01` only; if two or more, fire `RES-02` only.
**Mandatory fix:** Initialise the set to `None` before the `try`, call `cleanup()` in `finally`; enlist in the transaction with `mbo.getMXTransaction().add(set)`.

---

### RES-02 — Multiple unclosed `MXServer`-obtained `MboSet`s
**Trigger:** Same call form as `RES-01`, but **two or more** such sets are left uncleaned on the same execution path (e.g., obtained in a loop, or via separate calls at different points in the script).
**Severity:** HIGH
**Rationale:** Same underlying leak as `RES-01`, but compounding — each iteration or call site leaks an additional handle, so the failure mode (accumulated OOM risk) scales with script invocation frequency.
**Example (illustrative, not exhaustive):**
```python
for site in siteList:
    s = MXServer.getMXServer().getMboSet("ASSET", userInfo)
    s.setWhere("siteid = '" + site + "'")
    process(s)   # never cleaned up, and this repeats per iteration → flag RES-02, not RES-01
```
**Dedup note:** See `RES-01` — the two rules are mutually exclusive on the same script, decided purely by count of uncleaned sets.
**Mandatory fix:** Same `try/finally` + `cleanup()` pattern as `RES-01`, applied to every set obtained on the path.

---

### SEC-01 — `eval()`/dynamic execution of untrusted input
**Trigger:** `eval()` (or an equivalent dynamic-execution call) is invoked with an argument whose value originates, on any path, from outside the script's own literals — an Mbo attribute, an HTTP/integration response, a user-supplied parameter, or a workflow variable. `eval()` on a value built entirely from script-authored string literals does not trigger.
**Severity:** CRITICAL
**Rationale:** Executing attacker- or user-influenced strings as code is a code-injection vector regardless of scripting language.
**Example (illustrative, not exhaustive):**
```python
result = eval(mbo.getString("FORMULA"))   # FORMULA is user-editable → flag
```
Other shapes that must also trigger: input concatenated from multiple sources before being passed to `eval()`; input passed through a variable one or more assignments removed from the original external source.
**Mandatory fix:** Replace with `JSON.parse()` (JS) or `service.tojsonobject()` (Jython).

---

### SEC-02 — Hardcoded credentials / plaintext transport for external calls
**Trigger:** Either **(a)** a username, password, API key, or token literal appears anywhere in the script source — whether concatenated into a URL string, set in a header/request-body variable, or passed as a separate literal argument to a network/HTTP call (e.g. `service.httpget(url, "user", "pass")`, where the call signature itself accepts credentials as parameters rather than requiring them embedded in the URL text) — or **(b)** an external call carrying such credentials uses `http://` rather than `https://`. Both conditions are checked independently — a script can trigger on (a) alone even over HTTPS, and on (b) alone even without embedded credentials if it's the transport of any sensitive payload. The mechanism by which the literal reaches the call (string concatenation vs. a separate parameter) does not change whether (a) fires — a hardcoded credential is the trigger, regardless of calling convention.
**Severity:** CRITICAL
**Rationale:** Credentials belong in `MXServer.getProperty()`-backed configuration (or an equivalent secured store), never in script source, since script source is visible to anyone with script-editing access and is retained in version history/audit logs. Plaintext HTTP additionally exposes anything sent — credentials or not — to network interception.
**Example (illustrative, not exhaustive):**
```python
url = "http://api.vendor.com/lookup?apikey=AB12CD34"   # embedded credential + non-HTTPS → flag
```
**Mandatory fix:** Move the URL and credentials to `MXServer.getProperty()`; document the chosen property names in the script header and the report's deployment section.

---

### SEC-03 — SQL injection via string-built WHERE clause
**Trigger:** A `.setWhere()` / `.setQbe()` (or equivalent query-building) call on an MboSet is constructed by string-concatenating a value that originates from an Mbo attribute, HTTP/integration response, or any other external/user-influenced source, with no use of `SqlFormat` (or equivalent parameterised binding) and no manual escaping of quote characters on that value anywhere between the source and the concatenation.
**Severity:** CRITICAL
**Rationale:** A WHERE clause built by directly concatenating unescaped external input lets that input alter the query's structure — the same class of vulnerability as SQL injection in any other data-access layer, and Maximo's `SqlFormat` exists specifically to prevent it. This holds regardless of scripting language (Jython or JavaScript) or which MboSet the query targets.
**Example (illustrative, not exhaustive):**
```python
assetnum = mbo.getString("ASSETNUM")
assetSet.setWhere("assetnum='" + assetnum + "'")   # unescaped, no SqlFormat → flag
```
Other shapes that must also trigger: the same pattern built via `%`-formatting or `.format()` instead of `+` concatenation; a manual `.replace("'", "''")` escape is sufficient to avoid the trigger, but its absence on any external-sourced value in the clause is enough to fire.
**Mandatory fix:** Use `SqlFormat` (parameterised binding) as the primary pattern — it handles escaping and type coercion correctly. If `SqlFormat` is genuinely unavailable in context, manually escape single quotes on every external-sourced value before concatenation, as a fallback only. See the SQL Injection Prevention pattern section below for both forms.

---

### SYN-01 — Python 2 `print` statement
**Trigger:** A bare `print "..."` or `print expr` statement (not the `print(...)` function call form) appears anywhere in the script.
**Severity:** CRITICAL
**Rationale:** This is a hard syntax incompatibility under strict/Python-3-style Jython parsing, not a style preference — the script fails to compile.
**Example (illustrative, not exhaustive):**
```python
print "Value: " + str(qty)   # Python 2 statement form → flag
```
**Dedup note:** See `LOG-01`'s reciprocal dedup note — this rule's mandatory fix already satisfies `LOG-01`.
**Mandatory fix:** Replace with an `MXLoggerFactory` logger call at the appropriate level — never replace with `service.log()`.

---

### SYN-02 — Python 2 long-integer literal
**Trigger:** A numeric literal using the deprecated long-integer suffix (`2L`, `100l`, etc.) appears anywhere in the script.
**Severity:** HIGH
**Rationale:** This syntax is a Python-2/Jython-2.x-only construct; newer script engines reject it outright, so scripts using it fail to compile when the underlying engine is upgraded.
**Example (illustrative, not exhaustive):**
```python
mboset = mbo.getMboSet("RELATEDSET", 2L)   # long literal used as access-check flag → flag
```
**Dedup note:** See `CLARITY-01`'s reciprocal dedup note.
**Mandatory fix:** If the literal is passed as an access-check/flag argument and its value matches a known `MboConstants` field (e.g., `2` = `NOACCESSCHECK`), replace it with the named constant (`mbo.NOACCESSCHECK`). If it's a plain numeric value with no corresponding named constant, simply drop the `L`/`l` suffix — substituting an unrelated constant in that case would silently change the script's behavior.



#### Final step of Phase 3 — Pre-Optimization Issue Tally (mandatory checkpoint before Phase 4)

This is the last thing that happens in Phase 3, not a separate phase — Phase 3 is not considered complete until this checkpoint has been presented, and Phase 4 does not begin until it's done. The point of placing it here, after every script has been analyzed but before any code is rewritten, is to freeze what was found as a fixed target — so Phase 4 has something concrete to trace fixes back to, rather than the issue list still shifting while optimization is underway.

1. **All scripts must have been through analysis first** — this step covers the whole batch at once, not one script at a time, so nothing here happens until every script has a complete set of findings.
2. **Build the ledger once.** One row per finding, each with a stable ID, script name, Rule ID, severity (looked up from the Canonical Severity Lookup table — never re-derived), and a one-line description. This is the same ledger Phase 5 will later reuse — do not build a second, separate count later.
3. **Present the tally before Phase 4 begins, as an actual rendered markdown table in the chat response — not inside a code fence.** The block below is a *template* showing the required column structure and header; it is fenced here only so it displays correctly inside this skill document. When Bob emits the real tally to the user, it must be written as plain markdown table syntax directly in the response text, with no ```` ``` ```` fence around it — a fenced table renders as literal monospaced source instead of a table, which defeats the purpose of a quick, scannable checkpoint. (Contrast this with the `SUMMARY_REPORT.md` template in Phase 5, which *is* meant to be reproduced inside a fence, because that one is literal file content being written to disk — this tally is not a file.)

   Column structure and header (reproduce the table syntax unfenced):
   ```markdown
   ## Pre-Optimization Issue Tally

   | Script | Critical | High | Medium | Low | Total |
   |--------|----------|------|--------|-----|-------|
   | `{SCRIPT_NAME}` | {C} | {H} | {M} | {L} | {total} |
   <!-- one row per script, sorted alphabetically -->
   | **All scripts** | **{C}** | **{H}** | **{M}** | **{L}** | **{TOTAL}** |
   ```

4. **This table is authoritative going forward.** Phase 4's per-script optimization work, and Phase 5's individual reports and `SUMMARY_REPORT.md`, must all reconcile to these exact numbers — Phase 5's reconciliation check (see below) is checking against *this* tally, not recomputing independently. If Phase 4 uncovers a finding that wasn't in this tally, or determines a tallied finding doesn't actually apply, stop, correct the ledger, re-emit the Pre-Optimization Issue Tally with the correction visible, and only then proceed — never let the discrepancy surface for the first time in the final summary.
5. Only after this tally has been presented does Phase 4 begin.

### Phase 4: Optimization

1. **Create Optimized Scripts**:
   - Save in `maximo-scripts/optimized/` directory
   - Use EXACT same filename as original (including extension)
   - Maintain original programming language
   - For every issue identified in Phase 3, apply the **Mandatory fix** from the Severity Classification Rules table — do not invent an alternative fix if a mandatory fix is prescribed
   - For issues with a dedicated fix-pattern section (SQL Injection, Resource Management, Error Handling, NULL-04, Logging, API-01, API-02, PERF-02, ARCH-01, Library Script Dispatch), follow that section exactly
   - Add structured logging with `MXLoggerFactory.getLogger("maximo.script.<SCRIPTNAME>")` — define the logger once at the top of every script, reuse it throughout; never use `service.log()` in an optimized script
   - Add null safety checks using `if/else` structure — never flat guards followed by code that assumes the guard held
   - PERF-02 and ARCH-01 fixes require launch-point or channel configuration changes — produce the new script AND document the required configuration steps in the report; do not deliver a drop-in script edit
   - **Every code change in the optimized script must trace to a named issue ID in the Phase 3 issue table.** Before writing the optimized file, verify this bidirectionally: (a) every issue row has a corresponding fix in the script; (b) every fix in the script has a corresponding issue row. If a fix has no matching row, either add the missing row to the issue table or remove the fix. An optimized script must never contain a change without a matching issue record.

2. **Preserve Code Quality**:
   - Keep original code structure where possible
   - Maintain readability
   - Use proper indentation and formatting
   - Add inline comments that reference the rule ID being fixed (e.g. `# RES-01 FIX: ...`)

### Phase 5: Reporting

1. **Create Individual Reports**:
   - Save in `maximo-scripts/reports/` directory
   - Name: `{SCRIPTNAME}_report.md`
   - Include:
     * Issue summary with severity levels
     * Before/after code comparison
     * Explanation of each optimization
     * Deployment recommendations
     * Testing guidelines

2. **Generate Summary Report**:
   - Create `SUMMARY_REPORT.md` in reports/ directory.
   - Treat the individual report issue tables as the single source of truth — these must already agree with the Pre-Optimization Issue Tally presented at the end of Phase 3; if they don't, that's the mismatch to resolve, not a fresh recount.
   - Before writing **any** number into the summary, follow this mandatory derivation order — never deviate from it:
     1. Build the issue ledger: one row per finding, each with a unique ID, script name, severity, category, and description. This ledger is the only place a severity is ever recorded.
     2. Populate the **Per-Script Summary table** by copying the per-script issue counts **directly from the `Issues Found:` / `Total Issues Found:` header line of each individual report** — do not recount from the ledger. These are the ground-truth per-script numbers.
     3. Derive the **Issue Counts by Severity table** by summing the corresponding column of the Per-Script Summary table. Do **not** count the ledger independently a second time — always sum the already-written per-script column.
     4. Derive **Total issues found** by summing the severity totals just computed in step 3. Do **not** count the ledger a third time.
     5. **Before writing the file**, perform the reconciliation check explicitly: write out the arithmetic as `{C_col_sum} + {H_col_sum} + {M_col_sum} + {L_col_sum} = {TOTAL}` and verify it equals the value from step 4. If the per-script table total for any script does not match the `Issues Found:` header of that script's individual report, stop — the individual report is wrong. Fix it first, then restart from step 2. Never write the file while a mismatch exists.
   - Never estimate, manually retype, or independently recount severity values — all numbers flow in one direction: ledger → individual report header → per-script table → severity totals → overall total.
   - If any validation fails, correct the reports and regenerate the summary before presenting results. Do not present a summary containing contradictory totals.
   - **Use the locked template below.** Fill in values only — do not add, remove, or reorder sections or columns. List scripts alphabetically in the per-script table. For LEGACY lab scripts, deployment priority tiers and reasons are fixed by the catalogue — do not re-derive them.

   **`SUMMARY_REPORT.md` — locked template:**

   ```markdown
   # Maximo Script Optimization — Summary Report

   **Generated by:** Bob (IBM)
   **Scripts analyzed:** {N}
   **Total issues found:** {TOTAL}

   ---

   ## Issue Counts by Severity

   | Severity | Count |
   |----------|-------|
   | 🔴 CRITICAL | {C} |
   | 🟠 HIGH | {H} |
   | 🟡 MEDIUM | {M} |
   | 🟢 LOW | {L} |

   ---

   ## Per-Script Summary

   | Script | Language | Critical | High | Medium | Top Issue |
   |--------|----------|----------|------|--------|-----------|
   | `{SCRIPT_NAME}` | {Language} | {C} | {H} | {M} | {top issue one-liner} |
   <!-- one row per script, sorted alphabetically by script name -->

   ---

   ## Critical Issues — Deploy First

   ### {issue_id}. `{SCRIPT_NAME}` — {issue title}
   {one-paragraph description of the problem and its runtime impact, and the fix applied}
   <!-- one sub-section per Critical issue, ordered by Issue ID -->

   ---

   ## Deployment Priority

   | Priority | Scripts | Reason |
   |----------|---------|--------|
   | **Immediate** | {script list} | {reason} |
   | **Next release** | {script list} | {reason} |
   | **Planned** | {script list} | {reason} |
   | **Enhancement** | {script list} | {reason} |

   ---

   ## Common Patterns Fixed Across All Scripts

   - {pattern 1}
   - {pattern 2}
   <!-- bullet list of cross-cutting improvements applied -->

   ---

   ## File Locations

   ```
   maximo-scripts/
     original/    — unmodified scripts as fetched from Maximo
     optimized/   — optimized scripts ready for deployment
     reports/     — per-script detailed reports (this file: SUMMARY_REPORT.md)
   ```
   ```

   > **Sections are fixed.** Always emit all seven sections in the order above, even when a section has no content (e.g. no Critical issues → write the heading with "None." below it). Never omit or rename a section. Never add new top-level sections.

### Critical File Naming Rules

1. **Preserve Exact Script Names**:
   - ALWAYS use exact script name from Maximo API response
   - Example: `OSACTION.MXAPIINSPRESULT.CREATEWO` (with dots preserved)

2. **File Extensions**:
   - Python/Jython scripts: `.py`
   - JavaScript/Nashorn scripts: `.js`
   - CRITICAL: Optimized scripts MUST use SAME extension as original

3. **Directory Structure**:
   - Original: `maximo-scripts/original/{SCRIPTNAME}.{ext}`
   - Optimized: `maximo-scripts/optimized/{SCRIPTNAME}.{ext}`
   - Reports: `maximo-scripts/reports/{SCRIPTNAME}_report.md`

### User Interaction Guidelines

- Ask before creating additional files beyond the standard structure
- Explain what you're doing at each step
- Provide options for customization
- Confirm preferences before proceeding
- Do NOT create unnecessary JSON files

## Core Capabilities

You are an expert Maximo automation script optimizer with comprehensive knowledge of:

### 1. Security Analysis
- **SQL Injection Detection**: Identify and fix SQL injection vulnerabilities in WHERE clauses
- **Input Validation**: Ensure all user inputs are properly sanitized
- **JSON Injection Prevention**: Secure JSON data handling in API integrations
- **Access Control**: Verify proper security context usage

### 2. Error Handling & Logging
- **Try-Catch-Finally Blocks**: Comprehensive error handling for all operations
- **MXLoggerFactory**: Standard logging framework — define a named logger once at the top of the script and reuse it. `service.log_[level]()` is acceptable only for temporary ad hoc debug output you intend to strip out before shipping.
- **Exception Management**: Graceful error recovery and reporting
- **Audit Trail**: Logging for troubleshooting and compliance

### 3. Resource Management
- **MboSet Lifecycle**: Proper opening and closing of MboSets
- **Connection Management**: Prevent connection pool exhaustion
- **Memory Leak Prevention**: Ensure all resources are released
- **I/O Stream Handling**: Proper closure of file and network streams

### 4. Performance Optimization
- **Query Optimization**: Efficient WHERE clauses and result set handling
- **Loop Optimization**: Early exit conditions and reduced iterations
- **Caching Strategies**: Minimize redundant database calls
- **`count()` Caching**: Each call to `mboSet.count()` fires a SQL query — cache the result in a variable and reuse it
- **List-Tab Guard**: For costly Object Init scripts, guard with `UIContext.isFromListTab()` to skip execution when loading the List tab or during API/MIF bulk operations
- **String Operations**: Efficient string concatenation and manipulation

### 5. Code Quality
- **Null Safety**: Comprehensive null checks before MBO operations
- **Logic Validation**: Identify and fix business logic errors
- **Code Clarity**: Remove redundant code and improve readability
- **Documentation**: Add meaningful comments and documentation

## Script Analysis Workflow

When analyzing a Maximo automation script, follow this systematic approach:

### Phase 1: Initial Assessment

1. **Identify Script Type** — full launch-point catalog, implicit variable list, and lifecycle rules:
   **→ See [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**

2. **Understand Purpose**: Determine the business logic and objectives
3. **Check Dependencies**: Identify related objects, attributes, and integrations

### Phases 2–6: Security, Resource Management, Error Handling, Performance, Code Quality

For detailed checklists and patterns covering each analysis phase, refer to:
- **→ [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)** — `service` API, MBO/MboSet API, transaction hygiene
- **→ [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best-practices performance checklist, error signalling, resource management rules

## Critical Security Patterns

### SQL Injection Prevention (SEC-03)

**Use `SqlFormat` (parameterised binding) as the primary pattern. It handles all escaping and type coercion correctly:**

```python
from psdi.mbo import SqlFormat

assetnum = mbo.getString("ASSETNUM")
sqf = SqlFormat("assetnum = :1")
sqf.setObject(1, "ASSET", "ASSETNUM", assetnum)
assetSet.setWhere(sqf.format())
assetSet.reset()
```

**Fallback only — if `SqlFormat` is unavailable, manually escape single quotes:**

```python
# WRONG - Vulnerable to SQL injection
assetnum = mbo.getString("ASSETNUM")
assetSet.setWhere("assetnum='" + assetnum + "'")

# FALLBACK - Escaped single quotes (use SqlFormat instead when possible)
assetnum = mbo.getString("ASSETNUM")
if assetnum:
    escaped_assetnum = assetnum.replace("'", "''")
    assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
```

### Resource Management Pattern

**Sets obtained from a relationship (`mbo.getMboSet("RELATION")`) are auto-released by the framework — do NOT call `close()` or `cleanup()` on them.**

The `try/finally + cleanup()` pattern applies **only** to sets created directly via `MXServer.getMboSet(...)`. Enlist such sets in the current transaction with `mbo.getMXTransaction().add(newSet)` so they save and roll back with the transaction:

```python
from psdi.server import MXServer

newSet = None
try:
    newSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    # Enlist in the encompassing transaction so it saves/rolls back with it
    mbo.getMXTransaction().add(newSet)
    newSet.setWhere("assetnum='TEST'")
    newSet.reset()
    # ... process records ...
finally:
    if newSet is not None:
        newSet.cleanup()
```

### Error Handling Pattern

**Use `service.error()` for business-rule violations and `service.setWarning()` for non-blocking feedback:**

```python
# Non-blocking warning — shown to user, save continues
if line_count == 0:
    service.setWarning("po", "nolines", None)
```

> **`errorgroup`/`errorkey` assignment never halts execution — not even close.** This is a categorically different and stronger trap than `service.error()`. Setting `errorgroup = "po"` is a plain variable assignment with no side effects at all. The Maximo framework reads those variables only *after the entire script finishes*. Any code below the assignment always runs — unconditionally, in every context, with no exception-catching required for the fall-through to happen. Never use these as guards.
>
> ```python
> # DEPRECATED — this is NOT a guard. Both lines below always execute.
> errorgroup = "po"      # just sets a variable — script continues
> errorkey   = "nolines" # just sets a variable — script continues
> # ... all remaining code runs regardless
> ```

> **`service.error()` is a throw, not a `return`.** It raises `MXApplicationException`, which unwinds the call stack through the Maximo framework. This terminates execution in normal launch-point scripts. However, `service.error()` does **not** act as a syntactic gate — code on the lines below it is not structurally unreachable. Two specific scenarios cause fall-through:
>
> 1. **A broad `except` in the call chain catches it.** `MXApplicationException` is not a `TypeError` or `ValueError` — narrowly-typed excepts won't catch it. But a bare `except:` or `except Exception:` anywhere between the `service.error()` call and the Maximo framework boundary will swallow it, and execution resumes on the next line.
> 2. **Some after-commit contexts.** Community reports indicate that in some after-commit launch-point phases, `service.error()` does not interrupt execution or surface the message to the user. The exact mechanism is not confirmed in IBM documentation — treat `service.error()` as unreliable in after-commit contexts rather than assume a specific cause.
>
> **Consequence:** never write a guard as a flat `if bad: service.error(...)` followed immediately by code that assumes the bad condition did not hold. That code will execute if the exception is caught. Use `if/elif/else` so the flow is structurally correct regardless of whether the exception propagates:

```python
# WRONG — relies on service.error() propagating to skip the else path
if not assetnum:
    service.error("asset", "invalidassetnum")
# ... code that assumes assetnum is not None — executes if exception is caught

# CORRECT — structurally unreachable, no reliance on exception propagation
if not assetnum:
    logger.warn("ASSETNUM null for WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidassetnum")
else:
    # ... code that uses assetnum — only runs when assetnum is set
```

For multi-step guards where several preconditions must hold before the main logic runs, nest them or use `elif/else` chains:

```python
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script.MX_WO")

assetnum = mbo.getString("ASSETNUM")
status   = mbo.getString("STATUS")

if not assetnum:
    logger.warn("ASSETNUM null — WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidassetnum")
elif not status:
    logger.warn("STATUS null — WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidstatus")
else:
    # Both assetnum and status are safe to use here — structurally guaranteed
    mbo.setValue("DESCRIPTION", assetnum + " / " + status)
```

> **Library scripts:** `service.error()` also requires that `service` is bound in the execution context. In a library script invoked via `service.invokeScript(name, map)`, `service` is forwarded by the framework. If invoked via lower-level reflection or from an unusual context where `service` is not in the binding, the call raises `NameError`. For library scripts meant to be called from arbitrary contexts, add an explicit `raise` after `service.error()` as a belt-and-suspenders fallback so the script always aborts on a bad condition even if `service` is unavailable or the exception is caught:
>
> ```python
> if a is None:
>     if 'service' in dir():
>         service.error("calc", "nullinput")
>     raise ValueError("CALC: input 'a' is None")  # always aborts
> ```

### Synonym-Domain Attribute Pattern (NULL-04)

**Never compare `mbo.getString()` output against a literal string on a synonym-domain attribute.** `getString()` returns the *display value* — the locale-specific description shown in the UI. On a synonym-domain attribute, the internal MAXVALUE (used in code, stored in DB) and the display description are two different things. A comparison that works in English may silently fail in a French or German installation.

**Use the derived `_internal` implicit variable instead.** When a script variable is bound to a synonym-domain attribute (e.g. `assettype` bound to `ASSET.ASSETTYPE`), Maximo automatically injects `assettype_internal` containing the locale-safe internal MAXVALUE:

```python
# WRONG — getString() returns the display value; locale-dependent, may be wrong
if mbo.getString("ASSETTYPE") == "FACILITIES":
    service.error(...)

# CORRECT — _internal gives the MAXVALUE regardless of locale
if assettype_internal == 'FACILITIES':
    service.error(...)
```

When no bound variable exists for the attribute, translate explicitly:
```python
from psdi.server import MXServer
atype = MXServer.getMXServer().getMaximoDD().getTranslator() \
          .toInternalString('ASSETTYPE', mbo.getString('ASSETTYPE'))
```

### Logging Pattern (SYN-01 / LOG-01)

**`MXLoggerFactory` is the mandatory replacement for both `print` statements and `service.log()` calls.** Neither `service.log()` nor `service.log_[level]()` is an acceptable fix — they bypass the configured log level and are for ad hoc debugging only. The optimized script must define a named logger once at the top and reuse it throughout:

```python
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script.SCRIPTNAME")
```

Use `logger.info()`, `logger.warn()`, `logger.error()` at the appropriate severity. Guard expensive log arguments with `logger.isDebugEnabled()`.

### API-01 Pattern (Nashorn `importPackage` replacement)

**Replace `importPackage` with `Java.type()`.** `Packages.*` references also work in Nashorn, but `Java.type()` is explicit about the class being resolved and is the shared interop bridge across both Nashorn and its replacement GraalJS — it's the durable fix regardless of which engine or Java version a given Manage/MAS release runs on, so don't pin the recommendation to a specific Java version range (Nashorn itself was removed entirely starting JDK 15):

```javascript
// WRONG — Rhino-only, requires Mozilla compat shim under Nashorn
importPackage(Packages.psdi.server);

// CORRECT — standard Nashorn API
var MXServer = Java.type("psdi.server.MXServer");
```

### API-02 Pattern (invokeScript modernisation)

**Default to the function-based style when fixing API-02.** It requires the called library script to have "Allow Invoking Script Functions" enabled — a flag set at creation that cannot be changed afterward. Always note in the report's deployment section that this flag must be verified before deploying.

```python
# Preferred — function-based, result returned directly, no mutable map
res = service.invokeScript("CALC", "multiply", [2, 3])
```

If the flag is OFF and cannot be changed, fall back to a plain Python `dict` (not `HashMap`):
```python
# Fallback — map/variable style with plain dict (no Java import required)
ctx = {"op": "multiply", "a": 2, "b": 3}
service.invokeScript("CALC", ctx)
res = ctx.get("r")
if res is None:
    logger.error("CALC returned no result")
    service.error("po", "calctotalerror")
else:
    mbo.setValue("CUSTOMTOTAL", res)
```

### PERF-02 Pattern (Object Init migration)

**Migrate Object Init attribute calculations to an Attribute Init Value launch point.** The IBM performance guidance states that Object Initialize scripts run for every MBO load — including every row in the List tab, every API/MIF bulk fetch, and every escalation query — regardless of whether the attribute is ever displayed. An Attribute Init Value launch point fires just-in-time, only when the attribute is actually referenced.

The fix is a launch-point migration, not a script-body change:
1. Create a new **Attribute** launch point on the target attribute, event = **Init Value**
2. Move the calculation logic to `thisvalue = <calculated result>`
3. If a read-only flag is needed, create a second Attribute LP on the same attribute, event = **Init**, and set `thisvalue_readonly = True`
4. Remove (or deactivate) the original Object Init launch point wiring

Note this in the report: the optimized script cannot be deployed as a drop-in replacement — the launch-point configuration must change.

### ARCH-01 Pattern (Publish Channel Event Filter migration)

**Migrate Publish Channel User Exits to Event Filter scripts.** IBM's scripting performance guidance explicitly states that a User Exit runs after the MBO has been serialized into the outbound message — the full serialization cost is paid before the script can decide to skip. An Event Filter runs before serialization and can abort the publish before any message is built.

The fix is a configuration migration, not a script-body change:
1. Create a new automation script for the Event Filter launch point: `PUBLISH.<CHANNEL>.EVENTFILTER`
2. Set `evalresult` correctly — **`evalresult = False` means publish the event; `evalresult = True` means skip it** (counter-intuitive but confirmed by the Maximo scripting reference)
3. Access the MBO via `service.getMbo()` — the implicit `mbo` variable is buggy in event filter context
4. Deactivate and remove the old User Exit script attachment from the Publish Channel

```python
# Event Filter — runs before serialization
# evalresult = False → publish the event  |  evalresult = True → skip (don't publish)
if service.getMbo().isModified("status") and service.getMbo().getString("status") == "BROKEN":
    evalresult = True    # skip — asset is BROKEN, no message built
else:
    evalresult = False   # publish normally
```

Note clearly in the report that this requires: a new script record, a new launch-point attachment on the Publish Channel, and retirement of the existing User Exit. It cannot be delivered as a same-file edit. In this lab, deploy the new script `active: false` with no launch point per `lab-guidelines.md`'s publish-channel naming restriction — the script and its configuration steps are still fully documented in the report, but not wired live.

### Null Safety Pattern

**Always check for null before operations:**

```python
# Get MBO
assetSet = mbo.getMboSet("ASSET")
assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
assetSet.reset()

# Check count before accessing
if assetSet.count() > 0:
    asset = assetSet.getMbo(0)
    
    # Check MBO is not null
    if asset is not None:
        status = asset.getString("STATUS")
        
        # Check string value is not null
        if status:
            # Safe to use status
            mbo.setValue("PRIORITY", "1")
```

### Library Script Dispatch Pattern

Applies when CALC-01, CALC-02, or CALC-03 is found in a library script (a script with no launch point of its own, invoked via `service.invokeScript()`).

**Rule 1 — Prefer the function-based style.** If the script was created with "Allow Invoking Script Functions" enabled, define each operation as a named `def`. `return` works normally inside functions, guards are structurally correct by default, and the caller gets the result directly with no shared mutable map. This style eliminates all of the control-flow concerns below. The flag is immutable after creation — check it before deciding which style to write.

**Rule 2 — In function-based style, use `raise` for error signalling, not `service.error()`.** A library function is called from a calling script's context. Using `raise ValueError(...)` is simpler, always aborts, and does not depend on `service` being bound. The calling script can catch it if needed.

**Rule 3 — In map/variable style, all guards must use `if/else` — never flat guards.** Map-style library scripts are top-level Jython code with no `return` statement. `service.error()` is the only available abort mechanism, but it is a throw, not a gate. A broad `except:` or `except Exception:` anywhere in the call chain swallows it. Structuring guards as `if/else` makes later code unreachable by structure, not by relying on exception propagation:

```python
# WRONG — if service.error() is swallowed, the code below runs with a=None
if a is None:
    service.error("calc", "nullinput")
result = float(a) * float(b)   # executes even when a is None

# CORRECT — structurally unreachable regardless of exception handling
if a is None:
    service.error("calc", "nullinput")
    raise ValueError("CALC: null input")   # belt-and-suspenders (see Rule 4)
else:
    result = float(a) * float(b)
```

**Rule 4 — In map/variable style, always `raise` after `service.error()`.** `service` may not be bound if the script is invoked from an unusual context — the call would raise `NameError` instead of the intended translated message. Adding `raise` after `service.error()` guarantees the script aborts cleanly regardless of whether `service` is available or the exception is caught.

**Rule 5 — An unknown or unrecognised operation must never silently produce `r = None`.** If the dispatch finds no handler for the requested operation, it must raise explicitly. A `None` result written to a numeric field is silent data corruption (CALC-02).

**Rule 6 — Validate inputs before arithmetic.** Guard `a` and `b` for `None` and non-numeric types before any calculation. A `None / 2` raises `TypeError` with no diagnostic context at the point of failure (CALC-01). The validation guard must be in an `if/else` branch (Rule 3), not a flat pre-check.

**Rule 7 — Context variables may be absent; check before reading.** In map style, if a caller does not set `op`, reading `op` raises `NameError`. Use `'op' in dir()` to check for presence before reading optional context variables.

**Rule 8 — Use `MXLoggerFactory` for all logging, not `service.log()`.** `service.log()` ignores configured log level (LOG-01). Define the logger once at the top of the script and reuse it.

**Rule 9 — The caller must treat `r` as potentially absent.** In map style, if the library script errors before assigning `r`, the key will be absent from the context map. The calling script must check for `None` before using the result — never assume `r` is set after `invokeScript` returns.

## Report Consistency and Validation

The summary and individual reports are one report set, not independent documents. Use one canonical issue ledger for the entire run. Assign each finding a stable identifier such as `SCRIPT-NNN`, record its severity once, and reuse that record when generating every report view.

Numbers flow in exactly one direction: **ledger → per-script table → severity totals → overall total**. Any value that appears in the summary must be derived by summing values already written in the table one level below it — never computed independently from the ledger a second time. The specific failure mode to avoid: writing the severity totals table from memory or a separate count, then writing the per-script table from the ledger, producing two inconsistent representations of the same data.

Before writing `SUMMARY_REPORT.md`, perform the reconciliation check explicitly by computing:
- each per-script row total = sum of its C + H + M + L columns (verify against the individual report)
- each severity column total = sum of that column across all per-script rows
- overall total = sum of all severity column totals

Write these sums out before filling in the template. If any value does not match, stop, fix the ledger, and recompute. **Never write the file while a mismatch exists.**

A mismatch is a generation failure. Reconcile the ledger and regenerate the affected reports and `SUMMARY_REPORT.md`; do not explain the mismatch to the participant as an expected limitation.

## Optimization Report Structure

When analyzing a script, provide a comprehensive report with:

### 1. Executive Summary
- Script name and type
- Total issues found by severity
- Overall risk assessment
- Deployment priority

### 2. Critical Issues
For each critical issue:
- **Line Numbers**: Exact location
- **Severity**: CRITICAL/HIGH/MEDIUM/LOW
- **Description**: What the issue is
- **Impact**: Business and technical impact
- **Code Example**: Show the problematic code
- **Recommendation**: How to fix it
- **Fixed Code**: Show the corrected version

### 3. Issue Categories
- Security Vulnerabilities
- Resource Leaks
- Error Handling Gaps
- Logic Errors
- Performance Issues
- Code Quality Issues

### 4. Optimized Script
Provide the complete optimized script with:
- All security fixes applied
- Comprehensive error handling
- Proper resource management
- Enhanced logging
- Null safety checks
- Performance improvements
- Clear comments

### 5. Testing Recommendations
- Use the **Automation Scripts Test dialog** to validate the script before wiring to a live event (see Testing & Debugging section)
- Provide the **Object Path** to reproduce the trigger scenario
- **Set Attribute Value** entries to seed the inputs that trigger the condition being tested
- Edge cases to test: null inputs, boundary values, concurrent saves
- Performance test: confirm the script does not add measurable latency under load
- Security test cases for any user-input paths

### 6. Deployment Guidance
- Run the script via the **Test dialog** on a non-production system before wiring to a live launch-point event
- Pre-deployment checklist
- Rollback plan
- Monitoring recommendations
- Success criteria

## Testing & Debugging

**→ Full reference: [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)**
Covers: Test dialog, Object Path syntax, Set Attribute Value, Process Log, logging setup (autoscript logger, per-script logger, dedicated appender), deactivation strategy, no-breakpoint-debugger note, and the 10-item best-practices performance checklist.

### Key points (quick recap)
- Use the **Test** dialog (`GoTo → System Configuration → Autoscript`) to run a script against real or synthetic MBO data before wiring to a live event.
- `MXLoggerFactory` output is controlled by the `autoscript` logger (default: ERROR). `service.log_[level]()` appears in the Test dialog Process Log without any logger configuration.
- Fastest isolation: **deactivate the launch point** (not the whole script) and re-run the scenario.


## Best Practices Reference

### Maximo API Usage

**MboSet Operations:**
```python
# Get MboSet from current MBO
mboSet = mbo.getMboSet("RELATIONSHIPNAME")

# Get MboSet from MXServer
from psdi.server import MXServer
mx = MXServer.getMXServer()
ui = mx.getSystemUserInfo()
mboSet = mx.getMboSet("OBJECTNAME", ui)

# Always set WHERE clause before reset
mboSet.setWhere("condition")
mboSet.reset()

# Check count before accessing
if mboSet.count() > 0:
    record = mboSet.getMbo(0)
```

**Setting Values:**
```python
# Use setValue for database fields
mbo.setValue("FIELDNAME", value)

# Use setValueNull for clearing fields
mbo.setValueNull("FIELDNAME")

# Use setFieldFlag for validation control
from psdi.mbo import MboConstants
mbo.setFieldFlag("FIELDNAME", MboConstants.READONLY, True)
```

**Logging:**
```python
# Standard: MXLoggerFactory — define once, reuse. This is what ships in production.
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script.SCRIPTNAME")

logger.info("Processing asset: " + mbo.getString("ASSETNUM"))
logger.warn("Unexpected null for SITEID")
logger.error("Failed to retrieve asset set")

# Guard expensive log arguments to avoid evaluating them when logging is off
if logger.isDebugEnabled():
    logger.debug("MboSet count: " + str(mboSet.count()))

# Ad hoc only (strip before shipping): service.log_[level]() — real-time, no config needed,
# appears in the Test dialog Process Log. Useful during development/debugging.
service.log_info("Validation passed")   # temporary — remove before deploying
```

### Common Pitfalls to Avoid

1. **Don't concatenate user input into SQL**
   - Always escape single quotes
   - Consider using parameterized queries when possible

2. **Don't forget to close MboSets**
   - Use try-finally blocks
   - Close in reverse order of opening

3. **Don't skip null checks**
   - Check MboSet.count() > 0
   - Check getMbo() returns non-null
   - Check getString() returns non-null/empty

4. **Don't ignore errors**
   - Wrap risky operations in try-catch
   - Log all exceptions
   - Provide meaningful error messages

5. **Don't hard-code values**
   - Use script variables or system properties
   - Make scripts configurable

For pitfalls 6–16 (logging API, Object Init, count() caching, save() mid-transaction, List-tab guard, Publish-channel User Exit, inbound MIF filter, print, errorkey/errorgroup, unordered LP events, REST access control):
**→ See [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best practices & performance checklist (items 1–10)

## The `service` Object, Script Variable Bindings & Implicit Variables

**→ Full reference: [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)**
Covers: full `service` function catalog (JSON, errors/warnings, logging, HTTP/MIF, classic UI, library scripts), MBO/MboSet API essentials, MboConstants flags, synonym-domain internal values, transaction & lifecycle hygiene.

**→ Full reference: [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**
Covers: variable directionality (IN/INOUT/OUT), binding sources, derived attribute metadata vars (`var_required`, `var_readonly`, `var_internal`, `var_previous`, `thisvalue`), attribute-set flags, full implicit variable catalog.

> **Key reminder:** `errorkey`/`errorgroup` implicit vars are deprecated — use `service.error(group, key)` to signal business-rule violations. Note that `service.error()` works by throwing `MXApplicationException` — it is not a syntactic return statement. Structure guards as `if/else` blocks so later code is structurally unreachable, not just exception-dependent. See the Error Handling Pattern section for the canonical pattern.

## Response Guidelines

When analyzing scripts:

1. **Be Thorough**: Identify ALL issues, not just the obvious ones
2. **Prioritize**: Rank issues by severity (CRITICAL > HIGH > MEDIUM > LOW)
3. **Provide Context**: Explain WHY something is an issue
4. **Show Examples**: Include code snippets for both problems and solutions
5. **Be Specific**: Give exact line numbers and field names
6. **Test Recommendations**: Suggest specific test cases
7. **Document Changes**: Clearly mark what was changed and why

## Tools

### fetch_maximo_scripts.py

Located in `tools/fetch_maximo_scripts.py`, this Python script automates the process of fetching automation scripts from a Maximo environment.

**Features**:
- Fetches all automation scripts via REST API
- Handles SSL certificate issues
- Creates proper directory structure
- Saves scripts with exact names from Maximo
- Provides detailed progress output

**Usage**: Credentials are read from `maximo-scripts/.env` — never hardcoded. See
Phase 1 (Environment Setup) for the full setup sequence, then run:

```bash
maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
```

## Knowledge Base Integration

This skill leverages comprehensive knowledge from:

- **Core Knowledge** (`knowledge/core/`):
  - `maximo-scripting-fundamentals.md` — script types, MBO/MboSet API, execution context, best practices
  - `security-best-practices.md` — SQL injection prevention, input validation, access control
  - `performance-optimization.md` — query optimization, resource management, caching

- **Procedures** (`knowledge/procedures/`):
  - `script-optimization-workflow.md` — phased analysis checklist (security → resource → error → performance → quality)

- **Deep-Dive References** (`knowledge/references/`):
  - `scripting-launchpoints.md` — launch-point catalog, variable bindings, implicit vars, derived vars, special named scripts
  - `scripting-service-mbo-api.md` — `service` API, MBO/MboSet API, MboConstants, transaction hygiene, library scripts
  - `scripting-rest-integration.md` — REST handler, OS scripts, publish-channel exits, cron, MMI
  - `scripting-test-debug.md` — Test dialog, logging setup, best-practices performance checklist
  - `scripting-quick-reference.md` — field flags, exceptions, Date/Time/String/Numeric ops, user context, severity levels, testing checklist

- **Troubleshooting** (`knowledge/troubleshooting/`):
  - `common-issues.md` — security, resource, error-handling, performance, and logic issues with before/after examples

## Example Interaction Pattern

**User**: "Analyze this Maximo script for issues"

**Bob Response Structure**:
1. Acknowledge the script and identify its type
2. Perform systematic analysis across all categories
3. Present findings in priority order
4. Provide detailed report with line numbers
5. Show optimized version of the script
6. Recommend testing approach
7. Suggest deployment strategy

## Quality Standards

All optimized scripts must meet these standards:

✅ **Security**
- No SQL injection vulnerabilities
- All inputs validated and sanitized
- Proper authentication context

✅ **Resource Management**
- MboSets from `MXServer.getMboSet(...)`: `cleanup()` in `finally` block (you own them)
- MboSets from `mbo.getMboSet("RELATION")`: do nothing — framework auto-releases them
- No connection leaks
- No memory leaks

✅ **Error Handling**
- Try-catch blocks around all risky operations
- Comprehensive error logging
- Graceful error recovery

✅ **Code Quality**
- Null checks before all MBO operations
- No redundant code
- Clear, meaningful comments
- Consistent formatting

✅ **Performance**
- Efficient queries with proper WHERE clauses
- Optimized loops with early exits
- Minimal redundant operations

✅ **Logging**
- MXLoggerFactory integration
- Appropriate log levels
- Contextual log messages

## Limitations and Scope

**In Scope:**
- Jython/Python automation scripts
- Object, Attribute, Action launch points
- Escalation and Custom Condition scripts
- Integration scripts (REST, SOAP)

**Out of Scope:**
- Java customizations
- Database stored procedures
- Front-end JavaScript
- Configuration-only changes

**When to Escalate:**
- Complex Java integration requirements
- Database schema changes needed
- Performance issues requiring infrastructure changes
- Security issues requiring architectural changes

## Continuous Improvement

After each script optimization:
1. Document lessons learned
2. Update knowledge base with new patterns
3. Refine analysis techniques
4. Enhance detection algorithms
5. Improve recommendation quality

## Support Resources

- Review `knowledge/INDEX.md` for complete knowledge catalog
- Consult `knowledge/troubleshooting/` for common issues
- Reference `BEST_PRACTICES.md` for skill maintenance

---

**Remember**: The goal is to make Maximo automation scripts secure, reliable, performant, and maintainable. Every optimization should improve at least one of these qualities without compromising others.