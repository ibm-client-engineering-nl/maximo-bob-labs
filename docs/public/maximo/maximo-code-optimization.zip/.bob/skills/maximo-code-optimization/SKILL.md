---
name: maximo-code-optimization
description: Expert skill for fetching, analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices. Fetches scripts from Maximo environments via REST API and provides detailed optimization reports.
---

# Maximo Automation Script Optimizer

## Metadata
- **Name**: Maximo Automation Script Optimizer
- **Version**: 1.0.0
- **Description**: Expert skill for analyzing, optimizing, and securing IBM Maximo automation scripts with comprehensive best practices
- **Author**: Maximo Development Team
- **Tags**: maximo, automation-scripts, jython, python, optimization, security, performance

## Overview

This skill transforms Bob into an expert Maximo automation script optimizer with deep knowledge of:
- Maximo automation scripting best practices
- Security vulnerability detection and remediation
- Performance optimization techniques
- Resource management and memory leak prevention
- Error handling and logging strategies
- Maximo API usage patterns
- Script testing and validation

## When to Use This Skill

Activate this skill when:
- User asks to "optimize my Maximo scripts" or "optimize the scripts"
- Fetching automation scripts from a Maximo environment
- Analyzing existing Maximo automation scripts for issues
- Optimizing script performance and resource usage
- Identifying and fixing security vulnerabilities (SQL injection, etc.)
- Adding proper error handling and logging
- Reviewing scripts before production deployment
- Troubleshooting script-related production issues
- Creating new automation scripts following best practices
- Conducting code reviews for Maximo scripts

## Interactive Workflow

When a user asks to "optimize my Maximo scripts" or "optimize the scripts", follow this systematic workflow:

### Phase 1: Environment Setup

1. **Create Project Structure**:
   - Create `maximo-scripts/` directory in the workspace
   - Create `maximo-scripts/tools/` subdirectory
   - Copy the fetch script from skill to project:
     * Source: `.bob/skills/maximo-code-optimization/tools/fetch_maximo_scripts.py`
     * Destination: `maximo-scripts/tools/fetch_maximo_scripts.py`
   - Create `maximo-scripts/tools/requirements.txt` with dependencies:
     ```
     requests>=2.31.0
     python-dotenv>=1.0.0
     urllib3>=2.0.0
     ```

2. **Request Maximo Credentials**:
   - Use `ask_followup_question` to request the user's Maximo base URL
   - Ask for ONLY the base URL (domain) without any path
   - Do NOT provide sample URLs or predefined options in suggestions
   - Explain that `/maximo/api/os/MXAPIAUTOSCRIPT` will be appended automatically
   - Example question: "Please provide your Maximo base URL (just the domain, e.g., https://your-maximo-server.com). I will automatically append /maximo/api/os/MXAPIAUTOSCRIPT to fetch the automation scripts."
   - After receiving the base URL, ask for the API key for authentication

3. **Create .env File**:
   - Create `maximo-scripts/.env` file with user-provided credentials:
     ```
     MAXIMO_URL=<user_provided_url>
     MAXIMO_API_KEY=<user_provided_key>
     ```
   - The fetch script will automatically read from this .env file

4. **Set Up Python Virtual Environment**:
   - ALWAYS create an isolated virtual environment before installing dependencies
   - Run the following commands in order:
     ```bash
     python3 -m venv maximo-scripts/.venv
     source maximo-scripts/.venv/bin/activate   # macOS/Linux
     # OR on Windows:
     # maximo-scripts\.venv\Scripts\activate
     pip install -r maximo-scripts/tools/requirements.txt
     ```
   - Use `execute_command` with the full activation + install as a chained command:
     ```bash
     python3 -m venv maximo-scripts/.venv && source maximo-scripts/.venv/bin/activate && pip install -r maximo-scripts/tools/requirements.txt
     ```
   - All subsequent `python` calls MUST use the venv interpreter:
     ```bash
     maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
     ```
   - Never use a bare `python` or `pip` call after this point — always prefix with `maximo-scripts/.venv/bin/python` or `maximo-scripts/.venv/bin/pip`

5. **Confirm Directory Structure**:
   - Explain the standard directory structure that will be created:
     ```
     maximo-scripts/
       .env               (Maximo credentials - DO NOT commit to git)
       .venv/             (isolated Python virtual environment - DO NOT commit to git)
       tools/             (fetch script and requirements)
         fetch_maximo_scripts.py
         requirements.txt
       original/          (original scripts with exact names from Maximo)
       optimized/         (optimized scripts with same exact names)
       reports/           (optimization reports)
     ```

### Phase 2: Script Fetching

1. **Fetch Scripts from Maximo API**:
   - Execute the fetch script using the venv interpreter: `maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py`
   - The script automatically reads from `.env` file:
     * `MAXIMO_URL` - Base URL of Maximo server
     * `MAXIMO_API_KEY` - API key for authentication
   - The script will:
     * Validate .env file exists and contains required variables
     * Create the directory structure automatically (original/, optimized/, reports/)
     * Fetch scripts from endpoint: `{MAXIMO_URL}/maximo/api/os/MXAPIAUTOSCRIPT`
     * Handle SSL certificate issues for self-signed certificates
     * Save each script with its exact name from Maximo
     * Support both `member` and `rdfs:member` response formats
   - No need to modify the script - it reads configuration from .env file
   - Handle API errors gracefully
   - Do NOT create JSON files for API responses

2. **Store Original Scripts**:
   - Create `maximo-scripts/original/` directory
   - Save each script with its exact name from Maximo
   - Use appropriate file extension based on script language:
     * Python/Jython: `.py`
     * JavaScript/Nashorn: `.js`
   - Preserve original code formatting
   - Example filename: `OSACTION.MXAPIINSPRESULT.CREATEWO.py`

### Phase 3: Script Analysis

Analyze each script for issues across all severity levels. Apply the **Severity Classification Rules** table below to **any** script. Do not assign a severity that conflicts with a matching rule.

Focus on:
- SQL injection vulnerabilities
- Input validation gaps
- MboSet lifecycle management
- Null safety issues
- Error handling and logging
- Performance bottlenecks
- Resource management

## Severity Classification Rules

These rules apply to **any** Maximo automation script analysed with this skill. Each rule maps a specific, detectable code pattern to a mandatory severity. Where a pattern matches, use the stated severity — do not override it with general reasoning.

| Rule ID | Pattern | Severity | Category | Mandatory fix |
|---------|---------|----------|----------|---------------|
| SEC-01 | `eval()` with external or user-supplied input | CRITICAL | Security | Replace with `JSON.parse()` (JS) or `service.tojsonobject()` (Jython) |
| SEC-02 | HTTP URL (not HTTPS) with embedded credentials in source | CRITICAL | Security | Move URL and credentials to `MXServer.getProperty()`; document chosen property names in the script header and report deployment section |
| SYN-01 | Python 2 `print` statement (bare `print "..."`, not `print(...)`) | CRITICAL | Syntax | Replace with `MXLoggerFactory` logger call at the appropriate level — **never** replace with `service.log()` |
| RES-01 | `MXServer.getMboSet()` result never closed — no `try/finally` with `cleanup()` | CRITICAL | Resource Leak | Initialise set to `None` before the `try`, call `cleanup()` in `finally`; enlist in transaction with `mbo.getMXTransaction().add(set)` |
| SYN-02 | Python 2 long integer literal (e.g. `2L`) — syntax error in Jython strict mode | HIGH | Syntax | Replace with `mbo.NOACCESSCHECK` (no import required; `MboConstants` is mixed into every MBO) |
| RES-02 | `getMboSet()` called multiple times on the same path, handles not closed | HIGH | Resource Leak | Same `try/finally + cleanup()` pattern as RES-01 |
| PERF-01 | `mboSet.count()` called more than once without caching the result in a variable | HIGH | Performance | Cache result in a local variable before the first use |
| ERR-01 | Deprecated `errorgroup`/`errorkey` flag-variable pattern instead of `service.error()` | HIGH | Error Signalling | Infer intent from context: if nothing follows the flag assignments (end of script or no further state changes), replace with `service.error()`; if state-modifying code follows, flag as ambiguous in the report — do not choose blocking vs. non-blocking without developer confirmation |
| ERR-02 | No `try/catch` around external HTTP/network calls | HIGH | Error Handling | Wrap the HTTP call and all downstream processing in `try/catch`; log the error and re-raise or call `service.error()` |
| API-01 | `importPackage` (Rhino-only, broken or slow under Nashorn without the Mozilla compat shim) | HIGH | Compatibility | Replace with `Java.type("fully.qualified.ClassName")` — the standard Nashorn API, works on Java 8 and Java 11+ |
| API-02 | Deprecated `HashMap`-based `service.invokeScript()` pattern | HIGH | API Modernisation | Default to function-based style: `service.invokeScript(name, fnName, args[])`; note in the deployment section that "Allow Invoking Script Functions" must be ON (verify before deploying — flag is immutable). If OFF and cannot be changed, fall back to plain Python `dict` instead of `HashMap` |
| NULL-01 | `mbo.getString()` result used directly in a string method (e.g. `.startswith()`) without a `None` guard | HIGH | Null Safety | Add `if not value:` guard before the string method call; use `if/else` structure (see Error Handling Pattern) |
| NULL-02 | Arithmetic on a field value retrieved from `mbo.getString()` / `mbo.getDouble()` that may be `None` | HIGH | Null Safety | Guard with `if value is not None:` before the arithmetic; use `if/else` structure |
| NULL-04 | `mbo.getString()` on a synonym-domain attribute compared against a literal string value | HIGH | Null Safety | Use the derived `_internal` implicit variable (e.g. `assettype_internal`) instead of `mbo.getString()` — `getString()` returns the display value which is locale-dependent; `_internal` gives the internal MAXVALUE which is locale-safe and the correct value for comparisons |
| PERF-02 | Object Init script runs unconditionally on every MBO load — no guard (e.g. `UIContext.isFromListTab()`) | HIGH | Performance | Migrate the calculation to an **Attribute Init Value** launch point on the target attribute — this makes execution just-in-time (fires only when the attribute is referenced) and eliminates the problem structurally. Note in the report that this requires creating a new Attribute launch point and removing the Object Init wiring |
| ARCH-01 | Publish-channel User Exit used where an Event Filter would avoid paying the serialization cost | HIGH | Architecture | Recommended fix is migration to a Publish Channel Event Filter script: create a new script under the Event Filter launch point, set `evalresult = False` to skip or `True` to publish, and retire the User Exit attachment. **This is not an in-place script edit** — it requires a new launch-point record and Publish Channel reconfiguration. Document this clearly in the report. Do not deliver a "drop-in" optimized User Exit as the fix |
| CALC-01 | Numeric operation performed on a value with no guard for `None` or non-numeric types | HIGH | Null/Type Safety | Guard inputs before arithmetic; use `if/else` — see Library Script Dispatch Pattern |
| CALC-02 | Unknown/unrecognised operation causes silent failure (no exception raised, no log entry) | HIGH | Error Signalling | Raise explicitly on unknown operation — never assign `r = None` silently; see Library Script Dispatch Pattern |
| CALC-03 | Single-operation design — adding a new calculation requires writing a new script | HIGH | Extensibility | Convert to function-based or dispatch-table style; see Library Script Dispatch Pattern |
| LOG-01 | `service.log()` used as the sole logging mechanism (ignores configured log level; no `MXLoggerFactory`) | MEDIUM | Logging | Replace with `MXLoggerFactory.getLogger("maximo.script.<SCRIPTNAME>")` — define the logger once at the top and reuse it. **Never** replace `service.log()` with another `service.log_[level]()` call — that is the same pattern |
| NULL-03 | Return value of `.getCurrentData()` or similar optional API used directly without a `None` guard | MEDIUM | Null Safety | Add `if value is not None:` guard before use; use `if/else` structure |
| PERF-03 | No guard on empty or null API/external response before processing its content | MEDIUM | Performance | Add explicit length/null check on the response before parsing or iterating |
| CLARITY-01 | Flag or control variable assigned with no accompanying comment explaining its purpose | MEDIUM | Clarity | Add an inline comment on the same line explaining what the value means |

> **Rule count:** 23 rules — 4 CRITICAL, 14 HIGH, 4 MEDIUM, 1 LOW (none defined; omit LOW rows unless a new pattern is added). NULL-04 was added to capture synonym-domain `getString()` comparison as a distinct failure mode from generic null-safety (NULL-01).

### Phase 4: Optimization

1. **Create Optimized Scripts**:
   - Save in `maximo-scripts/optimized/` directory
   - Use EXACT same filename as original (including extension)
   - Maintain original programming language
   - For every issue identified in Phase 3, apply the **Mandatory fix** from the Severity Classification Rules table — do not invent an alternative fix if a mandatory fix is prescribed
   - For issues with a dedicated fix-pattern section (SQL Injection, Resource Management, Error Handling, NULL-04, Logging, API-01, API-02, PERF-02, ARCH-01, Library Script Dispatch), follow that section exactly
   - Add structured logging with `MXLoggerFactory.getLogger("maximo.script.<SCRIPTNAME>")` — define the logger once at the top of every script, reuse it throughout; never use `service.log()` in an optimized script
   - Add null safety checks using `if/else` structure — never flat guards followed by code that assumes the guard held
   - PERF-02 and ARCH-01 fixes require launch-point or channel configuration changes — produce the new script AND document the required configuration steps in the report; do not deliver a drop-in script edit

2. **Preserve Code Quality**:
   - Keep original code structure where possible
   - Maintain readability
   - Use proper indentation and formatting
   - Add inline comments that reference the rule ID being fixed (e.g. `# RES-01 FIX: ...`)

### Phase 5: Reporting

1. **Create Individual Reports**:
   - Save in `maximo-scripts/reports/` directory
   - Name: `{SCRIPTNAME}_report.md`
   - Include:
     * Issue summary with severity levels
     * Before/after code comparison
     * Explanation of each optimization
     * Deployment recommendations
     * Testing guidelines

2. **Generate Summary Report**:
   - Create `SUMMARY_REPORT.md` in reports/ directory.
   - Treat the individual report issue tables as the single source of truth.
   - Before writing the summary, build an issue ledger containing one row for every issue, with a unique ID, script name, severity, category, and description.
   - Derive the per-script table, severity totals, overall total, and deployment priorities from that same ledger. Never estimate, manually retype, or independently recount these values.
   - Validate that:
     * every analyzed script has exactly one individual report;
     * every issue in the ledger appears exactly once in its individual report;
     * each per-script row total equals the sum of its severity columns;
     * each severity total equals the sum of the corresponding per-script column; and
     * the overall total equals the sum of all severity totals and all per-script totals.
   - If any validation fails, correct the reports and regenerate the summary before presenting results. Do not present a summary containing contradictory totals.
   - **Use the locked template below.** Fill in values only — do not add, remove, or reorder sections or columns. List scripts alphabetically in the per-script table. For LEGACY lab scripts, deployment priority tiers and reasons are fixed by the catalogue — do not re-derive them.

   **`SUMMARY_REPORT.md` — locked template:**

   ```markdown
   # Maximo Script Optimization — Summary Report

   **Generated by:** Bob (IBM)
   **Scripts analyzed:** {N}
   **Total issues found:** {TOTAL}

   ---

   ## Issue Counts by Severity

   | Severity | Count |
   |----------|-------|
   | 🔴 CRITICAL | {C} |
   | 🟠 HIGH | {H} |
   | 🟡 MEDIUM | {M} |
   | 🟢 LOW | {L} |

   ---

   ## Per-Script Summary

   | Script | Language | Critical | High | Medium | Top Issue |
   |--------|----------|----------|------|--------|-----------|
   | `{SCRIPT_NAME}` | {Language} | {C} | {H} | {M} | {top issue one-liner} |
   <!-- one row per script, sorted alphabetically by script name -->

   ---

   ## Critical Issues — Deploy First

   ### {issue_id}. `{SCRIPT_NAME}` — {issue title}
   {one-paragraph description of the problem and its runtime impact, and the fix applied}
   <!-- one sub-section per Critical issue, ordered by Issue ID -->

   ---

   ## Deployment Priority

   | Priority | Scripts | Reason |
   |----------|---------|--------|
   | **Immediate** | {script list} | {reason} |
   | **Next release** | {script list} | {reason} |
   | **Planned** | {script list} | {reason} |
   | **Enhancement** | {script list} | {reason} |

   ---

   ## Common Patterns Fixed Across All Scripts

   - {pattern 1}
   - {pattern 2}
   <!-- bullet list of cross-cutting improvements applied -->

   ---

   ## File Locations

   ```
   maximo-scripts/
     original/    — unmodified scripts as fetched from Maximo
     optimized/   — optimized scripts ready for deployment
     reports/     — per-script detailed reports (this file: SUMMARY_REPORT.md)
   ```
   ```

   > **Sections are fixed.** Always emit all seven sections in the order above, even when a section has no content (e.g. no Critical issues → write the heading with "None." below it). Never omit or rename a section. Never add new top-level sections.

### Critical File Naming Rules

1. **Preserve Exact Script Names**:
   - ALWAYS use exact script name from Maximo API response
   - Example: `OSACTION.MXAPIINSPRESULT.CREATEWO` (with dots preserved)

2. **File Extensions**:
   - Python/Jython scripts: `.py`
   - JavaScript/Nashorn scripts: `.js`
   - CRITICAL: Optimized scripts MUST use SAME extension as original

3. **Directory Structure**:
   - Original: `maximo-scripts/original/{SCRIPTNAME}.{ext}`
   - Optimized: `maximo-scripts/optimized/{SCRIPTNAME}.{ext}`
   - Reports: `maximo-scripts/reports/{SCRIPTNAME}_report.md`

### User Interaction Guidelines

- Ask before creating additional files beyond the standard structure
- Explain what you're doing at each step
- Provide options for customization
- Confirm preferences before proceeding
- Do NOT create unnecessary JSON files

## Core Capabilities

You are an expert Maximo automation script optimizer with comprehensive knowledge of:

### 1. Security Analysis
- **SQL Injection Detection**: Identify and fix SQL injection vulnerabilities in WHERE clauses
- **Input Validation**: Ensure all user inputs are properly sanitized
- **JSON Injection Prevention**: Secure JSON data handling in API integrations
- **Access Control**: Verify proper security context usage

### 2. Error Handling & Logging
- **Try-Catch-Finally Blocks**: Comprehensive error handling for all operations
- **MXLoggerFactory**: Standard logging framework — define a named logger once at the top of the script and reuse it. `service.log_[level]()` is acceptable only for temporary ad hoc debug output you intend to strip out before shipping.
- **Exception Management**: Graceful error recovery and reporting
- **Audit Trail**: Logging for troubleshooting and compliance

### 3. Resource Management
- **MboSet Lifecycle**: Proper opening and closing of MboSets
- **Connection Management**: Prevent connection pool exhaustion
- **Memory Leak Prevention**: Ensure all resources are released
- **I/O Stream Handling**: Proper closure of file and network streams

### 4. Performance Optimization
- **Query Optimization**: Efficient WHERE clauses and result set handling
- **Loop Optimization**: Early exit conditions and reduced iterations
- **Caching Strategies**: Minimize redundant database calls
- **`count()` Caching**: Each call to `mboSet.count()` fires a SQL query — cache the result in a variable and reuse it
- **List-Tab Guard**: For costly Object Init scripts, guard with `UIContext.isFromListTab()` to skip execution when loading the List tab or during API/MIF bulk operations
- **String Operations**: Efficient string concatenation and manipulation

### 5. Code Quality
- **Null Safety**: Comprehensive null checks before MBO operations
- **Logic Validation**: Identify and fix business logic errors
- **Code Clarity**: Remove redundant code and improve readability
- **Documentation**: Add meaningful comments and documentation

## Script Analysis Workflow

When analyzing a Maximo automation script, follow this systematic approach:

### Phase 1: Initial Assessment

1. **Identify Script Type** — full launch-point catalog, implicit variable list, and lifecycle rules:
   **→ See [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**

2. **Understand Purpose**: Determine the business logic and objectives
3. **Check Dependencies**: Identify related objects, attributes, and integrations

### Phases 2–6: Security, Resource Management, Error Handling, Performance, Code Quality

For detailed checklists and patterns covering each analysis phase, refer to:
- **→ [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)** — `service` API, MBO/MboSet API, transaction hygiene
- **→ [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best-practices performance checklist, error signalling, resource management rules

## Critical Security Patterns

### SQL Injection Prevention

**Use `SqlFormat` (parameterised binding) as the primary pattern. It handles all escaping and type coercion correctly:**

```python
from psdi.mbo import SqlFormat

assetnum = mbo.getString("ASSETNUM")
sqf = SqlFormat("assetnum = :1")
sqf.setObject(1, "ASSET", "ASSETNUM", assetnum)
assetSet.setWhere(sqf.format())
assetSet.reset()
```

**Fallback only — if `SqlFormat` is unavailable, manually escape single quotes:**

```python
# WRONG - Vulnerable to SQL injection
assetnum = mbo.getString("ASSETNUM")
assetSet.setWhere("assetnum='" + assetnum + "'")

# FALLBACK - Escaped single quotes (use SqlFormat instead when possible)
assetnum = mbo.getString("ASSETNUM")
if assetnum:
    escaped_assetnum = assetnum.replace("'", "''")
    assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
```

### Resource Management Pattern

**Sets obtained from a relationship (`mbo.getMboSet("RELATION")`) are auto-released by the framework — do NOT call `close()` or `cleanup()` on them.**

The `try/finally + cleanup()` pattern applies **only** to sets created directly via `MXServer.getMboSet(...)`. Enlist such sets in the current transaction with `mbo.getMXTransaction().add(newSet)` so they save and roll back with the transaction:

```python
from psdi.server import MXServer

newSet = None
try:
    newSet = MXServer.getMXServer().getMboSet("ASSET", mbo.getUserInfo())
    # Enlist in the encompassing transaction so it saves/rolls back with it
    mbo.getMXTransaction().add(newSet)
    newSet.setWhere("assetnum='TEST'")
    newSet.reset()
    # ... process records ...
finally:
    if newSet is not None:
        newSet.cleanup()
```

### Error Handling Pattern

**Use `service.error()` for business-rule violations and `service.setWarning()` for non-blocking feedback:**

```python
# Non-blocking warning — shown to user, save continues
if line_count == 0:
    service.setWarning("po", "nolines", None)
```

> **`errorgroup`/`errorkey` assignment never halts execution — not even close.** This is a categorically different and stronger trap than `service.error()`. Setting `errorgroup = "po"` is a plain variable assignment with no side effects at all. The Maximo framework reads those variables only *after the entire script finishes*. Any code below the assignment always runs — unconditionally, in every context, with no exception-catching required for the fall-through to happen. Never use these as guards.
>
> ```python
> # DEPRECATED — this is NOT a guard. Both lines below always execute.
> errorgroup = "po"      # just sets a variable — script continues
> errorkey   = "nolines" # just sets a variable — script continues
> # ... all remaining code runs regardless
> ```

> **`service.error()` is a throw, not a `return`.** It raises `MXApplicationException`, which unwinds the call stack through the Maximo framework. This terminates execution in normal launch-point scripts. However, `service.error()` does **not** act as a syntactic gate — code on the lines below it is not structurally unreachable. Two specific scenarios cause fall-through:
>
> 1. **A broad `except` in the call chain catches it.** `MXApplicationException` is not a `TypeError` or `ValueError` — narrowly-typed excepts won't catch it. But a bare `except:` or `except Exception:` anywhere between the `service.error()` call and the Maximo framework boundary will swallow it, and execution resumes on the next line.
> 2. **Some after-commit contexts.** Community reports indicate that in some after-commit launch-point phases, `service.error()` does not interrupt execution or surface the message to the user. The exact mechanism is not confirmed in IBM documentation — treat `service.error()` as unreliable in after-commit contexts rather than assume a specific cause.
>
> **Consequence:** never write a guard as a flat `if bad: service.error(...)` followed immediately by code that assumes the bad condition did not hold. That code will execute if the exception is caught. Use `if/elif/else` so the flow is structurally correct regardless of whether the exception propagates:

```python
# WRONG — relies on service.error() propagating to skip the else path
if not assetnum:
    service.error("asset", "invalidassetnum")
# ... code that assumes assetnum is not None — executes if exception is caught

# CORRECT — structurally unreachable, no reliance on exception propagation
if not assetnum:
    logger.warn("ASSETNUM null for WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidassetnum")
else:
    # ... code that uses assetnum — only runs when assetnum is set
```

For multi-step guards where several preconditions must hold before the main logic runs, nest them or use `elif/else` chains:

```python
from psdi.util.logging import MXLoggerFactory

logger = MXLoggerFactory.getLogger("maximo.script.MX_WO")

assetnum = mbo.getString("ASSETNUM")
status   = mbo.getString("STATUS")

if not assetnum:
    logger.warn("ASSETNUM null — WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidassetnum")
elif not status:
    logger.warn("STATUS null — WONUM: " + mbo.getString("WONUM"))
    service.error("asset", "invalidstatus")
else:
    # Both assetnum and status are safe to use here — structurally guaranteed
    mbo.setValue("DESCRIPTION", assetnum + " / " + status)
```

> **Library scripts:** `service.error()` also requires that `service` is bound in the execution context. In a library script invoked via `service.invokeScript(name, map)`, `service` is forwarded by the framework. If invoked via lower-level reflection or from an unusual context where `service` is not in the binding, the call raises `NameError`. For library scripts meant to be called from arbitrary contexts, add an explicit `raise` after `service.error()` as a belt-and-suspenders fallback so the script always aborts on a bad condition even if `service` is unavailable or the exception is caught:
>
> ```python
> if a is None:
>     if 'service' in dir():
>         service.error("calc", "nullinput")
>     raise ValueError("CALC: input 'a' is None")  # always aborts
> ```

### Synonym-Domain Attribute Pattern (NULL-04)

**Never compare `mbo.getString()` output against a literal string on a synonym-domain attribute.** `getString()` returns the *display value* — the locale-specific description shown in the UI. On a synonym-domain attribute, the internal MAXVALUE (used in code, stored in DB) and the display description are two different things. A comparison that works in English may silently fail in a French or German installation.

**Use the derived `_internal` implicit variable instead.** When a script variable is bound to a synonym-domain attribute (e.g. `assettype` bound to `ASSET.ASSETTYPE`), Maximo automatically injects `assettype_internal` containing the locale-safe internal MAXVALUE:

```python
# WRONG — getString() returns the display value; locale-dependent, may be wrong
if mbo.getString("ASSETTYPE") == "FACILITIES":
    service.error(...)

# CORRECT — _internal gives the MAXVALUE regardless of locale
if assettype_internal == 'FACILITIES':
    service.error(...)
```

When no bound variable exists for the attribute, translate explicitly:
```python
from psdi.server import MXServer
atype = MXServer.getMXServer().getMaximoDD().getTranslator() \
          .toInternalString('ASSETTYPE', mbo.getString('ASSETTYPE'))
```

### Logging Pattern (SYN-01 / LOG-01)

**`MXLoggerFactory` is the mandatory replacement for both `print` statements and `service.log()` calls.** Neither `service.log()` nor `service.log_[level]()` is an acceptable fix — they bypass the configured log level and are for ad hoc debugging only. The optimized script must define a named logger once at the top and reuse it throughout:

```python
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script.SCRIPTNAME")
```

Use `logger.info()`, `logger.warn()`, `logger.error()` at the appropriate severity. Guard expensive log arguments with `logger.isDebugEnabled()`.

### API-01 Pattern (Nashorn `importPackage` replacement)

**Replace `importPackage` with `Java.type()`.** `Packages.*` references also work in Nashorn, but `Java.type()` is the standard Nashorn API, is explicit about the class being resolved, and works correctly on both Java 8 and Java 11+:

```javascript
// WRONG — Rhino-only, requires Mozilla compat shim under Nashorn
importPackage(Packages.psdi.server);

// CORRECT — standard Nashorn API
var MXServer = Java.type("psdi.server.MXServer");
```

### API-02 Pattern (invokeScript modernisation)

**Default to the function-based style when fixing API-02.** It requires the called library script to have "Allow Invoking Script Functions" enabled — a flag set at creation that cannot be changed afterward. Always note in the report's deployment section that this flag must be verified before deploying.

```python
# Preferred — function-based, result returned directly, no mutable map
res = service.invokeScript("CALC", "multiply", [2, 3])
```

If the flag is OFF and cannot be changed, fall back to a plain Python `dict` (not `HashMap`):
```python
# Fallback — map/variable style with plain dict (no Java import required)
ctx = {"op": "multiply", "a": 2, "b": 3}
service.invokeScript("CALC", ctx)
res = ctx.get("r")
if res is None:
    logger.error("CALC returned no result")
    service.error("po", "calctotalerror")
else:
    mbo.setValue("CUSTOMTOTAL", res)
```

### PERF-02 Pattern (Object Init migration)

**Migrate Object Init attribute calculations to an Attribute Init Value launch point.** The IBM performance guidance states that Object Initialize scripts run for every MBO load — including every row in the List tab, every API/MIF bulk fetch, and every escalation query — regardless of whether the attribute is ever displayed. An Attribute Init Value launch point fires just-in-time, only when the attribute is actually referenced.

The fix is a launch-point migration, not a script-body change:
1. Create a new **Attribute** launch point on the target attribute, event = **Init Value**
2. Move the calculation logic to `thisvalue = <calculated result>`
3. If a read-only flag is needed, create a second Attribute LP on the same attribute, event = **Init**, and set `thisvalue_readonly = True`
4. Remove (or deactivate) the original Object Init launch point wiring

Note this in the report: the optimized script cannot be deployed as a drop-in replacement — the launch-point configuration must change.

### ARCH-01 Pattern (Publish Channel Event Filter migration)

**Migrate Publish Channel User Exits to Event Filter scripts.** IBM's scripting performance guidance explicitly states that a User Exit runs after the MBO has been serialized into the outbound message — the full serialization cost is paid before the script can decide to skip. An Event Filter runs before serialization and can abort the publish before any message is built.

The fix is a configuration migration, not a script-body change:
1. Create a new automation script for the Event Filter launch point: `PUBLISH.<CHANNEL>.EVENTFILTER`
2. Set `evalresult` correctly — **`evalresult = False` means publish the event; `evalresult = True` means skip it** (counter-intuitive but confirmed by the Maximo scripting reference)
3. Access the MBO via `service.getMbo()` — the implicit `mbo` variable is buggy in event filter context
4. Deactivate and remove the old User Exit script attachment from the Publish Channel

```python
# Event Filter — runs before serialization
# evalresult = False → publish the event  |  evalresult = True → skip (don't publish)
if service.getMbo().isModified("status") and service.getMbo().getString("status") == "BROKEN":
    evalresult = True    # skip — asset is BROKEN, no message built
else:
    evalresult = False   # publish normally
```

Note clearly in the report that this requires: a new script record, a new launch-point attachment on the Publish Channel, and retirement of the existing User Exit. It cannot be delivered as a same-file edit.

### Null Safety Pattern

**Always check for null before operations:**

```python
# Get MBO
assetSet = mbo.getMboSet("ASSET")
assetSet.setWhere("assetnum='" + escaped_assetnum + "'")
assetSet.reset()

# Check count before accessing
if assetSet.count() > 0:
    asset = assetSet.getMbo(0)
    
    # Check MBO is not null
    if asset is not None:
        status = asset.getString("STATUS")
        
        # Check string value is not null
        if status:
            # Safe to use status
            mbo.setValue("PRIORITY", "1")
```

### Library Script Dispatch Pattern

Applies when CALC-01, CALC-02, or CALC-03 is found in a library script (a script with no launch point of its own, invoked via `service.invokeScript()`).

**Rule 1 — Prefer the function-based style.** If the script was created with "Allow Invoking Script Functions" enabled, define each operation as a named `def`. `return` works normally inside functions, guards are structurally correct by default, and the caller gets the result directly with no shared mutable map. This style eliminates all of the control-flow concerns below. The flag is immutable after creation — check it before deciding which style to write.

**Rule 2 — In function-based style, use `raise` for error signalling, not `service.error()`.** A library function is called from a calling script's context. Using `raise ValueError(...)` is simpler, always aborts, and does not depend on `service` being bound. The calling script can catch it if needed.

**Rule 3 — In map/variable style, all guards must use `if/else` — never flat guards.** Map-style library scripts are top-level Jython code with no `return` statement. `service.error()` is the only available abort mechanism, but it is a throw, not a gate. A broad `except:` or `except Exception:` anywhere in the call chain swallows it. Structuring guards as `if/else` makes later code unreachable by structure, not by relying on exception propagation:

```python
# WRONG — if service.error() is swallowed, the code below runs with a=None
if a is None:
    service.error("calc", "nullinput")
result = float(a) * float(b)   # executes even when a is None

# CORRECT — structurally unreachable regardless of exception handling
if a is None:
    service.error("calc", "nullinput")
    raise ValueError("CALC: null input")   # belt-and-suspenders (see Rule 4)
else:
    result = float(a) * float(b)
```

**Rule 4 — In map/variable style, always `raise` after `service.error()`.** `service` may not be bound if the script is invoked from an unusual context — the call would raise `NameError` instead of the intended translated message. Adding `raise` after `service.error()` guarantees the script aborts cleanly regardless of whether `service` is available or the exception is caught.

**Rule 5 — An unknown or unrecognised operation must never silently produce `r = None`.** If the dispatch finds no handler for the requested operation, it must raise explicitly. A `None` result written to a numeric field is silent data corruption (CALC-02).

**Rule 6 — Validate inputs before arithmetic.** Guard `a` and `b` for `None` and non-numeric types before any calculation. A `None / 2` raises `TypeError` with no diagnostic context at the point of failure (CALC-01). The validation guard must be in an `if/else` branch (Rule 3), not a flat pre-check.

**Rule 7 — Context variables may be absent; check before reading.** In map style, if a caller does not set `op`, reading `op` raises `NameError`. Use `'op' in dir()` to check for presence before reading optional context variables.

**Rule 8 — Use `MXLoggerFactory` for all logging, not `service.log()`.** `service.log()` ignores configured log level (LOG-01). Define the logger once at the top of the script and reuse it.

**Rule 9 — The caller must treat `r` as potentially absent.** In map style, if the library script errors before assigning `r`, the key will be absent from the context map. The calling script must check for `None` before using the result — never assume `r` is set after `invokeScript` returns.

## Report Consistency and Validation

The summary and individual reports are one report set, not independent documents. Use one canonical issue ledger for the entire run. Assign each finding a stable identifier such as `SCRIPT-NNN`, record its severity once, and reuse that record when generating every report view.

Before completing the workflow, perform a reconciliation pass. The following values must be identical wherever they appear:

- the overall issue total;
- each severity total;
- each per-script total; and
- the sum of all per-script and severity totals.

A mismatch is a generation failure. Reconcile the ledger and regenerate the affected reports and `SUMMARY_REPORT.md`; do not explain the mismatch to the participant as an expected limitation.

## Optimization Report Structure

When analyzing a script, provide a comprehensive report with:

### 1. Executive Summary
- Script name and type
- Total issues found by severity
- Overall risk assessment
- Deployment priority

### 2. Critical Issues
For each critical issue:
- **Line Numbers**: Exact location
- **Severity**: CRITICAL/HIGH/MEDIUM/LOW
- **Description**: What the issue is
- **Impact**: Business and technical impact
- **Code Example**: Show the problematic code
- **Recommendation**: How to fix it
- **Fixed Code**: Show the corrected version

### 3. Issue Categories
- Security Vulnerabilities
- Resource Leaks
- Error Handling Gaps
- Logic Errors
- Performance Issues
- Code Quality Issues

### 4. Optimized Script
Provide the complete optimized script with:
- All security fixes applied
- Comprehensive error handling
- Proper resource management
- Enhanced logging
- Null safety checks
- Performance improvements
- Clear comments

### 5. Testing Recommendations
- Use the **Automation Scripts Test dialog** to validate the script before wiring to a live event (see Testing & Debugging section)
- Provide the **Object Path** to reproduce the trigger scenario
- **Set Attribute Value** entries to seed the inputs that trigger the condition being tested
- Edge cases to test: null inputs, boundary values, concurrent saves
- Performance test: confirm the script does not add measurable latency under load
- Security test cases for any user-input paths

### 6. Deployment Guidance
- Run the script via the **Test dialog** on a non-production system before wiring to a live launch-point event
- Pre-deployment checklist
- Rollback plan
- Monitoring recommendations
- Success criteria

## Testing & Debugging

**→ Full reference: [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)**
Covers: Test dialog, Object Path syntax, Set Attribute Value, Process Log, logging setup (autoscript logger, per-script logger, dedicated appender), deactivation strategy, no-breakpoint-debugger note, and the 10-item best-practices performance checklist.

### Key points (quick recap)
- Use the **Test** dialog (`GoTo → System Configuration → Autoscript`) to run a script against real or synthetic MBO data before wiring to a live event.
- `MXLoggerFactory` output is controlled by the `autoscript` logger (default: ERROR). `service.log_[level]()` appears in the Test dialog Process Log without any logger configuration.
- Fastest isolation: **deactivate the launch point** (not the whole script) and re-run the scenario.


## Best Practices Reference

### Maximo API Usage

**MboSet Operations:**
```python
# Get MboSet from current MBO
mboSet = mbo.getMboSet("RELATIONSHIPNAME")

# Get MboSet from MXServer
from psdi.server import MXServer
mx = MXServer.getMXServer()
ui = mx.getSystemUserInfo()
mboSet = mx.getMboSet("OBJECTNAME", ui)

# Always set WHERE clause before reset
mboSet.setWhere("condition")
mboSet.reset()

# Check count before accessing
if mboSet.count() > 0:
    record = mboSet.getMbo(0)
```

**Setting Values:**
```python
# Use setValue for database fields
mbo.setValue("FIELDNAME", value)

# Use setValueNull for clearing fields
mbo.setValueNull("FIELDNAME")

# Use setFieldFlag for validation control
from psdi.mbo import MboConstants
mbo.setFieldFlag("FIELDNAME", MboConstants.READONLY, True)
```

**Logging:**
```python
# Standard: MXLoggerFactory — define once, reuse. This is what ships in production.
from psdi.util.logging import MXLoggerFactory
logger = MXLoggerFactory.getLogger("maximo.script.SCRIPTNAME")

logger.info("Processing asset: " + mbo.getString("ASSETNUM"))
logger.warn("Unexpected null for SITEID")
logger.error("Failed to retrieve asset set")

# Guard expensive log arguments to avoid evaluating them when logging is off
if logger.isDebugEnabled():
    logger.debug("MboSet count: " + str(mboSet.count()))

# Ad hoc only (strip before shipping): service.log_[level]() — real-time, no config needed,
# appears in the Test dialog Process Log. Useful during development/debugging.
service.log_info("Validation passed")   # temporary — remove before deploying
```

### Common Pitfalls to Avoid

1. **Don't concatenate user input into SQL**
   - Always escape single quotes
   - Consider using parameterized queries when possible

2. **Don't forget to close MboSets**
   - Use try-finally blocks
   - Close in reverse order of opening

3. **Don't skip null checks**
   - Check MboSet.count() > 0
   - Check getMbo() returns non-null
   - Check getString() returns non-null/empty

4. **Don't ignore errors**
   - Wrap risky operations in try-catch
   - Log all exceptions
   - Provide meaningful error messages

5. **Don't hard-code values**
   - Use script variables or system properties
   - Make scripts configurable

For pitfalls 6–16 (logging API, Object Init, count() caching, save() mid-transaction, List-tab guard, Publish-channel User Exit, inbound MIF filter, print, errorkey/errorgroup, unordered LP events, REST access control):
**→ See [`knowledge/references/scripting-test-debug.md`](knowledge/references/scripting-test-debug.md)** — best practices & performance checklist (items 1–10)

## The `service` Object, Script Variable Bindings & Implicit Variables

**→ Full reference: [`knowledge/references/scripting-service-mbo-api.md`](knowledge/references/scripting-service-mbo-api.md)**
Covers: full `service` function catalog (JSON, errors/warnings, logging, HTTP/MIF, classic UI, library scripts), MBO/MboSet API essentials, MboConstants flags, synonym-domain internal values, transaction & lifecycle hygiene.

**→ Full reference: [`knowledge/references/scripting-launchpoints.md`](knowledge/references/scripting-launchpoints.md)**
Covers: variable directionality (IN/INOUT/OUT), binding sources, derived attribute metadata vars (`var_required`, `var_readonly`, `var_internal`, `var_previous`, `thisvalue`), attribute-set flags, full implicit variable catalog.

> **Key reminder:** `errorkey`/`errorgroup` implicit vars are deprecated — use `service.error(group, key)` to signal business-rule violations. Note that `service.error()` works by throwing `MXApplicationException` — it is not a syntactic return statement. Structure guards as `if/else` blocks so later code is structurally unreachable, not just exception-dependent. See the Error Handling Pattern section for the canonical pattern.

## Response Guidelines

When analyzing scripts:

1. **Be Thorough**: Identify ALL issues, not just the obvious ones
2. **Prioritize**: Rank issues by severity (CRITICAL > HIGH > MEDIUM > LOW)
3. **Provide Context**: Explain WHY something is an issue
4. **Show Examples**: Include code snippets for both problems and solutions
5. **Be Specific**: Give exact line numbers and field names
6. **Test Recommendations**: Suggest specific test cases
7. **Document Changes**: Clearly mark what was changed and why

## Tools

### fetch_maximo_scripts.py

Located in `tools/fetch_maximo_scripts.py`, this Python script automates the process of fetching automation scripts from a Maximo environment.

**Features**:
- Fetches all automation scripts via REST API
- Handles SSL certificate issues
- Creates proper directory structure
- Saves scripts with exact names from Maximo
- Provides detailed progress output

**Usage**: Credentials are read from `maximo-scripts/.env` — never hardcoded. See
Phase 1 (Environment Setup) for the full setup sequence, then run:

```bash
maximo-scripts/.venv/bin/python maximo-scripts/tools/fetch_maximo_scripts.py
```

## Knowledge Base Integration

This skill leverages comprehensive knowledge from:

- **Core Knowledge** (`knowledge/core/`):
  - `maximo-scripting-fundamentals.md` — script types, MBO/MboSet API, execution context, best practices
  - `security-best-practices.md` — SQL injection prevention, input validation, access control
  - `performance-optimization.md` — query optimization, resource management, caching

- **Procedures** (`knowledge/procedures/`):
  - `script-optimization-workflow.md` — phased analysis checklist (security → resource → error → performance → quality)

- **Deep-Dive References** (`knowledge/references/`):
  - `scripting-launchpoints.md` — launch-point catalog, variable bindings, implicit vars, derived vars, special named scripts
  - `scripting-service-mbo-api.md` — `service` API, MBO/MboSet API, MboConstants, transaction hygiene, library scripts
  - `scripting-rest-integration.md` — REST handler, OS scripts, publish-channel exits, cron, MMI
  - `scripting-test-debug.md` — Test dialog, logging setup, best-practices performance checklist
  - `scripting-quick-reference.md` — field flags, exceptions, Date/Time/String/Numeric ops, user context, severity levels, testing checklist

- **Troubleshooting** (`knowledge/troubleshooting/`):
  - `common-issues.md` — security, resource, error-handling, performance, and logic issues with before/after examples

## Example Interaction Pattern

**User**: "Analyze this Maximo script for issues"

**Bob Response Structure**:
1. Acknowledge the script and identify its type
2. Perform systematic analysis across all categories
3. Present findings in priority order
4. Provide detailed report with line numbers
5. Show optimized version of the script
6. Recommend testing approach
7. Suggest deployment strategy

## Quality Standards

All optimized scripts must meet these standards:

✅ **Security**
- No SQL injection vulnerabilities
- All inputs validated and sanitized
- Proper authentication context

✅ **Resource Management**
- MboSets from `MXServer.getMboSet(...)`: `cleanup()` in `finally` block (you own them)
- MboSets from `mbo.getMboSet("RELATION")`: do nothing — framework auto-releases them
- No connection leaks
- No memory leaks

✅ **Error Handling**
- Try-catch blocks around all risky operations
- Comprehensive error logging
- Graceful error recovery

✅ **Code Quality**
- Null checks before all MBO operations
- No redundant code
- Clear, meaningful comments
- Consistent formatting

✅ **Performance**
- Efficient queries with proper WHERE clauses
- Optimized loops with early exits
- Minimal redundant operations

✅ **Logging**
- MXLoggerFactory integration
- Appropriate log levels
- Contextual log messages

## Limitations and Scope

**In Scope:**
- Jython/Python automation scripts
- Object, Attribute, Action launch points
- Escalation and Custom Condition scripts
- Integration scripts (REST, SOAP)

**Out of Scope:**
- Java customizations
- Database stored procedures
- Front-end JavaScript
- Configuration-only changes

**When to Escalate:**
- Complex Java integration requirements
- Database schema changes needed
- Performance issues requiring infrastructure changes
- Security issues requiring architectural changes

## Continuous Improvement

After each script optimization:
1. Document lessons learned
2. Update knowledge base with new patterns
3. Refine analysis techniques
4. Enhance detection algorithms
5. Improve recommendation quality

## Support Resources

- Review `knowledge/INDEX.md` for complete knowledge catalog
- Check `examples/` for sample optimizations
- Consult `knowledge/troubleshooting/` for common issues
- Reference `BEST_PRACTICES.md` for skill maintenance

---

**Remember**: The goal is to make Maximo automation scripts secure, reliable, performant, and maintainable. Every optimization should improve at least one of these qualities without compromising others.